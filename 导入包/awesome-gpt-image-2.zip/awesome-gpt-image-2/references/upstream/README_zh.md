
<a href="https://youmind.com/zh-CN/gpt-image-2-prompts">
  <img src="https://marketing-assets.youmind.com/campaigns/gpt-image-2/og-hq.png" alt="GPT Image 2 Prompts" width="100%" />
</a>

> 💡 🎬 进阶玩法：用 **Seedance 2** 把 GPT Image 2 生成的图变成炸裂 AI 视频，2000+ 提示词等你探索 👉 [awesome-seedance-2-prompts](https://github.com/YouMind-OpenLab/awesome-seedance-2-prompts)
# 🚀 GPT Image 2 提示词大全

[![Awesome](https://awesome.re/badge.svg)](https://github.com/sindresorhus/awesome)
[![GitHub stars](https://img.shields.io/github/stars/YouMind-OpenLab/awesome-gpt-image-2?style=social)](https://github.com/YouMind-OpenLab/awesome-gpt-image-2)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Update README](https://github.com/YouMind-OpenLab/awesome-gpt-image-2/actions/workflows/update-readme.yml/badge.svg)](https://github.com/YouMind-OpenLab/awesome-gpt-image-2/actions)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](docs/CONTRIBUTING.md)

> 🎨 OpenAI GPT Image 2 创意提示词精选集合

> ⚠️ **版权声明**：所有提示词均收集自社区，仅供教育目的使用。如果您认为任何内容侵犯了您的权利，请[提交 issue](https://github.com/YouMind-OpenLab/awesome-gpt-image-2/issues/new?template=bug-report.yml)，我们将立即移除。

---

[![English](https://img.shields.io/badge/English-Click%20to%20View-lightgrey)](README.md) [![简体中文](https://img.shields.io/badge/%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87-Current-brightgreen)](README_zh.md) [![繁體中文](https://img.shields.io/badge/%E7%B9%81%E9%AB%94%E4%B8%AD%E6%96%87-Click%20to%20View-lightgrey)](README_zh-TW.md) [![日本語](https://img.shields.io/badge/%E6%97%A5%E6%9C%AC%E8%AA%9E-Click%20to%20View-lightgrey)](README_ja-JP.md) [![한국어](https://img.shields.io/badge/%ED%95%9C%EA%B5%AD%EC%96%B4-Click%20to%20View-lightgrey)](README_ko-KR.md) [![ไทย](https://img.shields.io/badge/%E0%B9%84%E0%B8%97%E0%B8%A2-Click%20to%20View-lightgrey)](README_th-TH.md) [![Tiếng Việt](https://img.shields.io/badge/Ti%E1%BA%BFng%20Vi%E1%BB%87t-Click%20to%20View-lightgrey)](README_vi-VN.md) [![हिन्दी](https://img.shields.io/badge/%E0%A4%B9%E0%A4%BF%E0%A4%A8%E0%A5%8D%E0%A4%A6%E0%A5%80-Click%20to%20View-lightgrey)](README_hi-IN.md) [![Español](https://img.shields.io/badge/Espa%C3%B1ol-Click%20to%20View-lightgrey)](README_es-ES.md) [![Español (Latinoamérica)](https://img.shields.io/badge/Espa%C3%B1ol%20(Latinoam%C3%A9rica)-Click%20to%20View-lightgrey)](README_es-419.md) [![Deutsch](https://img.shields.io/badge/Deutsch-Click%20to%20View-lightgrey)](README_de-DE.md) [![Français](https://img.shields.io/badge/Fran%C3%A7ais-Click%20to%20View-lightgrey)](README_fr-FR.md) [![Italiano](https://img.shields.io/badge/Italiano-Click%20to%20View-lightgrey)](README_it-IT.md) [![Português (Brasil)](https://img.shields.io/badge/Portugu%C3%AAs%20(Brasil)-Click%20to%20View-lightgrey)](README_pt-BR.md) [![Português](https://img.shields.io/badge/Portugu%C3%AAs-Click%20to%20View-lightgrey)](README_pt-PT.md) [![Türkçe](https://img.shields.io/badge/T%C3%BCrk%C3%A7e-Click%20to%20View-lightgrey)](README_tr-TR.md)

---

## 🌐 在网页图库中查看

<div align="center">

[![Cover](public/images/gpt-image-2-prompts-cover-zh.png)](https://youmind.com/zh-CN/gpt-image-2-prompts)

</div>

**[👉 浏览 YouMind GPT Image 2 提示词图库](https://youmind.com/zh-CN/gpt-image-2-prompts)**

为什么使用图库？

| Feature | GitHub README | youmind.com 图库 |
|---------|--------------|---------------------|
| 🎨 可视化布局 | 线性列表 | 精美的瀑布流网格 |
| 🔍 搜索 | 仅 Ctrl+F | 全文搜索和筛选 |
| 🤖 AI 一键生图 | - | AI 一键生图 |
| 📱 移动端 | 基础 | 完全响应式 |
| 🏷️ 分类 | - | 分类浏览 |


### 🏷️ 按分类浏览

- **使用场景**
  - [个人资料 / 头像](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=profile-avatar)
  - [社交媒体帖子](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=social-media-post)
  - [信息图 / 教育视觉图](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=infographic-edu-visual)
  - [YouTube 缩略图](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=youtube-thumbnail)
  - [漫画 / 故事板](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=comic-storyboard)
  - [产品营销](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=product-marketing)
  - [电商主图](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=ecommerce-main-image)
  - [游戏素材](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=game-asset)
  - [海报 / 传单](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=poster-flyer)
  - [App / 网页设计](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=app-web-design)
- **风格**
  - [摄影](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=photography)
  - [电影 / 电影剧照](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=cinematic-film-still)
  - [动漫 / 漫画](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=anime-manga)
  - [插画](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=illustration)
  - [草图 / 线稿](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=sketch-line-art)
  - [漫画 / 图画小说](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=comic-graphic-novel)
  - [3D 渲染](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=3d-render)
  - [Q 版 / Q 萌风](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=chibi-q-style)
  - [等距](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=isometric)
  - [像素艺术](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=pixel-art)
  - [油画](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=oil-painting)
  - [水彩画](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=watercolor)
  - [水墨 / 中国风](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=ink-chinese-style)
  - [复古 / 怀旧](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=retro-vintage)
  - [赛博朋克 / 科幻](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=cyberpunk-sci-fi)
  - [极简主义](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=minimalism)
- **主体**
  - [人像 / 自拍](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=portrait-selfie)
  - [网红 / 模特](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=influencer-model)
  - [角色](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=character)
  - [团体 / 情侣](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=group-couple)
  - [产品](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=product)
  - [食品 / 饮料](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=food-drink)
  - [时尚单品](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=fashion-item)
  - [动物 / 生物](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=animal-creature)
  - [车辆](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=vehicle)
  - [建筑 / 室内设计](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=architecture-interior)
  - [风景 / 自然](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=landscape-nature)
  - [城市风光 / 街道](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=cityscape-street)
  - [图表](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=diagram-chart)
  - [文本 / 排版](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=text-typography)
  - [摘要 / 背景](https://youmind.com/zh-CN/gpt-image-2-prompts?categories=abstract-background)

---

## 📖 目录

- [🌐 在网页图库中查看](#-view-in-web-gallery)
- [🤔 什么是 GPT Image 2？](#-what-is-gpt-image-2)
- [📊 统计数据](#-statistics)
- [🔥 精选提示词](#-featured-prompts)
- [📋 所有提示词](#-all-prompts)
- [🤝 如何贡献](#-how-to-contribute)
- [📄 许可证](#-license)
- [🙏 致谢](#-acknowledgements)
- [⭐ Star 历史](#-star-history)

---

## 🤔 什么是 GPT Image 2？

**GPT Image 2**（代号 **"duct-tape"**）是 OpenAI 下一代图像生成模型。社区测试反馈它在以下方面实现了质的飞跃：

- 🎯 **像素级文字渲染** — 中文、英文、日文均达到 native 水准，无错字、无字形扭曲
- 🎨 **跨图像素级一致性** — 同一角色、风格、IP 在多张图间保持像素级一致
- ⚡ **商用级插画质量** — 插画风格输出无需人工精修，即可直接用于商业场景
- 🌈 **真实艺术风格注入** — 不止是"模仿参考图"，而是真正理解并再现艺术风格的灵魂
- 🔧 **故事板与产品系列** — 适合故事板、IP 形象、产品系列图等需要多图一致性的场景
- 📐 **多语言平面设计** — 社交卡片、Banner、海报一次生图即可完成多语言文字排版

📚 **了解更多：** 查看社区测试 [报告要点](docs/FAQ.md)

### 🚀 Raycast 集成

部分提示词支持使用 [Raycast Snippets](https://raycast.com/help/snippets) 语法的**动态参数**。寻找 🚀 Raycast Friendly 徽章！

**示例：**
```
A quote card with "{argument name="quote" default="Stay hungry, stay foolish"}"
by {argument name="author" default="Steve Jobs"}
```

在 Raycast 中使用时，您可以动态替换参数以快速迭代！

---

## 📊 统计数据

<div align="center">

| 指标 | 数量 |
|--------|-------|
| 📝 提示词总数 | **17579** |
| ⭐ 精选 | **6** |
| 🔄 最后更新 | **2026年9月23日星期三 UTC 15:43:27** |

</div>

---

## 🔥 精选提示词

> ⭐ 由我们的团队精心挑选，具有卓越的质量和创造力

### No. 1: VR 头显爆炸视图海报

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一张高科技 VR 头显爆炸视图，包含详细的组件标注和宣传文案。

#### 📝 提示词

```
{
  "type": "产品爆炸视图海报",
  "subject": "VR 头显",
  "style": "简洁的高科技 3D 渲染，摄影棚灯光，发光装饰",
  "background": "{argument name=\"background color\" default=\"柔和的紫蓝色渐变\"}",
  "header": {
    "logo": "∞ {argument name=\"product name\" default=\"Meta Quest 3\"}",
    "subtitle": "{argument name=\"main catchphrase\" default=\"以全新的结构，重塑全新的现实。\"}"
  },
  "layout": {
    "centerpiece": "VR 头显的垂直堆叠爆炸视图，展示了 9 层不同的内部组件：外壳、摄像头传感器、带芯片的主板、Pancake 透镜、内部框架、电池组、侧带、顶部头带和面部接口衬垫。",
    "callout_labels": {
      "count": 8,
      "left_side": [
        "Snapdragon® XR2 Gen 2\n卓越的处理性能，带来实时沉浸体验。",
        "可调节 IPD 机构\n为广大用户提供舒适的佩戴感。",
        "精密设计的头带\n追求舒适与稳定的工程学设计。"
      ],
      "right_side": [
        "前面板\n精致的设计与优化的重量平衡。",
        "追踪摄像头\n实现高精度的位置追踪与环境感知。",
        "Pancake 透镜\n轻薄设计，提供广阔视野与清晰画质。",
        "高性能电池\n优化电源设计，支持长时间续航。",
        "柔软的面部接口\n确保长时间佩戴依然舒适。"
      ]
    },
    "footer": {
      "left_text_block": {
        "headline": "{argument name=\"bottom headline\" default=\"体验，源于结构的进化。\"}",
        "body": "每一个零件都蕴含着支撑沉浸式体验的前沿科技与匠心设计。Meta Quest 3 从内部构建未来，为您带来超乎想象的体验。"
      },
      "right_logo": "∞ Meta"
    }
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776658772018_lukyfw_HGSUfldbIAEiMWZ.jpg" width="700" alt="VR 头显爆炸视图海报 - Image 1">
</div>

#### 📌 详情

- **作者:** [wory＠ホッピング中](https://x.com/wory37303852)
- **来源:** [Twitter Post](https://x.com/wory37303852/status/2045925660401795478#reversed-0)
- **发布时间:** 2026年4月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=13460)**

---

### No. 2: 手绘城市美食地图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一张手绘水彩风格的旅游地图，包含编号的当地特色美食、地标建筑及图例。

#### 📝 提示词

```
{
  "type": "手绘地图信息图",
  "style": "{argument name=\"art style\" default=\"复古羊皮纸上的水彩墨水手绘插画\"}",
  "title_section": {
    "text": "{argument name=\"city name\" default=\"成都\"} {argument name=\"map title\" default=\"吃货暴走地图\"}",
    "mascot": "戴着墨镜并竖起大拇指的卡通红辣椒"
  },
  "border": "{argument name=\"border decoration\" default=\"绿叶与红辣椒藤蔓\"}",
  "layout": {
    "background": "带有黄色道路、蓝色河流和绿色公园区域的纹理米色羊皮纸",
    "sections": [
      {
        "title": "地标建筑",
        "count": 6,
        "illustrations": ["传统凉亭", "传统寺院", "带有攀爬熊猫的现代摩天大楼", "高耸的电视塔", "传统牌坊", "工业建筑"],
        "labels": ["人民公园", "文殊院", "IFS", "339电视塔", "宽窄巷子", "东郊记忆"]
      },
      {
        "title": "美食地点",
        "count": 12,
        "illustrations": ["麻婆豆腐", "红油水饺", "冷锅串串", "三大炮", "蛋烘糕", "九宫格火锅", "肥肠粉", "钵钵鸡", "冒菜", "盖碗茶", "冰粉", "兔头"],
        "labels": ["1 陈麻婆豆腐", "2 钟水饺", "3 春熙路", "4 宽窄巷子·三大炮", "5 建设路·叶婆婆蛋烘糕", "6 玉林路·小龙坎火锅", "7 香香巷·肥肠粉", "8 武侯祠大街·钵钵鸡", "9 东郊记忆·冒椒火辣", "10 人民公园·鹤鸣茶社", "11 锦里古街·冰粉", "12 双流老妈兔头"]
      },
      {
        "title": "图例",
        "position": "右下角",
        "count": 5,
        "items": ["红点", "绿色建筑", "绿树", "蓝线", "黄色双线"],
        "labels": ["美食地点", "地标景点", "公园绿地", "河流湖泊", "主要道路"]
      }
    ],
    "centerpiece": "坐着吃竹子的大熊猫",
    "bottom_right_extras": ["带有东南西北方向的复古罗盘", "带有红辣椒图标的免责声明：'温馨提示：吃辣需谨慎，肠胃要保护~'"]
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776662673014_nf0taw_HGRMNDybsAAGG88.jpg" width="700" alt="手绘城市美食地图 - Image 1">
</div>

#### 📌 详情

- **作者:** [皮皮特](https://x.com/mm_zzm44854)
- **来源:** [Twitter Post](https://x.com/mm_zzm44854/status/2045861258520568230#reversed-1)
- **发布时间:** 2026年4月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=13515)**

---

### No. 3: 混合风格的桃太郎讲解 Slides

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个融合了 Irasutoya 插图简约温馨的美学风格与日本政府 Slides 高信息密度特征的提示词。

#### 📝 提示词

```
创建一个讲解型 Slides（{argument name="format" default="ponchi-e diagram"}），主题为 {argument name="theme" default="Momotaro"}，将“Irasutoya”的柔和氛围与“霞关风格 Slides”极高的信息密度完美融合。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776699414289_t6mebs_HGQQxukbUAA_qc0.jpg" width="700" alt="混合风格的桃太郎讲解 Slides - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776699414149_63j8pd_HGQQy1_aQAAHSqP.jpg" width="700" alt="混合风格的桃太郎讲解 Slides - Image 2">
</div>

#### 📌 详情

- **作者:** [やまもん](https://x.com/yammamon)
- **来源:** [Twitter Post](https://x.com/yammamon/status/2045778624092254603)
- **发布时间:** 2026年4月19日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=13983)**

---

### No. 4: 电商直播 UI 样机

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成逼真的社交媒体直播界面，叠加在人物肖像之上，包含可自定义的聊天消息、礼物弹窗和商品购买卡片。

#### 📝 提示词

```
{
  "type": "直播 UI 样机",
  "subject": {
    "description": "{argument name=\"host name\" default=\"Elon Musk\"} 的肖像，面带微笑，身穿印有白色技术示意图的黑色 T 恤",
    "background": "左侧显示带有 '{argument name=\"left background logo\" default=\"SPACEX\"}' 文字的屏幕，右侧显示红色的 '{argument name=\"right background logo\" default=\"Tesla T logo\"}' 和一辆深色汽车"
  },
  "ui_overlay": {
    "top_header": {
      "host_info": "头像，名称 '{argument name=\"host name\" default=\"Elon Musk\"}'，副标题 '55.6万本场点赞'，红色 '关注' 按钮",
      "rank_badge": "带有 '全站第1名' 的金币图标",
      "viewer_stats": "3 个顶部观众头像，显示 '12.3w'、'8.6w'、'5.7w'，总计 '68.7万'，'X' 关闭按钮",
      "right_links": "'更多直播 >'，'礼物展馆 0/24'（带有蓝色 '经典' 标签）"
    },
    "mid_left_gifts": {
      "count": 2,
      "items": [
        "头像 '科技爱好者'，'送小心心'，爱心图标 x 1314",
        "头像 '星辰大海'，'送火箭'，火箭图标 x 666"
      ]
    },
    "bottom_left_chat": {
      "system_message": "37 级勋章 '宇宙漫游者 加入了直播间'",
      "message_count": 7,
      "messages": [
        "小火箭: 马斯克！未来可期！🚀",
        "future: 特斯拉Model 2什么时候出？",
        "星空梦想家: SpaceX今年能上火星吗？",
        "AI探索者: Neuralink进展如何？",
        "帅气的网友: 马总好！",
        "Mars: 第一次来你的直播，超激动！",
        "用户123: 讲讲AI吧，会取代人类吗？"
      ]
    },
    "bottom_right_product_card": {
      "hot_tag": "橙色 '热卖 x 1888'",
      "image": "Tesla Cybertruck",
      "title": "{argument name=\"product name\" default=\"特斯拉Cybertruck 电动皮卡\"}",
      "price": "{argument name=\"product price\" default=\"¥ 1,618,000\"}",
      "button": "红色 '抢' 按钮",
      "floating_animation": "半透明爱心沿右侧边缘向上浮动"
    },
    "bottom_bar": {
      "input_field": "'说点什么...'",
      "icons": ["笑脸", "三个点", "购物车", "礼物盒", "分享"]
    }
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776699445498_ga2ry5_HGO7H0DWkAApdKK.jpg" width="700" alt="电商直播 UI 样机 - Image 1">
</div>

#### 📌 详情

- **作者:** [神经病不想好转](https://x.com/sjbbxhz)
- **来源:** [Twitter Post](https://x.com/sjbbxhz/status/2045684734714380687#reversed-0)
- **发布时间:** 2026年4月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=14036)**

---

### No. 5: 动漫武术对决

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一个动态的动漫风格动作场景，展示两个角色在传统道场中伴随元素光环进行战斗。

#### 📝 提示词

```
一幅极具动态感的动漫插画，描绘了两名少女在传统木质道场内进行激烈武术对决的场景。在前景中，一名留着 {argument name="character 1 hair" default="黑色高丸子头配红色丝带"} 的少女摆出强有力的低位武术架势，正奋力挥拳。她身穿 {argument name="character 1 outfit" default="带有红色流苏的白色中式上衣和红色宽松长裤"}，强烈的红色能量斩击环绕着她挥动的四肢。在右侧半空中，一名留着 {argument name="character 2 hair" default="浅紫色双丸子头"} 的少女优雅地跃起，自信地微笑着，身穿 {argument name="character 2 outfit" default="带有金色刺绣的深绿色连衣裙和黑色紧身裤"}，伴随着扫过的蓝色水流状能量轨迹。背景是质朴的木质寺庙内部，上方悬挂着一块写有“{argument name="sign text" default="武術会"}”的醒目招牌。场景充满了爆发性的动作感，飞扬的尘土、破碎的木质地板、发光的彩色粒子特效，以及将角色与精细背景完美区分开来的戏剧性低角度光影。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776756799880_c8u8w7_HGUKjjaasAAvVRa.jpg" width="700" alt="动漫武术对决 - Image 1">
</div>

#### 📌 详情

- **作者:** [たねもみ 2.0 / Tanemomi Ver2.0](https://x.com/Tanemomi_Ver2)
- **来源:** [Twitter Post](https://x.com/Tanemomi_Ver2/status/2046063806846214265#reversed-0)
- **发布时间:** 2026年4月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=13467)**

---

### No. 6: 3D 石阶演化信息图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Featured](https://img.shields.io/badge/⭐-Featured-gold)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

将平面的演化时间轴转化为逼真的 3D 石阶信息图，包含精细的生物渲染图和结构化的侧边栏。

#### 📝 提示词

```
{
  "type": "演化时间轴信息图",
  "instruction": "以 REFERENCE_0 作为结构基础，将平面矢量设计转化为高度逼真的 3D 信息图。将平滑的坡道替换为独特的石阶，并将所有生物升级为照片级真实的 3D 模型。",
  "style": {
    "background": "{argument name=\"background style\" default=\"复古纹理羊皮纸\"}",
    "staircase": "{argument name=\"staircase material\" default=\"逼真的纹理石块\"}",
    "subjects": "{argument name=\"organism style\" default=\"高度精细的照片级真实 3D 渲染\"}"
  },
  "layout": {
    "main_title": "{argument name=\"main title\" default=\"人类演化\"}",
    "sections": [
      {
        "position": "左侧边栏",
        "count": 8,
        "labels": ["L0: 单细胞生命", "L1: 多细胞生物", "L2: 动物界", "L3: 脊索动物", "L4: 上陆革命", "L5: 哺乳纲", "L6: 人科演化", "L7: 智人纪元"]
      },
      {
        "position": "右上角",
        "title": "获得的功能 / 失去的功能",
        "description": "带有加号和减号图标的图例"
      },
      {
        "position": "底部中心",
        "title": "演化关键里程碑",
        "count": 6,
        "description": "包含 6 个展示从猿到人演化剪影图形的时间轴"
      }
    ],
    "centerpiece": {
      "description": "蜿蜒的石阶，共有 25 个编号台阶，展示特定生物。",
      "count": 25,
      "notable_elements": [
        "第 07 阶: 水母",
        "第 09 阶: 菊石",
        "第 10 阶: 三叶虫",
        "第 24 阶: 直立行走的人类",
        "第 25 阶: {argument name=\"future evolution concept\" default=\"带有问号的发光宇宙剪影\"}"
      ]
    }
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1776661968404_8a5flm_HGQc_KOaMAA2vt0.jpg" width="700" alt="3D 石阶演化信息图 - Image 1">
</div>

#### 📌 详情

- **作者:** [知识猫图解](https://x.com/GeekCatX)
- **来源:** [Twitter Post](https://x.com/GeekCatX/status/2045792240044511277#reversed-1)
- **发布时间:** 2026年4月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=13491)**

---

## 📋 所有提示词

> 📝 按发布日期排序（最新优先）

### No. 1: 个人资料 / 头像 - 晨间厨房围裙人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张写实风格的人像照片，展示了一位年轻女子在阳光明媚的厨房里系着头发，身穿格纹围裙，周围摆放着新鲜食材。

#### 📝 提示词

```
这是一张写实风格的中景照片，展现了一位年轻的亚洲女性站在明亮温馨的厨房中，正值清晨时分。她留着带刘海的黑色长发，双臂举至脑后，正在将头发扎成马尾。她身穿一件黑白格纹围裙，白色肩带露出光洁的肩膀，佩戴着精致的金色项链和小巧耳环。她的神情平静，目光直视镜头。前景的木质台面上摆放着新鲜食材，包括一把绿叶蔬菜、三颗藤上红番茄、一把厨师刀和一个不锈钢搅拌碗。背景是温暖的木质橱柜、一台白色冰箱，以及一扇透入柔和自然阳光的窗户，照亮了整个场景。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150026668_6ry2za_HS2zg2EaYAAFQsn.jpg" width="600" alt="个人资料 / 头像 - 晨间厨房围裙人像 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150026577_zqi54u_HS2zg16awAAmE93.jpg" width="600" alt="个人资料 / 头像 - 晨间厨房围裙人像 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150026340_9k6sku_HS2zg2CbIAAw9JN.jpg" width="600" alt="个人资料 / 头像 - 晨间厨房围裙人像 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150027318_1dn225_HS2zg1-aQAAtn5v.jpg" width="600" alt="个人资料 / 头像 - 晨间厨房围裙人像 - Image 4">
</div>

#### 📌 详情

- **作者:** [One Breath｜AI Portrait](https://x.com/OneBreath00)
- **来源:** [Twitter Post](https://x.com/OneBreath00/status/2102533983292793075#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35238)**

---

### No. 2: 个人资料 / 头像 - GPT Image 2 提示词：晨间厨房围裙

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

用于生成一张写实照片的提示词，画面中一位女性在厨房里系头发，身穿格纹围裙。

#### 📝 提示词

```
主题：
穿着格纹围裙系头发的场景。

主要主体：
年轻女性在明亮的厨房中央抬起双臂系头发。关键元素包括：黑白小方格挂脖式围裙、腰部前方打的大结、前景中的蔬菜。

人物与表情：
小巧的椭圆形脸庞，下巴纤细，深棕色大眼睛，眉毛稀疏整齐，鼻子精致，光泽粉嫩的嘴唇微微张开。脸部略微向右转，目光平静地直视镜头。深棕色头发带有细碎刘海和松散发丝，双手在脑后扎成低马尾。

服装与姿势：
黑白小方格图案，粗白色挂脖带，褶皱围裙连衣裙平整覆盖胸部，腰部前方有同材质大蝴蝶结。佩戴小金耳环和细吊坠。站立时手肘大幅向上向外弯曲，双手在脑后拢起头发。

背景与光线：
前景为木质台面，上有金属碗装的绿叶蔬菜、红番茄、刀具和胡椒研磨器。背景左侧是冰箱和木架，中间是水槽，右侧是大窗户和绿植。清晨强烈的阳光从右上方窗户射入，照亮面部、手臂和胸部，在台面上投下明亮阴影。

构图与相机：
3:4 竖幅构图，相机位于台面对面的胸部高度，捕捉从头部到腰部以下的人物上半身。人物居中且占比大，抬起的手臂构成顶部框架，蔬菜位于底部边缘。手肘在侧边被裁切，焦点集中在眼睛/面部，厨房景深略微虚化。

纹理与风格：
写实摄影风格。高清自然肤质，细腻格纹布料，头发，金属碗，蔬菜，木质台面。色彩：白色、黑色、木色调加上温暖的晨光。

负面提示：
改变手臂/系头发的姿势；省略格纹围裙或蔬菜。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150022718_cotvzv_HScB3Shb0AA3kZH.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 提示词：晨间厨房围裙 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2102520565219180953)
- **发布时间:** 2026年9月22日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35232)**

---

### No. 3: 个人资料 / 头像 - 可爱对话气泡吉祥物头像图标

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

生成一个极简风格头像，包含一个脸红的白色对话气泡角色和一个在黑色背景上微笑的小型设备伙伴。

#### 📝 提示词

```
一幅极简主义扁平设计插画，描绘了两个可爱的吉祥物，背景为纯黑色。主要主体位于左侧，是一个大型白色对话气泡角色，拥有两个垂直椭圆形黑眼睛和脸颊上柔和的粉色腮红。右下角部分重叠在主形象上的是一个较小的灰色圆角矩形，类似手持设备或智能手机，配有白色屏幕；屏幕上显示着一张简单的脸，有两个黑点眼睛和微笑的嘴巴。整体风格简洁、矢量感强，适合作为个人头像图标。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150026701_ohp2z3_HS0jSeZagAAbC-B.jpg" width="600" alt="个人资料 / 头像 - 可爱对话气泡吉祥物头像图标 - Image 1">
</div>

#### 📌 详情

- **作者:** [りょうたぐ/ryoutag.@愛しのsense9破損で泣く](https://x.com/ryoutag_)
- **来源:** [Twitter Post](https://x.com/ryoutag_/status/2102375406011830423#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35237)**

---

### No. 4: 个人资料 / 头像 - GPT Image 2 怀旧编辑风剪贴簿转换

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

将上传的照片转换为垂直 3:4 的编辑风格剪贴簿布局。上半部分保留原始照片的真实感，下半部分则在纹理纸上呈现同一场景的微缩手绘故事书版本，并配有微妙的手写文字。

#### 📝 提示词

```
使用上传的照片作为精确的视觉参考，将其转换为具有怀旧感的编辑风格剪贴簿艺术作品。保留原始照片中的人物主体、构图、服装、姿势、物体及整体场景。

创建垂直 3:4 的构图，采用精致、极简且受日本美学启发的照片转插画风格。

最终设计应分为两个相等的水平区域：

上半部分 — 原始照片
• 将上传的原始照片放置在画布的上半部分（50%）。
• 保持其真实感且完全不做修改。
• 保留确切的面部特征、身体比例、服装、发型、姿势、光照、环境、家具、食物、毯子、窗户以及所有其他可识别的细节。
• 不要裁剪重要的主体。
• 自然地使用原始图像，边缘干净，无人工边框。

下半部分 — 微缩故事书版本
• 将照片中的确切场景重新创作为一幅小巧精致的手绘插画，位于下半部分的中心附近。
• 保持相同的人物主体、姿势、服装、物体、透视和可识别的构图，但使整个场景看起来像是放置在纸上的微小怀旧插画。
• 使用柔和的水彩 + 彩色铅笔 + 微妙的水粉画美学。
• 细腻不完美的笔触、轻微纹理的边缘、柔和的阴影、柔和的自然色彩、略微褪色的复古外观。
• 微缩场景应仅占据下半部分约 25–35% 的空间，周围留有充足的负空间。
• 使其感觉像是捕捉在纸上的微小记忆，而非常规的全框插画。
• 在微缩场景下方添加非常微妙的手绘阴影，以使其感觉自然地放置在纸上。

背景
• 用温暖的米白色/象牙色手工纸覆盖整个下半部分。
• 可见细微的纸张纤维和颗粒感。
• 略有不均匀的有机纹理，类似于优质水彩纸。
• 极简、温暖、平静且优雅。
• 无边框、无装饰图案、无不必要的元素。

文字
• 在微缩插画下方，添加一行非常小的手写短语：
“{argument name="phrase" default="sunny days"}”
• 使用纤细、精致的小写手写体。
• 浅灰色/灰褐色墨水。
• 保持文字微妙且不显眼，居中置于艺术作品下方。

光照与色彩
• 温暖的自然日光。
• 柔和的奶油色、米色、淡蓝色、柔和的牛仔蓝和暖棕色调。
• 温和的高光和柔和的阴影。
• 略带怀旧感的胶片风格调色。
• 避免过度饱和。
• 整体氛围：安静、舒适、感性、宁静的家庭记忆。

重要提示
• 保持参考照片中人物的身份和视觉特征。
• 不要发明额外的人物或物体。
• 不要改变服装或姿势。
• 不要扭曲解剖结构。
• 微缩插画必须清晰地描绘与原始照片完全相同的时刻和场景。
• 干净的高端编辑式构图。
• 高细节、精致的艺术指导、写实
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150020908_dj537c_HSzQDcuaYAAOrZ0.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 怀旧编辑风剪贴簿转换 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150020932_ajoywl_HSzQEE6aEAEdeZe.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 怀旧编辑风剪贴簿转换 - Image 2">
</div>

#### 📌 详情

- **作者:** [Laraib Fatima‎](https://x.com/AiwithLariab)
- **来源:** [Twitter Post](https://x.com/AiwithLariab/status/2102283904560566600)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35230)**

---

### No. 5: 个人资料 / 头像 - 迪拜天际线黄金时刻人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成一位女性在黄金时刻于俯瞰迪拜市中心天际线的阳台上自拍的超写实竖版人像的提示词。

#### 📝 提示词

```
创建一张超写实的 9:16 竖版人像，保留参考图像中同一位女性的确切面部特征、脸型、眼睛、眉毛、鼻子、嘴唇、下颌线、自然肤色及可识别的特征。她留着长而浓密的黑发，梳成高马尾，其余头发以柔和波浪状自然垂落在单侧肩上。她身穿一件优雅的象牙白修身长袖服装，带有柔软的堆堆领和微妙的毛绒袖口。
她在黄金时刻于一个阳台上拍摄自然的自拍，背景是迪拜市中心天际线和停泊着船只的水滨。背景中可见高耸的现代摩天大楼，通过真实的景深效果呈现柔和模糊状态。温暖的夕阳余晖轻轻照亮她的脸庞，营造出自然的高光和柔和的阴影。
自然放松的微笑，直视镜头，真实的面部表情，逼真的皮肤质感，可见细微细节和毛孔，微妙的瑕疵，真实的发丝，专业智能手机摄影，浅景深，电影般的自然光线，逼真的色彩，高细节，照片级真实感，高端生活方式摄影。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150021286_krpxxh_HSzQCfpXIAA93oG.jpg" width="600" alt="个人资料 / 头像 - 迪拜天际线黄金时刻人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [Zarnish](https://x.com/ZarnishNael)
- **来源:** [Twitter Post](https://x.com/ZarnishNael/status/2102283876294918510)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35231)**

---

### No. 6: 个人资料 / 头像 - 电影感蓝色背光人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成具有青色蓝色背光和未来主义氛围的忧郁、高对比度电影感人像的提示词。

#### 📝 提示词

```
电影感高对比度人像，年轻男子侧脸特写，佩戴深色墨镜，中等长度凌乱头发被风吹向后方，下颌线条分明且面部纹理自然，戏剧性剪影效果，强烈的青色蓝色背光从身后照射，明亮过曝的白蓝色光晕环绕发丝，面部和颈部呈现深邃阴影，微妙的轮廓光勾勒出发丝和肩部线条，忧郁的未来主义氛围，极简背景，浅景深，柔和的大气雾霭，照片级逼真的皮肤和头发细节，时尚杂志摄影风格，使用 85mm 人像镜头拍摄，光圈 f/1.8，高动态范围，胶片颗粒感，青蓝单色调色，超精细细节，8K 分辨率，垂直构图，3:4 宽高比。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150022327_vqyz70_HSyk80baAAAEBne.jpg" width="600" alt="个人资料 / 头像 - 电影感蓝色背光人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2102236497948897434)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35157)**

---

### No. 7: 个人资料 / 头像 - 南亚女性时尚大片

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于创建南亚女性传统服饰优雅写实肖像的提示词，背景为奢华室内环境。

#### 📝 提示词

```
超写实优雅肖像：一位年轻南亚女性端坐于室内，留着中分、浓密飘逸的深棕色长发，自然垂落在肩头。她五官精致，皮肤质感真实自然，妆容柔和，眉形清晰，眼线细腻，唇色红润，神情平静自信，直视镜头。她身穿一件合身的黑色露肩长袖上衣，佩戴着优雅的长款传统吊坠耳环。一条柔和的灰粉色刺绣 Lehenga（长裙）环绕在她身侧，裙摆上饰有精致的银金色细节，自然铺展。温暖的室内自然光，奢华现代的背景，柔和的中性色调，浅景深效果，逼真的面料纹理，电影感摄影风格，可见自然的皮肤毛孔，高细节呈现，专业时尚大片摄影，85mm 镜头，柔和散景，照片级真实感，垂直 4:5 构图。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063416657_tdf4kw_HSt0ZvjakAAHYiF.jpg" width="600" alt="个人资料 / 头像 - 南亚女性时尚大片 - Image 1">
</div>

#### 📌 详情

- **作者:** [Zarnish](https://x.com/ZarnishNael)
- **来源:** [Twitter Post](https://x.com/ZarnishNael/status/2101901645684838428)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35111)**

---

### No. 8: 个人资料 / 头像 - GPT Image 2 提示词：花园斑驳光影

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

GPT Image 2 提示词：生成一张写实照片，展现一位身穿白色服饰的女性坐在花园池塘边，重点突出斑驳的阳光效果。

#### 📝 提示词

```
主题：
白色花园中的斑驳阳光

主体：
画面中央，一位年轻女性坐在水莲池的石质边缘。象牙色细带迷你连衣裙、系至脚踝的白色凉鞋、手抚脸颊的动作以及洒满斑驳阳光的庭院是主要特征。

人物/面部：
瘦长的鹅蛋脸，小巧的下巴，淡棕色的大眼睛，纤细的眉毛，挺直的鼻梁，光泽感的淡粉色嘴唇。脸部微微向右倾斜，对着正面镜头露出温柔的微笑。明亮的灰棕色长发带有稀疏的空气刘海和柔和的面部波浪卷，自然垂落至肩部和背部。

服装/姿势：
短款喇叭形象牙色迷你连衣裙，配有细肩带、侧边系带和细微褶皱。白色细带凉鞋从脚趾交叉缠绕至脚踝上方，搭配低细跟。双膝并拢并在石质边缘处向左弯曲，双腿交叉，左臂伸展搭在膝盖上，右肘靠在左臂上，右手手指轻触脸颊。

背景/光线：
左下角是点缀着水莲和白花的池塘，后方有植被和巨大的树冠，白色的墙壁和深色木梁，带有大型格子窗的房屋，右侧背景中有一张绿色长椅。阳光从左上方柔和地透过树叶形成斑驳光影，照亮头发、肩膀、膝盖和石质边缘，在背景中营造出圆形叶片散景效果。

构图/相机：
2:3 竖幅构图，正面相机位于坐姿高度，拍摄范围从头顶到凉鞋脚趾全身。人物占据中心偏左位置，修长的双腿呈对角线延伸至右下角，池塘位于左下角，房屋位于右上角。脚趾靠近底部边缘，焦点集中在面部和服装上，花园和房屋呈现柔和虚化效果。

纹理/风格：
写实真人摄影风格。高清柔顺的发丝，自然的皮肤质感，连衣裙上的细微褶皱，细皮革鞋带，石头，树叶，水面；象牙色与绿色的清晰日光色调。

负面提示：
改变坐姿和系带鞋样式；省略花园和水莲池塘
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977645878_0o835b_HSbe5A6bsAAV2MH.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 提示词：花园斑驳光影 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101873803492216846)
- **发布时间:** 2026年9月21日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35118)**

---

### No. 9: 个人资料 / 头像 - 电影感男性肖像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

使用 GPT Image 2 生成的超写实电影感特写肖像提示词，展现身着西装的男士与戏剧性光影效果。

#### 📝 提示词

```
超写实电影感特写肖像，一位英俊的年轻男子身着精致的黑色定制西装和挺括的白色正装衬衫，浓密的深棕色波浪发向后梳理，呈现自然蓬松感，面部轮廓清晰阳刚，留有淡淡的胡茬，下颌线分明，目光坚定自信地直视镜头，采用四分之三侧面姿势，神情优雅而神秘。戏剧性的影棚布光，左侧带有温暖的琥珀色/橙色轮廓光，背景为深邃的冷调海军蓝，对比强烈，面部高光与阴影层次丰富且立体，浅景深，奢华时尚杂志美学，高端电影级调色，皮肤纹理高度细腻，发丝真实可见，毛孔自然，眼神锐利，专业摄影，85mm 人像镜头，f/1.8，柔和散景，HDR，照片级真实感，超高细节，8K，竖构图，精致的好莱坞风格肖像。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150023082_vpxiv3_HStZ5D3boAEtI0F.jpg" width="600" alt="个人资料 / 头像 - 电影感男性肖像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Sahil Verma](https://x.com/sahilvermaai)
- **来源:** [Twitter Post](https://x.com/sahilvermaai/status/2101872495544648189)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35108)**

---

### No. 10: 个人资料 / 头像 - 柑橘园自然抓拍人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成女性在柑橘园中户外自然抓拍人像的提示词，强调自然光线与质朴纹理。

#### 📝 提示词

```
一张写实风格的户外自然抓拍人像，画面中一位年轻女性坐在郁郁葱葱的柑橘园里的质朴木质平台上。她留着深棕色长卷发，发丝自然地垂落在肩头和背部，几缕精致的碎发轻拂脸颊。她头上松松地裹着一条柔和的米色头巾或宽布发带。
她抬头望向镜头，神情俏皮欢快，一只眼睛眨着，涂着柔和珊瑚红唇膏的嘴唇绽放出灿烂笑容。她的姿态放松而随性，一只手臂弯曲置于身侧，一只手轻轻搭在腰间附近。
她身穿一件修身的白色无袖纹理上衣，带有精致细节，搭配高腰蓝色牛仔短裤。手腕上戴着一根简单的黑色发圈。
她身旁放着一个大编织柳条篮，其弯曲的手柄和天然稻草纹理清晰可见。她身下的木质平台呈现出温暖的天然木纹和质朴质感。
她周围环绕着茂密的绿色花园，长满青草、绿叶植物，还有一棵成熟的柑橘树，树上挂满了无数小巧成熟的橙色果实。粗壮的枝干和鲜绿的叶片填满了背景上方，形成美丽的天然华盖。
构图：垂直 4:5 人像比例，略微俯视的高角度视角，主体位于画面下方中央，面部清晰可见，篮子在她身旁部分可见，柑橘树填满背景，呈现自然的抓拍框架。
光线：柔和温暖的自然日光，头发和面部有轻柔的高光，阴影真实，绿植新鲜充满活力，色调略带暖色。
摄影风格：超写实智能手机摄影，韩式/亚洲生活方式美学，自然皮肤质感，逼真的发丝，详细的柳条和木材纹理，真实的户外色彩，轻微的广角透视，微妙的景深，柔和的胶片颗粒感，高细节，4K。
负面提示词：动漫，卡通，插画，CGI，3D 渲染，塑料皮肤，过度美颜滤镜，不真实的面部，解剖结构扭曲，畸形手部，多余手指，缺失手指，融合手指，多余肢体，不自然姿势，变形篮子，人造头发，过饱和色彩，刺眼演播室灯光，模糊面部，低分辨率，文字，水印，标志。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977643868_qz26gy_HStP_xWbQAAun3Z.jpg" width="600" alt="个人资料 / 头像 - 柑橘园自然抓拍人像提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977643910_pwsu2r_HStQAikbQAACyps.jpg" width="600" alt="个人资料 / 头像 - 柑橘园自然抓拍人像提示词 - Image 2">
</div>

#### 📌 详情

- **作者:** [Aqsa](https://x.com/Aqsahere_)
- **来源:** [Twitter Post](https://x.com/Aqsahere_/status/2101861630657359924)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35114)**

---

### No. 11: 个人资料 / 头像 - 白毛巾温泉自拍

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个用于生成写实图像的提示词，描绘了一位年轻女子裹着白色毛巾在传统日式温泉中自拍的场景。

#### 📝 提示词

```
一张由一位年轻的亚洲女性拍摄的高分辨率写实自拍。她留着湿润的深棕色齐肩发和柔和的刘海。她裹着一条蓬松的白色浴巾，一只手紧紧护在胸前，另一只手伸出镜头进行拍摄。她的皮肤呈现出水润光泽的质感，暗示她刚刚沐浴完毕。场景位于传统日式温泉（Onsen）室内或半户外区域。背景中有一个石制水盆，清澈的水从竹制出水口流入池中，泛起轻柔的涟漪。左侧，一盏温暖明亮的纸灯笼放置在石台上，旁边有一盆小盆栽和一个木桶。灯光氛围浓郁且富有情调，将灯笼的暖光与水及石墙的冷色调完美融合。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977651720_plt2nq_HSno-O-aAAApSlG.jpg" width="600" alt="个人资料 / 头像 - 白毛巾温泉自拍 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977651731_1tvd2k_HSno-O4a4AEMI8y.jpg" width="600" alt="个人资料 / 头像 - 白毛巾温泉自拍 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977651704_cwunnk_HSno-O-aoAAZ13M.jpg" width="600" alt="个人资料 / 头像 - 白毛巾温泉自拍 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977652409_6iqh2h_HSno-O_aQAA2yzU.jpg" width="600" alt="个人资料 / 头像 - 白毛巾温泉自拍 - Image 4">
</div>

#### 📌 详情

- **作者:** [One Breath｜AI Portrait](https://x.com/OneBreath00)
- **来源:** [Twitter Post](https://x.com/OneBreath00/status/2101587415962124452#reversed-0)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35128)**

---

### No. 12: 个人资料 / 头像 - Y2K 风格拍照亭拼贴提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

使用 GPT Image 2 创建具有 Y2K 美学的怀旧四格拍照亭风格自拍拼贴画的提示词。

#### 📝 提示词

```
创作一张怀旧的成人女性四格拍照亭风格自拍拼贴画，每一格展示不同的俏皮表情和姿势，银色数码相机闪光灯效果，高光略微过曝，光泽感 Y2K 造型，色彩鲜艳的紧凑室内背景，微小的瑕疵细节，真实的千禧年初快照质感，细微颗粒感，柔和模糊效果，充满趣味的怀旧氛围，照片级真实感，3:4 比例。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977640707_qx7hpi_HSpG_4FaUAAkDhV.jpg" width="600" alt="个人资料 / 头像 - Y2K 风格拍照亭拼贴提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Eesha](https://x.com/MissDelulu9)
- **来源:** [Twitter Post](https://x.com/MissDelulu9/status/2101570258545057803)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35109)**

---

### No. 13: 个人资料 / 头像 - 韩国女孩黄金时刻人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

专为 GPT Image 设计的详细提示词，用于生成一位在黄金时刻坐在石质露台上的韩国女孩的逼真肖像。

#### 📝 提示词

```
创作了一位优雅地坐在美丽古典石质露台上的韩国女孩，时间设定为黄金时刻。她面容柔和精致，皮肤白皙自然，拥有一双大而富有表现力的棕色眼睛，淡淡的粉色腮红，光泽自然的嘴唇，以及一头非常长、直顺、如丝绸般的乌黑秀发，中分发型自然地垂落在双肩。她身穿合身的白色长袖上衣，搭配鼠尾草绿高腰阔腿裤，佩戴精致的银色耳环、小吊坠项链和奶油色单肩包。她自然地坐在石栏杆上，双腿并拢，双手轻轻放在腿上。周围环绕着覆盖着美丽白花的翠绿藤蔓、一盏优雅的复古灯笼、石柱，以及宁静的湖泊、远山和温暖粉彩日落的风景。柔和的金色阳光在她的头发和脸上形成美丽的轮廓光。逼真的皮肤纹理，真实的织物细节，自然的人体比例，电影级 DSLR 摄影效果，浅景深，柔和的背景虚化，温暖浪漫的氛围，高度细节化，超写实，自然光照，无变形，无多余手指，无人工感的皮肤。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977639073_9dquiz_HSobcbTboAAv9ym.jpg" width="600" alt="个人资料 / 头像 - 韩国女孩黄金时刻人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Maha](https://x.com/Aiwithmaha)
- **来源:** [Twitter Post](https://x.com/Aiwithmaha/status/2101522366593712546)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35105)**

---

### No. 14: 个人资料 / 头像 - 巴黎咖啡馆人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

使用 GPT Image 2 生成的时尚女性巴黎咖啡馆写实人像提示词。

#### 📝 提示词

```
一张高分辨率、写实风格的平视人像照片，画面中一位时尚的年轻白人女性坐在温暖昏暗的巴黎咖啡馆里。她神情宁静温柔，柔和的棕色双眸直视镜头。她的深金色头发梳成优雅的发辫盘发，几缕精致的碎发自然垂落在脸庞周围。她身穿一件深海军蓝丝绸缎面裹身长袖衬衫，搭配厚实的纹理感金色圈形耳环和细款金色叠戴链条项链。她的手优雅地搭在对侧肩膀上。背景呈现浅景深效果，伴有温暖的金色散景光斑、灯串反射、经典的深色木质护墙板和法式小酒馆座椅。柔和的自然窗光凸显了她光泽的肤色和丝滑的面料质感，采用 85mm 人像镜头拍摄，具有专业布光和电影级美学风格。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977640344_a2gddy_HSoUVMOakAAW65J.jpg" width="600" alt="个人资料 / 头像 - 巴黎咖啡馆人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Lavinia](https://x.com/laviniavelle)
- **来源:** [Twitter Post](https://x.com/laviniavelle/status/2101514600990773301)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35107)**

---

### No. 15: 个人资料 / 头像 - GPT Image 2 电影感男性人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个使用参考图像生成面部特征的超写实人像提示词，重点在于电影级布光、时尚杂志美学以及高细节的皮肤和头发渲染。

#### 📝 提示词

```
电影感超写实男性人像，使用提供的参考图像作为面部特征和整体外观的依据。一位 30 多岁男性的头部和肩部特写构图，具有强烈的男性化面部轮廓、分明的下颌线、浓密有质感的深色头发、逼真的短胡须以及细腻自然的皮肤纹理。他戴着圆形复古琥珀色/玳瑁色墨镜，镜片为深色，身穿一件超大号黑色连帽衫。他直视镜头，表情强烈、平静且中性。

忧郁奢华的时尚杂志美学，侧面戏剧性的冷蓝色轮廓光与皮肤上微妙的暖色调主光相结合，深邃的电影感阴影，墨镜中逼真的反射效果，根根分明的头发和胡须。柔和的蓝灰色工作室背景，带有轻微的大气衰减效果，浅景深，面部焦点清晰。使用 85mm 人像镜头在 f/1.8 光圈下拍摄，专业工作室摄影，高对比度，精致的暗色调色板，轻微的模拟胶片颗粒感，照片级真实感，极其详细，自然比例，电影级色彩分级，高端杂志编辑风格，8K 细节，居中构图。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977647215_39dbzm_HSoUJGmbQAAX-RX.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 电影感男性人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2101514331200639444)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35055)**

---

### No. 16: 个人资料 / 头像 - GPT Image 2 提示词：红色跑车内饰

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

用于 GPT Image 2 的提示词，生成一张高角度照片，展示一位身穿白色网眼制服的女性坐在红色跑车的驾驶座上。

#### 📝 提示词

```
主体：
红色内饰中的白色制服

主要主体：
画面中央，一位年轻女性坐在一辆红色敞篷跑车的驾驶座上，双膝抬起。她身穿白色网眼制服风格迷你连衣裙，搭配白色宽松长袜和透明厚底高跟鞋。

人物/面部：
瘦长的椭圆形脸庞，下巴小巧，明亮的棕色大眼睛，细眉，鼻梁挺拔，微微张开的珊瑚粉色光泽嘴唇。面部朝前，目光平静地望向镜头上方。浅棕色长发呈层叠状，留有薄刘海，披散在肩部和背部。

服装/姿势：
白色无袖网眼制服风格迷你连衣裙，领口和袖窿处有黑色 V 形设计，胸前有大号黑色字符图案。脚穿白色厚款宽松长袜和透明厚底高跟鞋。坐在驾驶座上，膝盖高高弯曲，右肘靠在车身边缘，右手轻触太阳穴，左臂自然垂放在大腿旁。

背景/光线：
背景为黑色内饰和红色车身，顶部可见灰色路面和红色立柱。强烈的日光从上方照射，配合正面辅助光，使面部、手臂和腿部明亮突出，车内形成深邃阴影。

构图/相机：
3:4 竖幅构图，鸟瞰视角从上方向下拍摄敞开的车身，涵盖从头顶到透明高跟鞋的全身。人物位于中心且占比大，方向盘在左下角，格纹座椅在右下角。车身四边被裁剪，焦点集中在面部，景深允许清晰分辨整个内饰细节。

纹理/风格：
写实摄影风格。高清自然的皮肤质感、网眼织物、厚针织袜、透明树脂鞋、红色车漆、黑色皮革及格纹布料；红、白、黑三色对比强烈。

负面提示：
改变鸟瞰视角下的内饰和膝盖位置；遗漏红色车身
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977646050_jc1fs5_HSbPn0za0AEOL1I.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 提示词：红色跑车内饰 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101482978278789330)
- **发布时间:** 2026年9月20日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35117)**

---

### No. 17: 个人资料 / 头像 - 水做的动漫少女

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

生成一个完全由水构成的空灵动漫角色的提示词，特色为水裙和漂浮的水滴，背景为多云天空。

#### 📝 提示词

```
创作一幅垂直构图的动漫风格数字插画，描绘一位完全由水构成的年轻女孩。角色留着短发波波头，头发看起来像是由飞溅的水花形成，发梢带有粉色和蓝色色调。她的眼睛大而清澈，呈蓝色，宛如水滴。她身穿一件由流动透明液态水制成的连衣裙，如水般环绕身体旋转。她的双腿和双脚也由水构成，赤脚站在浅水池中，水面反射着上方的天空。周围漂浮着许多大小不一的水滴和气泡。背景是柔和梦幻的天空，布满蓬松的白云，明亮的阳光透过云层洒下，营造出高调、空灵的照明效果。整体配色方案由冷蓝色、白色和柔和的粉色组成。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789891173879_dfcw7a_HSnQUXya4AAKY2d.jpg" width="600" alt="个人资料 / 头像 - 水做的动漫少女 - Image 1">
</div>

#### 📌 详情

- **作者:** [あいぼりー](https://x.com/HetareIvory)
- **来源:** [Twitter Post](https://x.com/HetareIvory/status/2101440136202559702#reversed-0)
- **发布时间:** 2026年9月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35057)**

---

### No. 18: 个人资料 / 头像 - GPT Image 2 提示词：连帽衫眨眼自拍

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

用于 GPT Image 2 的提示词，生成一张写实风格的自拍照片：一位身穿灰色连帽衫、戴着眼镜的女性，正对着镜头做 V 字手势遮住一只眼睛并眨眼。

#### 📝 提示词

```
主题：
透过眼镜的晨间眨眼

主要主体：
画面中央，在明亮的卧室里，一位年轻女性身体前倾靠近镜头，戴着灰色兜帽，左手在眼部区域做出横向 V 字手势。无框眼镜、单眼眨眼和灰色休闲服是主要特征。

人物/面部：
圆润纤薄的脸庞，小下巴，睁开的右眼呈深棕色，眉毛纤细，鼻梁挺拔，嘴唇呈光泽淡粉色。面部朝前，左眼闭起眨眼，右眼凝视近处的相机。长直深棕色头发带有湿发感的细刘海和碎发，从兜帽内垂至胸前。纤细的银色无框眼镜配有拉长的透明镜片。

服装/姿势：
浅灰色长袖拉链连帽夹克，具有精细编织纹理，银色拉链大幅拉开，白色抽绳，兜帽环绕头部。配套短裤带有白色饰边和腰部系带。腰部向前倾斜，右臂向下伸展支撑身体，左肘弯曲，左手的食指和中指从袖口伸出，分别位于左眼的上方和下方。

背景/光线：
左侧背景有白色床铺、镜子、台灯和香薰机，右侧为黑色椅子和浅色墙壁，底部铺有白色长毛地毯。来自左侧窗户的柔和日光照亮了面部、眼镜、头发和灰色织物，在室内投下淡淡的阴影。

构图/相机：
3:4 竖幅构图，平视视角的近景正面相机，取景范围从兜帽顶部到短裤顶部的半身肖像。面部占据上半部分较大比例，V 字手势位于左侧前景，眼镜居中。头顶、右臂和大腿在屏幕边缘被裁剪，焦点集中在睁开的右眼和眼镜上，背景呈现浅景深虚化效果。

纹理/风格：
写实真人摄影照片。高清自然肤质，根根分明的湿发，透明镜片，银色金属配件，精细灰色织物和白色地毯；白色与浅灰色的柔和晨光。

负面提示：
改变单眼眨眼和眼部上方的 V 字手势；粗框眼镜
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977644360_90i4ci_HSbOR2Bb0AAGCYZ.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 提示词：连帽衫眨眼自拍 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101437931344851203)
- **发布时间:** 2026年9月19日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35116)**

---

### No. 19: 个人资料 / 头像 - GPT Image 2 日式房间人像提示词

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

为 GPT Image 2 设计的详细提示词，用于生成一位身着和服、坐在榻榻米上手持折扇并带有纹身细节的女性逼真肖像。

#### 📝 提示词

```
主题：
折扇与牡丹的日式房间

主要主体：
画面中央，一位年轻女性坐在明亮日式房间的榻榻米上，身穿印有牡丹图案的和服，左手展开一把花卉折扇。右大腿前景处可见一条大型鲤鱼与波浪线条纹身。

人物与表情：
纤细的鹅蛋脸，小巧的下巴，大而明亮的榛褐色眼睛，细眉，鼻梁挺直，微微张开的嘴唇呈现光泽桃色。头部略微向右倾斜，静静地直视镜头。深棕色头发盘成高耸凌乱的发髻，薄刘海和散落的发丝垂至脸颊，右侧后脑勺插着金色花枝簪（kanzashi）。

服装与姿势：
一件式长袖和服，深 V 领设计，米色底色上印有大朵红色、橙色和绿色的牡丹图案，系着宽腰带（黑色底配红金花卉图案）和细红色带缔（obijime）。双腿交叠坐在榻榻米上，右手持扇，左手放在右侧榻榻米上。大型鲤鱼、波浪和花卉线条纹身横跨右大腿前景。

背景与光线：
左侧是白色障子门，背景中有灰色花瓶插着花枝、金色推拉门（fusuma）和低矮灯笼。柔和的自然光从左侧障子射入，照亮面部、和服和前景大腿，在右侧背景投下温暖的阴影。

构图与相机：
2:3 竖幅构图，相机位置略高于坐姿人物，拍摄从头顶到交叠双腿的全身特写肖像。上半部分聚焦于面部和折扇，下半部分左前景突出展示纹身的腿部。和服下摆在底部被截断，焦点集中在眼睛和折扇上，背景具有柔和的景深效果。

纹理与风格：
逼真的实拍照片风格。高清呈现自然肌肤质感、丝绸光泽、精细的牡丹图案、编织腰带、折扇的和纸材质、榻榻米纹理以及纹身的细腻线条。整体色调为温暖的日式房间色彩，包括米色、朱红色和墨黑色。

负面提示：
省略折扇和鲤鱼大腿纹身；改变和服和腰带的配色方案
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789891171955_stnqvi_HSbM81cawAAO85v.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 日式房间人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101297254481223763)
- **发布时间:** 2026年9月19日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35054)**

---

### No. 20: 个人资料 / 头像 - GPT Image 2 提示词：温泉白毛巾自拍

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

使用 GPT Image 2 生成一张逼真照片的详细提示词，画面中一位年轻女子裹着白色浴巾在温泉中自拍。

#### 📝 提示词

```
主体：
被温泉灯笼照亮的白色浴巾

主要主体：
从中心到左侧，一位年轻女子正手持相机向自己靠近，用白色浴巾裹住胸部。湿润的皮肤和头发、青绿色的水以及背景中的出水口是主要元素。

角色与表情：
纤细的鹅蛋脸，小下巴，大而深邃的棕色眼睛，细眉毛，鼻梁清晰，微微张开的粉嫩光泽嘴唇。头略微向右倾斜，以平静的目光注视着近距离的相机。湿漉漉的黑褐色头发随意地扎成高发髻，留有薄刘海和散落在脸颊及颈部的长发丝。

服装与姿势：
厚织的白色浴巾以抹胸裙的方式从胸部包裹至大腿，右手抓住胸前右侧以固定浴巾。坐在浴缸边缘，左臂笔直伸向相机进行自拍，右肘弯曲将浴巾紧压在身上。

背景与光线：
右侧是一个装满青绿色水的长方形浴缸，后方是灰褐色的石墙，方形出水口有水流下，旁边放着木桶和小白色毛巾，左侧有一盏方形灯笼，顶部是被照亮的植物。来自左侧灯笼和上方的柔和暖光照亮了脸部、肩膀和水珠，在水面上形成金色倒影。

构图与相机：
3:4 竖构图，手臂伸展的平视特写自拍镜头，捕捉从头顶到胸部下方及一条大腿的上半身。脸部位于左上角且较大，浴巾位于下方中心，浴缸占据右半部分。左臂和大腿在底部边缘被裁剪，焦点集中在双眼和面部，出水口略微模糊。

纹理与风格：
逼真的实拍照片。高清湿润的自然皮肤，细碎的散发，水珠，厚实的白色浴巾，深色石头，透明的水和表面反射，宁静的琥珀色与青绿色温泉夜景。

负面提示：
改变自拍中的白色浴巾和左臂；干燥的头发
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977650237_ci195m_HSbKgBTb0AAD1qZ.jpg" width="600" alt="个人资料 / 头像 - GPT Image 2 提示词：温泉白毛巾自拍 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101272591956840655)
- **发布时间:** 2026年9月19日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35124)**

---

### No. 21: 社交媒体帖子 - AI 写实缩略图：提灯笼的女孩

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张垂直社交媒体缩略图，对比了两名提灯笼女孩的 impressionist 油画与其 photorealistic AI 生成复刻版。

#### 📝 提示词

```
创建一张垂直 9:16 比例的社交媒体缩略图。背景是一张超写实、高分辨率的照片，画面中两名留着棕色卷发的小女孩身穿复古白色蕾丝边连衣裙，站在暮色中的郁郁葱葱的花园里。她们手持并装饰着发光的粉色纸灯笼。周围环绕着大型白色百合花和柔焦粉色玫瑰。在中心位置叠加粗体无衬线文字：“AI Made This Painting”为白色，下一行“Real”为黄色。在文字下方，放置一个较小的矩形插图，展示原始的印象派油画（两名提灯笼的女孩），配有金色画框，并有一个手绘黄色箭头从画作指向写实的场景。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150024233_00ki5y_HS33DZ9aQAAZaBs.jpg" width="600" alt="社交媒体帖子 - AI 写实缩略图：提灯笼的女孩 - Image 1">
</div>

#### 📌 详情

- **作者:** [VideoProc AI](https://x.com/ProcVideo)
- **来源:** [Twitter Post](https://x.com/ProcVideo/status/2102608261904323059#reversed-0)
- **发布时间:** 2026年9月23日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35234)**

---

### No. 22: 社交媒体帖子 - 纸艺揭秘海报

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一款采用分栏布局的设计海报，上半部分为原始照片，下半部分呈现选择性配色的纸艺揭秘效果。

#### 📝 提示词

```
基于此照片创作一张高端设计海报。整体采用 3:4 竖版构图，分为上下两个等大的部分，高度比例为严格的 1:1，各占画面的 50%。

上半部分：保留原始照片，确保主体的身份及所有细节与原图完全一致。

下半部分：在带有纹理的米白色背景上制作逼真的纸艺效果。画面中心应有一个撕裂的纸张破洞，露出上方同一城市场景的黑白版本。关键在于，该黑白场景中的特定元素需以原本鲜艳的彩色（红色、品红、黄色）高亮显示，从而与单色背景形成强烈对比。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150024211_aoqtzb_HS2g9KzXUAACRFc.jpg" width="600" alt="社交媒体帖子 - 纸艺揭秘海报 - Image 1">
</div>

#### 📌 详情

- **作者:** [Kris Kashtanova](https://x.com/icreatelife)
- **来源:** [Twitter Post](https://x.com/icreatelife/status/2102513577437315328#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35233)**

---

### No. 23: 社交媒体帖子 - 喧闹的捕虾人闯入酒馆

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一幅幽默的漫画风格插图，描绘了醉醺醺的渔民冲进酒馆的场景，并配有一首关于他们到来的俳句。

#### 📝 提示词

```
这是一幅横向的数字插画，采用粗犷的漫画风格，描绘了一群喧闹的渔民进入酒馆的场景。画面分为两部分：左侧是艺术作品，右侧是一个包含文字的黑色面板。在艺术作品中，五名表情夸张、满脸通红且醉意盎然的男子正破门而入。他们身穿厚重的蓝色针织毛衣、黄色雨衣和渔夫帽。中间的一名男子手持深色酒瓶，而他右侧的另一人则拿着一个金属酒杯。前景中，两名男子坐在木桌旁抬头看着新来者；左边那位鼻子很大，手里拿着一杯啤酒，右边那位秃顶，穿着蓝色外套。背景展示了灯光昏暗的酒馆内部，挂着灯笼，墙上的框牌写着“THE DRIFTING COD”和“RUM GIN BITTERS & BAD LANGUAGE”。在右侧纯黑背景上，白色衬线字体展示了一首俳句：“the shrimpers / stinking of shrimp and brine / enter the pub / already drunk on bitters / boisterous as stuck pigs”。诗歌下方是较小的署名文字：“AI image created by Michael H. Lester in collaboration with GPT Image 2 Low on @Nightcafestudio twitter: ™mhlester”，随后是两个 URL。右上角有一个二维码。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150027817_zn9mso_HS1pTCAbAAAzpq6.jpg" width="600" alt="社交媒体帖子 - 喧闹的捕虾人闯入酒馆 - Image 1">
</div>

#### 📌 详情

- **作者:** [Michael H. Lester](https://x.com/mhlester)
- **来源:** [Twitter Post](https://x.com/mhlester/status/2102452382345085279#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35239)**

---

### No. 24: 社交媒体帖子 - 雨窗畔阅读的男子

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

电影感镜头：一名身穿深色大衣的男子站在窗前，手持文件专注阅读，窗外雨痕斑驳，城市灯光朦胧。

#### 📝 提示词

```
中景镜头从后方略偏侧的角度捕捉到一名男子站在室内，面向一扇大窗户。他留着灰白的短发，身穿一件深海军蓝色的长款大衣或长袍。他双手捧着一份打开的白色文件或书籍，神情专注地阅读着。窗玻璃上布满了垂直的雨痕，将窗外的景色扭曲成一片抽象的模糊影像，呈现出深邃的蓝色、鲜艳的金黄色以及隐约的红色，暗示着夜晚的城市景象和发光的招牌（其中一个部分可辨认为“...BARBATES...”）。画面左侧，一部分抛光的深色木质镶板构成了场景的边框。底部沿窗台设有一排深蓝色天鹅绒长椅或座位区。整体光线充满情绪感和氛围感，窗外夜晚的冷色调与湿润玻璃上温暖的金色反光形成鲜明对比。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790150024476_e6wj8m_HS07TqYXwAACF_K.jpg" width="600" alt="社交媒体帖子 - 雨窗畔阅读的男子 - Image 1">
</div>

#### 📌 详情

- **作者:** [Juan José Arango E.](https://x.com/jjarangoes)
- **来源:** [Twitter Post](https://x.com/jjarangoes/status/2102401817682293027#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35235)**

---

### No. 25: 社交媒体帖子 - 日落照片转蜡笔画分屏

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个生成对比图像的提示词，将逼真的日落照片与包含日语励志文字的稚拙蜡笔素描复刻作品进行分屏展示。

#### 📝 提示词

```
创建一个垂直分屏构图。上半部分是一张逼真的照片，展示了一个人在日落时分站在沙洲上张开双臂，戏剧性的橙色和蓝色云彩倒映在平静的水面上。下半部分是一幅稚拙的手绘蜡笔或油画棒插图，在白色背景上重现完全相同的场景。在绘画中，使用粗糙、有质感的笔触描绘天空（橙色、黄色、蓝色），并用简单的黑色线条勾勒人物的剪影及其倒影。包含手写日文文字：左侧为大字“きっと、うまくいく。”（一切都会好起来的），右侧为小字“あの夕陽みたいに、今日も、いいほうへ。”（像那夕阳一样，今天也向着美好前行），右下角为带有笑脸的“Good Tomorrow”。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423255_q65b1v_HSzcvPEbEAApAyR.jpg" width="600" alt="社交媒体帖子 - 日落照片转蜡笔画分屏 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423269_x0e83d_HSzcvOwa8AAsSEI.jpg" width="600" alt="社交媒体帖子 - 日落照片转蜡笔画分屏 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423255_wbx6mw_HSzcvPEbwAA3BGd.jpg" width="600" alt="社交媒体帖子 - 日落照片转蜡笔画分屏 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063424148_3h0am9_HSzcvj7bUAAifoo.jpg" width="600" alt="社交媒体帖子 - 日落照片转蜡笔画分屏 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2102298619735138672#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35162)**

---

### No. 26: 社交媒体帖子 - 燕尾服猫照片与线条画双联图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

分屏设计，上方为逼真的燕尾服猫照片，下方为相呼应的极简线条素描及手写引言。

#### 📝 提示词

```
垂直双联构图，分为两个截然不同的部分。上半部分是一张高质量的照片，展示了一只拥有明亮绿色眼睛的黑白燕尾服猫，它将前爪搭在竹制栏杆边缘，背景为纯色的哑光鼠尾草绿。下半部分是在有纹理的奶油色纸张上绘制的极简线条插画。这幅画以细腻的深色墨线描绘了同一只猫相似的姿势。素描周围环绕着手写风格的文字：左侧写着“Same curious eyes a kinder day”，右侧写着“a quieter world is enough”，并配有一个小新月图标。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421387_ppq2r6_HSzbo6obsAAjoKb.jpg" width="600" alt="社交媒体帖子 - 燕尾服猫照片与线条画双联图 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421390_9wg2y9_HSzbo6qaMAAg77h.jpg" width="600" alt="社交媒体帖子 - 燕尾服猫照片与线条画双联图 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421376_7i162j_HSzbp6faIAAgz4w.jpg" width="600" alt="社交媒体帖子 - 燕尾服猫照片与线条画双联图 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063422214_j585w6_HSzbtfjbYAEk4_X.jpg" width="600" alt="社交媒体帖子 - 燕尾服猫照片与线条画双联图 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2102297479773671621#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35159)**

---

### No. 27: 社交媒体帖子 - 极简主义石膏银河艺术

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张采用分割构图的 posters，上半部分为逼真的银河照片，下半部分为黑色背景上极简风格的白色石膏螺旋星系雕塑，并配有阿拉伯语排版。

#### 📝 提示词

```
这是一张垂直双联海报设计，分为两个截然不同的部分。上半部分是高分辨率、照片级真实的银河系图像，以深邃的蓝色和紫色星云、密集的星团以及黑色虚空中的宇宙尘埃云为特色。下半部分是极简主义的影棚拍摄风格，采用纯哑光黑色背景。在下半部分的中心位置，有一个精致的白色石膏雕塑，安装在一根从矩形小底座升起的细金属杆上。该雕塑描绘了一个风格化的螺旋星系或太阳系模型，由同心圆环组成，环上点缀着代表行星和恒星的小球体。在雕塑左侧，优雅的阿拉伯语排版写着“بين النجوم”（意为“群星之间”）作为标题，下方是较小的文字“نفس واحد في اتساع لا نهائي”（意为“无限扩张中的一口气息”）。文字下方有一条短横线。右下角有非常微弱且细小的阿拉伯语文字。整体美学风格宁静、知性且高度精致。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421852_plz3wc_HSzaejEakAEW0I_.jpg" width="600" alt="社交媒体帖子 - 极简主义石膏银河艺术 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421854_9fu4xk_HSzafrvboAAuThl.jpg" width="600" alt="社交媒体帖子 - 极简主义石膏银河艺术 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421827_0ncn0q_HSzahbtbwAAV-Lp.jpg" width="600" alt="社交媒体帖子 - 极简主义石膏银河艺术 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063422541_mdh94m_HSzanQ1aAAAy4Sw.jpg" width="600" alt="社交媒体帖子 - 极简主义石膏银河艺术 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2102296056583335947#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35160)**

---

### No. 28: 社交媒体帖子 - 多洛米蒂湖泊照片转极简艺术

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

生成一张分割图像，上方展示高山湖泊船屋的风景照片，下方呈现与之匹配的极简主义纹理图形海报设计。

#### 📝 提示词

```
垂直分屏构图，将写实摄影与风格化图形插画形成对比。上半部分是意大利多洛米蒂山脉布莱耶斯湖（Lago di Braies）著名船屋的高分辨率风景照，画面中一座质朴的木制高脚船屋矗立在翡翠绿的湖面上，背景是巍峨的山峰和戏剧性的云层。下半部分将该场景转化为极简主义、带有颗粒质感的丝网印刷风格插画，采用深蓝、黑色、珊瑚红和奶油色的有限配色方案。在下半部分，山脉由带有颗粒质感的扁平蓝色色块表示，太阳是一个巨大的粉色圆形，船屋则以纯黑色描绘并配有红色百叶窗。在插画的左侧，有竖排中文文字：'山会记得'、'湖也会记得'，随后是较小的文字'有些地方'和'一直在那里'。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063420879_jz0oqf_HSzZlLjakAAw233.jpg" width="600" alt="社交媒体帖子 - 多洛米蒂湖泊照片转极简艺术 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063420957_3wpjht_HSzaAQkawAAYLQT.jpg" width="600" alt="社交媒体帖子 - 多洛米蒂湖泊照片转极简艺术 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063420951_c4gwa9_HSzaC8va0AA5ybS.jpg" width="600" alt="社交媒体帖子 - 多洛米蒂湖泊照片转极简艺术 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063421816_xbjlt0_HSzaFYYbEAAvp2u.jpg" width="600" alt="社交媒体帖子 - 多洛米蒂湖泊照片转极简艺术 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2102294943255650749#reversed-0)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35158)**

---

### No. 29: 社交媒体帖子 - 日式剪纸日落拼贴

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一幅垂直拼贴作品，将真实的海滨日落摄影与日式剪纸艺术插画及优雅排版相结合，非常适合用于旅行纪念或艺术创作。

#### 📝 提示词

```
创建一幅垂直拼贴风格的图像，结合写实摄影与剪纸插画。上半部分是一张高分辨率的海滨日落场景照片：天空中布满戏剧性的紫色和粉色云彩，金色的太阳正沉入海平线。左侧是延伸入水的岩石海岸线，轻柔的波浪拍打着沙滩。远处的城市灯光沿着海岸线闪烁，水面上隐约可见一艘小船。下半部分是在米色纹理纸背景上的日式剪纸艺术（kirigami）风格插画。该部分包括柔和蓝色和粉色调的分层纸云、由纹理纸制成的圆形橙色太阳、岸边深棕色的撕纸岩石以及精致的白色纸浪。包含优雅的日文排版：左上角是大字文本“やさしい、夜のはじまり”（温柔的夜晚开始），其下方是描述海洋与光线的较小诗意文本，右上角则是关于明日联结的额外文本。使用微妙的投影以在纸张层之间创造深度，保持摄影写实感与手工纸艺之间的审美平衡。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423607_g3uj14_HSwdnMvbQAAXvWy.jpg" width="600" alt="社交媒体帖子 - 日式剪纸日落拼贴 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423795_8khyni_HSwdr_HbQAAsu4j.jpg" width="600" alt="社交媒体帖子 - 日式剪纸日落拼贴 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423611_cbpitf_HSwdtBSa0AEZj2j.jpg" width="600" alt="社交媒体帖子 - 日式剪纸日落拼贴 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063425868_pugwoe_HSwduGDbMAA-a37.jpg" width="600" alt="社交媒体帖子 - 日式剪纸日落拼贴 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2102087832332632517#reversed-0)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35164)**

---

### No. 30: 社交媒体帖子 - 凌乱公寓中绝望的女性

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张写实风格的照片提示词，描绘了一位年轻女性坐在狭小日本公寓的极度杂乱和垃圾堆中，神情焦虑。

#### 📝 提示词

```
一张超写实的广角照片，展示了一间严重杂乱不堪的日本公寓房间。画面中央坐着一位深色头发、扎着凌乱发髻的年轻女性，她身穿舒适的奶油色针织毛衣和粉色图案睡裤。她坐在混乱的地板上，双手抱头，流露出绝望或压力巨大的神情，低头看着一张低矮的木桌，桌上堆满了脏碗碟、杯子、瓶子和一台打开的笔记本电脑。房间里塞满了垃圾：成堆的塑料袋、纸箱（其中一个印有“MUJI”品牌标识）、随处可见的衣服以及覆盖地板的食物容器。左侧有一面镜子，反射出更多的杂物，墙上贴着带有日文文字的手写便签，如“想做的事情”。右侧的白色冰箱上也贴着更多手写便签，包括一份“To Do”清单和一幅猫的简笔画。背景中可见一张床，上面也堆满了毯子和衣服。大窗户透出外面的城市天际线，明亮的外部环境与昏暗、混乱的内部形成鲜明对比。光线自然但略显柔和，强调了这种杂乱无章带来的压迫感。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063424848_e2aawi_HSu0a9maEAA2BaV.jpg" width="600" alt="社交媒体帖子 - 凌乱公寓中绝望的女性 - Image 1">
</div>

#### 📌 详情

- **作者:** [癒音ちー✨ゆおんちー✨癒やし声ASMRとAI](https://x.com/chi_vc_)
- **来源:** [Twitter Post](https://x.com/chi_vc_/status/2101973994622894342#reversed-0)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35163)**

---

### No. 31: 社交媒体帖子 - Madonna & Angels: Oil Painting Meets Paper Cutout

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

Generates a split-image composition contrasting a classical religious oil painting with its whimsical paper-cutout reinterpretation, ideal for artistic storytelling or design inspiration.

#### 📝 提示词

```
A vertical two-panel image. The top panel is a classical oil painting of the Madonna and Child surrounded by three angels in a lush garden setting, with soft natural lighting and rich colors. The bottom panel shows a hand holding a handmade paper cutout version of the same scene, rendered in a delicate watercolor style on textured off-white paper. To the left of the cutout, handwritten blue text reads 'A quieter world for tender things', and to the right, it says 'Music keeps love near'. A small gold star icon appears above the left text, and a green olive branch illustration sits below the right text. The overall aesthetic blends fine art tradition with modern craft sensibility.
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063423640_alj3wv_HSuXdLqbcAAp0TU.jpg" width="600" alt="社交媒体帖子 - Madonna & Angels: Oil Painting Meets Paper Cutout - Image 1">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2101955568781119532#reversed-0)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35161)**

---

### No. 32: 社交媒体帖子 - GPT Image 2 镜面自拍提示词

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

专为 GPT Image 2 优化的详细提示词，用于生成身穿格纹上衣的年轻女性逼真镜面自拍。

#### 📝 提示词

```
主题：
蓝色格纹镜面前景

主要主体：
一位年轻女性在明亮的卧室中拍摄上半身镜面自拍。她身穿浅蓝色与白色相间的格纹露肩上衣、白色短裤，右手高举一部银色智能手机，手机位于画面右上方显著位置。

人物与表情：
纤细的鹅蛋脸，小巧的下巴，圆润的深棕色眼睛，细长的拱形眉毛，精致的小鼻子，光泽感的淡粉色嘴唇。头部微微向右倾斜，面带柔和微笑，透过镜子注视着智能手机区域。留着长波浪深棕色头发，配有薄刘海和侧边发束，脑后系着一条大白色丝带，垂至背部。

服装与姿势：
浅蓝白格纹图案，荷叶边泡泡袖滑落至肩部，胸前有蝴蝶结装饰，短款上衣带有弹性褶皱设计。搭配白色高腰牛仔短裤和白色花朵吊坠。左肩向前，右臂弯曲举过头顶，右手握持一部垂直放置的银色智能手机，手机上饰有小挂件。

背景与光线：
左侧边缘有一面细木框镜子，左后方墙壁上贴有照片并设有小搁板，摆放着香水瓶和绿植；右后方可见白色床品和米色毯子，以及一扇灰色门。清晨强烈的直射阳光从左侧窗户射入，照亮面部、胸部和手臂，在墙壁和床品上形成明亮光斑。

构图与相机：
3:4 竖幅构图，正面相机以胸部高度捕捉镜面反射，展示从头部到大腿的四分之三身体。人物居中且占比大，智能手机位于右上方，镜框位于左侧边缘。右手靠近顶部边缘，大腿底部被裁切，焦点集中在镜中的眼睛和服装上，卧室背景轻微虚化。

纹理与风格：
逼真的实拍照片风格。自然肤质，格纹面料的褶皱与弹性细节，牛仔布、头发及智能手机的高清细节均得到精细呈现，整体色调为清新的晨间白色与淡蓝色。

负面提示：
改变镜面拍摄角度和手机位置；省略蓝色格纹服装
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063419642_f4qceq_HSbieEWbUAAO6Vn.jpg" width="600" alt="社交媒体帖子 - GPT Image 2 镜面自拍提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101934956456845338)
- **发布时间:** 2026年9月21日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35120)**

---

### No. 33: 社交媒体帖子 - 乡村道路生活方式摄影提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

为 GPT Image 2 优化的综合提示词，用于生成两位朋友在乡村道路上的逼真生活方式旅行照片。

#### 📝 提示词

```
创作一张完全原创的 9:16 竖版生活方式旅行照片，灵感源自两位年轻朋友在蜿蜒的乡村道路上俏皮摆拍的概念，周围环绕着开阔的绿色田野和远处的山脉。

场景：

两位不同的年轻成年女性在宁静的山区乡村结伴旅行。一位女性随意地站在路边，另一位则略微蹲下/向镜头倾斜，摆出俏皮的旅行拍照姿势。自然的友谊氛围，自发的度假瞬间，轻松的笑容。

环境：

一条宽阔蜿蜒的沥青路穿过金绿色的草原，背景是连绵起伏的山脉，散落着野花，远处有几匹马和牛，柔和的晨雾，山坡上有零星的小树。景观构图与参考图完全不同。

人物：

两位外貌新颖的女性角色，具有独特的面部特征和发型。

女性 1：齐肩深棕色头发，米色针织毛衣，橄榄绿工装裤，奶油色运动鞋，小号海军蓝斜挎包。

女性 2：长卷发深色头发，芥末黄超大号夹克，浅蓝色阔腿牛仔裤，白色运动鞋，小号棕色背包。

姿势与构图：

全身竖版构图。两位女性位于道路的不同深度，营造出自然的透视感。一人随意行走并回头看向镜头，另一人侧身站立自然大笑。抓拍式旅行摄影，而非摆拍的时尚大片。

视觉风格：

逼真的智能手机旅行摄影，真实的人体比例，自然的皮肤纹理，细微的不完美，真实的织物质感，真实的头发细节，自然日光，柔和的阴天天空，略微柔和的大地色调，纪录片式的度假美学，可信的深度和透视感。

相机参数：

9:16 竖画幅，平视智能手机摄像头，等效 28mm 广角镜头，自然透视，主体清晰且背景细节真实，微妙的摄影颗粒感，无电影级色彩分级。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977639069_1o12c5_HSt4pOUa0AAJYUI.jpg" width="600" alt="社交媒体帖子 - 乡村道路生活方式摄影提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977639052_xsi16k_HSt4p2caYAALqfq.jpg" width="600" alt="社交媒体帖子 - 乡村道路生活方式摄影提示词 - Image 2">
</div>

#### 📌 详情

- **作者:** [Cherry](https://x.com/hey_am_cherry)
- **来源:** [Twitter Post](https://x.com/hey_am_cherry/status/2101906320471556567)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35106)**

---

### No. 34: 社交媒体帖子 - 天堂玻璃平台奢华大片

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个电影感提示词，描绘了一名男子站在云层之上的玻璃平台上，背景是群山，营造出一种天堂般的奢华美学。

#### 📝 提示词

```
超写实电影级奢华摄影作品：一位英俊非凡、二十岁出头的年轻男子自信地站立在悬浮于浩瀚云海之上的透明玻璃平台上。他拥有浓密自然的黑色波浪卷发，眉毛浓密有力，深棕色眼眸深邃迷人，下颌线条轮廓分明，留有细微自然的胡茬，皮肤质感真实，毛孔和面部细节清晰可见。他身穿剪裁精致的优雅米白色西装，搭配奢华丝绸衬衫，配饰极简，整体造型低调而高级。
在他身后，巨大的雪山山脉穿透云层拔地而起，向地平线无限延伸。令人屏息的柔和金色日出照亮了山脉与云朵，形成细腻的光束、微妙的大气雾霭以及环绕主体的神圣光晕。脚下的玻璃平台反射着天空、云朵和温暖的日出光芒，营造出他仿佛伫立于天堂的错觉。
空灵奢华的美学风格，梦幻般的氛围，电影构图，宏伟的尺度，柔和的体积阳光，逼真的云层形态，大气透视效果，自然反射，高端时尚编辑摄影，精致的色彩分级，浅景深，HDR，8K，超高细节，照片级真实皮肤，逼真光照，85mm 镜头，焦点清晰地落在男子身上，令人惊叹的广阔环境，无其他人物，无文字，无水印，无人工痕迹的面部。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063418222_sxf2zr_HStdhHvbMAAVueb.jpg" width="600" alt="社交媒体帖子 - 天堂玻璃平台奢华大片 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2101876484873064463)
- **发布时间:** 2026年9月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35112)**

---

### No. 35: 信息图 / 教育视觉图 - 动漫角色设计表：剑之女王

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一份全面的动漫女英雄角色参考表，包含档案数据、正交三视图、表情变化、服装分解、材质色板及技术说明。

#### 📝 提示词

```
为名为 {argument name="character name" default="RU RIO"} 的动漫风格女性战士创建一张高度详细且专业的角色设计表。布局应在深色背景上划分为不同的区域，使用金色和白色文字。

**左上角（档案）：** 标题为 "CHARACTER PROFILE" 的页眉，配有带翼徽章。下方是大号衬线字体的名字 "RU RIO"，副标题为 "SWORD QUEEN"。包含数据列表：年龄 (22)，身高 (172cm)，职业 (Sword Queen)，所属势力 (The Royal Court of Elysion)，头衔 (Heir to the Radiant Throne)，元素属性 (Light)，武器 (Regal Longsword "Lumina Regalia")。添加一个 "PERSONALITY" 部分，描述她冷静且坚定不移，以及一个 "LIKES/DISLIKES" 部分。以一句引言结尾："A queen's blade shall never waver."

**顶部中央（主图）：** 角色略微仰视的大型高质量半身肖像。她留着黑色短发，灰色眼睛，身穿带有金色细丝装饰和高领的精致银色板甲。

**右上角（三视图与分析）：** 标记为 "ORTHOGRAPHIC TURNAROUND" 的区域，展示角色站立的五个全身视图：正面 (FRONT)、3/4 侧面 (3/4 FRONT)、侧面 (SIDE)、3/4 背面 (3/4 BACK) 和背面 (BACK)。其右侧是一个 "PROPORTIONAL ANALYSIS" 图表，显示带有水平网格线的正面视图，标记头身比例（Head x 1, Head to Chin 等）。

**中间条带（表情）：** 标记为 "EXPRESSION ANCHORS" 的一行，包含八个方形面板，展示角色面部特写及不同情绪：中性 (NEUTRAL)、平静 (CALM)、坚定 (DETERMINED)、骄傲 (PROUD)、温柔微笑 (SOFT SMILE)、甜美微笑 (SWEET SMILE)、关切/处理中 (CONCERN/HANDLING) 和战斗呐喊 (BATTLE CRY)。

**左下角（服装）：** 标题为 "WARDROBE & ACCESSORIES BREAKDOWN" 的部分。它在人体模型上展示全套服装，随后是隔离展示的单品，标签包括：斗篷 (CLOAK)、躯干护甲 (TORSO ARMOR)、护手 (GAUNTLETS)、腿部护甲 (LEG ARMOR)、靴子 (BOOTS)，以及各种小配件如腰带和珠宝。

**底部中央（材质与细节）：** 两行内容。上一行是 "MATERIAL PALETTE"，展示银色钢 (SILVER STEEL)、午夜缎面 (MIDNIGHT SATIN)、浆洗上衣 (STARCHED TOP)、皇家皮革 (ROYAL LEATHER) 和镀金饰边 (GILDED TRIM) 的色样。下一行是 "DETAIL CLOSE-UPS"，展示肩部护肩 (SHOULDER PAULDRON)、胸部装饰 (CHEST ORNAMENT)、大腿绑带与链条 (THIGH STRAP & CHAIN)、大腿竖琴与链条 (THIGH HARP & CHAIN) 以及剑柄细节 (SWORD HILT DETAIL) 的微距镜头。

**右下角（技术）：** 一列 "TECHNICAL NOTES"，列出关于轮廓和面料的要点。在其下方，是一条 "COLOR SCHEME" 带，包含菱形色样。最后，是一个 "RIG & MOVEMENT REFERENCE" 部分，展示角色的三个小型线框/骨架图。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803929368_4sx68a_HShNkaobMAAVI9p.jpg" width="600" alt="信息图 / 教育视觉图 - 动漫角色设计表：剑之女王 - Image 1">
</div>

#### 📌 详情

- **作者:** [GenAIPractice](https://x.com/kkm27889)
- **来源:** [Twitter Post](https://x.com/kkm27889/status/2101015598843220445#reversed-0)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35009)**

---

### No. 36: 信息图 / 教育视觉图 - 民间艺术咖啡馆学习插画

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成垂直编辑故事书插画的提示词，描绘一位女性在咖啡馆学习的场景，融合斯堪的纳维亚民间艺术的简约风格与水彩质感。

#### 📝 提示词

```
将一家安静的社区咖啡馆描绘为极简且富有诗意的日常场景。一位年轻女性独自坐在小圆桌旁，使用打开的 MacBook 学习。画面中仅包含一把简单的椅子、笔记本电脑、一本笔记本、一支笔、一个陶瓷杯，以及隐约可见的咖啡馆窗户或吊灯。保持环境稀疏且扁平化，不要描绘详细的室内建筑结构。

以放松的四分之三侧面视角展示这位年轻女性，身体微微倾向笔记本电脑，一只手靠近键盘，另一只手正在记笔记。她的表情平静、好奇，全神贯注于学习。赋予她简化的孩童般比例、柔和圆润的脸庞、略大的双手、紧凑的几何发型以及自然的坐姿。让她穿着图案开衫、宽松长裤和简约鞋子。笔记本电脑应可识别为轻薄的 MacBook，但不要显示醒目的标志或任何可读的屏幕内容。

装饰性民间平面插画，融入精致极简的水彩速写本艺术。结合斯堪的纳维亚民间艺术的简约、日本绘本的克制感以及现代平面编辑插画风格。将每个人物、物体和家具简化为干净、柔和圆润的几何色块。使用不透明的水粉状形状，并叠加淡淡的半透明水彩渲染。添加松散、不完美的钢笔轮廓，线条粗细轻微波动，偶尔出现断裂边缘、细小划痕、短缝线、圆点和天真手绘图案。绘图必须感觉手工制作、略微不对称、温柔且故意不完美。

使用完全独立于源图像的新鲜调色板：灰紫色、长春花蓝、树莓红、淡柠檬黄、苹果绿、暖可可棕和奶油象牙纸色。不要使用青色、珊瑚橙、芥末黄或深海军蓝作为主导颜色。保持调色板有限且和谐，以紫色或长春花蓝作为主要服装颜色，树莓红和柠檬黄仅作为俏皮的点缀。

纵向构图，比例约为 2:3。使坐着的女性和笔记本电脑成为无可争议的焦点，占据画布约 60% 的空间。使用轻微裁剪的桌子和椅子来固定下半部分。在人物周围保留充足的米白色负空间，特别是在上方和外边缘。主要采用扁平的侧视透视，仅带有轻微的桌面角度。保持视觉层次简单且易于立即阅读。

仅在空白空间中散布少量微小的漂浮元素：四五个圆点、两片微型花瓣、一颗天真的八角星、一小枝叶子和一抹淡淡的薰衣草水彩飞溅。在开衫上添加微小的手绘对勾或种子图案，并在杯子或灯罩上添加简单的扇贝形边缘。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803922062_6s1yze_HSelMxHaEAAT0IW.jpg" width="600" alt="信息图 / 教育视觉图 - 民间艺术咖啡馆学习插画 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803923586_w365m8_HSelN1NbQAA5oNJ.jpg" width="600" alt="信息图 / 教育视觉图 - 民间艺术咖啡馆学习插画 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803922198_267gor_HSelTpIbMAAaqvs.jpg" width="600" alt="信息图 / 教育视觉图 - 民间艺术咖啡馆学习插画 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803923400_oe944n_HSelUUUaAAAOdSR.jpg" width="600" alt="信息图 / 教育视觉图 - 民间艺术咖啡馆学习插画 - Image 4">
</div>

#### 📌 详情

- **作者:** [Simply Ray](https://x.com/kingofdairyque)
- **来源:** [Twitter Post](https://x.com/kingofdairyque/status/2100829530164277695)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34939)**

---

### No. 37: 信息图 / 教育视觉图 - 中秋节排版海报提示词

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

用于生成极简主义、实验性排版海报的提示词，以中秋节为主题，特色为大号无衬线字体和 Gucci 红色点缀。

#### 📝 提示词

```
选取任何未来主义主题，提供核心概念、简短短语和次要辅助注释，并将该主题转化为极度放大的文字或符号主体：第一印象必须强烈，粗体无衬线字形几乎填满整个画面，水平压入布局中，字符主体像结构梁一样占据中心位置，部分被裁剪或溢出，使阅读首先成为一种强烈的形式体验，随后才是阅读边缘处的副标题。背景大部分保持空白，呈现冷色调留白，叠加极细、浅暖色的构图线、基线和垂直栏线；这些线条应看起来像是设计稿中未隐藏的骨架，而非装饰。仅使用高饱和度的橙红色作为主色来承载所有视觉重量，灰色用于小号说明文字，避免多色和渐变。信息模块稀疏地放置在网格交点和边缘：由简单几何角度、圆点和短破折号组成的小图标；标题简短且加粗；正文采用窄栏和浅灰色。整体呈现应具有精确、克制、实验性的排版教育感。字形构建要求低对比度、粗笔画、大开口字怀、平直末端、紧凑字距；标点符号和辅助符号也遵循网格节奏。如果切换到其他书写系统，请保持等效的块状体积、内部/外部空间关系、裁剪压力和水平阅读动势。禁止使用插图背景、阴影、纸张纹理、居中卡片、圆润可爱风格、商业海报灯光效果以及过度拥挤的信息。

——————
主题：{argument name="theme_en" default="Joy"}
宽高比：{argument name="aspect_ratio_en" default="9:16"}
备注：适当融入中秋节元素
字体颜色：{argument name="font_color_en" default="Gucci Ancora Red"}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717708670_l9g6hd_HSaRCE7aEAARvTd.jpg" width="600" alt="信息图 / 教育视觉图 - 中秋节排版海报提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717710254_7tw59m_HSaRC59bYAAXf7B.jpg" width="600" alt="信息图 / 教育视觉图 - 中秋节排版海报提示词 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717710232_2bpdv2_HSaREJmaYAAuJbb.jpg" width="600" alt="信息图 / 教育视觉图 - 中秋节排版海报提示词 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717709660_0jr50w_HSaRFJ4bcAATWUq.jpg" width="600" alt="信息图 / 教育视觉图 - 中秋节排版海报提示词 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2100526246707024323)
- **发布时间:** 2026年9月17日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34929)**

---

### No. 38: 信息图 / 教育视觉图 - 污水处理厂信息图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张详细的工业风格信息图海报，展示了污水处理厂的流程与原理，包含工艺流程图和醒目的排版设计。

#### 📝 提示词

```
创建一张横向信息图海报，解释污水处理厂的工作原理。设计风格为工业风、现代感且高对比度，采用深红、黑、白以及用于水元素的青/蓝配色方案。

**布局与文本元素：**
1.  **左上/居中（标题）：** 顶部横跨大号、粗体、做旧效果的红色中文字符“污水处理厂”。其下方为大号黑色粗体文字“工作原理”。再下方为较小的黑色文字：“从进水、分离、生化反应到净化出水”。
2.  **左侧边栏：** 垂直布局，包含小文本块。顶部文本块：“让每一滴污水重回自然”，“水的下一站是更洁净的未来”，英文文本“CLEANER WATER BRIGHTER TOMORROW”。底部文本块（红色背景）：“处理改变为了更好的水环境”，英文文本“CLEAN CYCLE HEALTHY CITIES”。
3.  **右侧（背景图像）：** 大型摄影拼贴画，展示充满蓝绿色水的圆形澄清池的鸟瞰图，由管道和走道连接。右侧叠加文本：“从污水到清水”，“连接城市与更健康的生活”，“FOR A CLEANER TOMORROW”，“水循环 城市运行 与自然共生”，“净化 让城市更有生命力”，“CLEAN WATER STRONGER CITIES”。
4.  **底部居中（流程图）：** 示意图横截面，展示水流经不同阶段的过程。箭头指示从左到右的方向。各部分上方标签：“格栅 / 沉砂”，“初沉”，“生化反应”（以气泡描绘），“二沉”。两端标签：左侧为“进水”，右侧为“出水”。
5.  **右下角：** 小文本块：“更干净的水 更宜居的城市 更可持续的明天”，英文文本“CLEANER WATER HEALTHIER CITIES A BRIGHTER TOMORROW”。
6.  **中心红框：** 一个包含白色文字的小红色方块：“看不见的工程 支撑看得见的美好生活”，英文文本“INFRASTRUCTURE FOR A HEALTHIER TOMORROW”。

**视觉风格细节：**
*   在整个图像上使用颗粒质感叠加层，以营造印刷纸张的感觉。
*   中文字体的排版应使用厚重的无衬线字体。
*   照片和图表中的水应在灰度/红/黑背景下呈现独特的青色/蓝绿色。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789458733276_rp96yq_HSMGlTdaoAAEKuS.jpg" width="600" alt="信息图 / 教育视觉图 - 污水处理厂信息图 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789458733214_u53ggv_HSMIL5fbcAA6R70.jpg" width="600" alt="信息图 / 教育视觉图 - 污水处理厂信息图 - Image 2">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2099530880842879182#reversed-0)
- **发布时间:** 2026年9月14日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34687)**

---

### No. 39: 信息图 / 教育视觉图 - GPT Image 2 极简主义仪式感海报提示词

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)

#### 📖 描述

专为 GPT Image 2 设计的详细提示词，用于生成兼具仪式感与理性美学的极简主义高审美海报。该提示词明确了布局、排版、色彩运用及负面约束条件，旨在实现博物馆般的留白效果。

#### 📝 提示词

```
围绕任意给定主题创建一张极简主义仪式信息海报。第一印象必须是大面积的暖白色空白区域，主标题精确居中，并与三个主题符号形成庄重的对齐关系：将主题提供的核心名称、参与者或关键词转化为顶部的大号细笔画标题、中心的一组可识别抽象标志以及两侧的纯色块；语义可以变化，但顺序保持不变。保留高比例留白、垂直中轴线、上下分区以及细黑水平线带来的停顿感；像展览目录或国际机构年鉴那样克制地排列所有元素。正文使用高对比度的精细衬线体或等效字形结构，具有开阔的字腔、纤细的笔画、锐利的终端和宽敞的节奏，在切换到任何书写系统时保持纤细的骨架、宽松的字距、清晰的辨识度和平静的呼吸感，而不是复制特定的拉丁字体。从主题中提取两种高纯度的代表色作为硬边正方形；中心标志仅使用黑色线条和最简几何图形；背景保持略带纸张纹理的暖白色，避免渐变、阴影和装饰性纹理。副标题和小号说明文字置于底部较低的重心位置，页脚微信息紧贴边缘，营造出宏大主题被博物馆式留白驯服的对比感；失败的症状包括元素拥挤、色彩混乱、字体过粗、写实图标或海报失去冷峻的仪式秩序。

将主题设定为“城市公共图书馆开放日”，用于公共文化机构活动的主海报：使用靛蓝色和朱砂红作为两种高纯度方块颜色；中心用黑色线条绘制抽象的打开书页和门拱，让符号组沿垂直轴稳定落在标题下方；主标题置于上半部分中央，副标题和日期在下方形成稀疏的两级信息层级，保留大面积暖白色留白和细黑线停顿；纵横比为垂直 3:4。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789388939731_hkt6p3_HSHLijVaQAAJZkh.jpg" width="600" alt="信息图 / 教育视觉图 - GPT Image 2 极简主义仪式感海报提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789388939778_v4qjhb_HSHLkKYbcAEjISS.jpg" width="600" alt="信息图 / 教育视觉图 - GPT Image 2 极简主义仪式感海报提示词 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789388939994_1deokd_HSHLlYhbkAAf3lE.jpg" width="600" alt="信息图 / 教育视觉图 - GPT Image 2 极简主义仪式感海报提示词 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789388940538_7bmbsi_HSHLn0raYAA68sK.jpg" width="600" alt="信息图 / 教育视觉图 - GPT Image 2 极简主义仪式感海报提示词 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2099183233166614915)
- **发布时间:** 2026年9月13日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34648)**

---

### No. 40: 信息图 / 教育视觉图 - UGC 风格营销面板网格

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个结构化提示词，用于为营销活动创建 3x3 网格的逼真 UGC 风格面板，包含电影级视觉效果和制作说明的空间。

#### 📝 提示词

```
使用 GPT Image 2 创建一个 3x3 的全页网格，展示此 {argument name="category" default="便利店"} 的逼真 UGC 风格面板。将视频分为 3 个连续部分。每个面板必须包含一个电影级视觉画面，以及直接印在面板内的清晰制作说明。目标不仅仅是展示产品，而是帮助客户构思购买理由。企业名称为 {argument name="business name" default="Zioraa Ventures"}。将企业名称嵌入背景中。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789199147235_45scrj_HR8Lt6TXYA4qfTB.jpg" width="600" alt="信息图 / 教育视觉图 - UGC 风格营销面板网格 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789199147395_7rxhrz_HR8LyD0a8AAEPZB.jpg" width="600" alt="信息图 / 教育视觉图 - UGC 风格营销面板网格 - Image 2">
</div>

#### 📌 详情

- **作者:** [Olatunde AI](https://x.com/OlatundeAI)
- **来源:** [Twitter Post](https://x.com/OlatundeAI/status/2098409803273879657)
- **发布时间:** 2026年9月11日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34464)**

---

### No. 41: 信息图 / 教育视觉图 - 金鹿晨曦羊毛毡艺术转化

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

创建一个分屏场景，对比一张雾气缭绕的金色森林鹿群照片与一幅极简主义羊毛毡插画。

#### 📝 提示词

```
目标：创建一个双面板水平对比图像，展示从写实自然照片到极简主义羊毛毡插画的转化。

画布：16:9 宽屏画布，垂直平分为左右两等份，中间有清晰的直线分割。

左侧面板：一张写实的黄金时刻森林草地照片。前景中准确展示 5 只鹿：最左侧 1 只正在行走，左中 1 只正在吃草，正中 1 只正在吃草，中右侧 1 只小鹿直立，最右侧 1 只较大的鹿站立。草地上覆盖着带露水的绿草，伴有温暖的黄色阳光和柔和的晨雾。背景中，深色的常绿树木形成浓密的森林剪影，右上角有额外的枝叶。强烈的阳光从右上角斜射穿过树林，营造出宁静的电影感氛围。

右侧面板：同一场景的柔和手工羊毛毡重新演绎，背景为温暖的米白色纹理纸，留有充足的空白。将羊毛毡场景水平居中于中上方区域。展示 5 只与左侧面板布局完全对应的小羊毛毡鹿：最左侧 1 只站立的鹿，左中 1 只吃草的鹿，正中 1 只橙棕色吃草的鹿，中右侧 1 只直立的小鹿，以及最右侧 1 只较大的站立鹿。将它们放置在一条细长的浅绿色毛毡草地上。在它们上方，加入一个简单的圆形毛毡太阳和 2 片柔和的水平毛毡云朵。在毛毡草地下方，添加手写文字 {argument name="caption text" default="A kinder morning ♡"}，字体采用精致的灰褐色手写体。

视觉风格：结合温暖治愈的美学、充足的留白、舒适的羊毛毡质感、柔和的边缘、柔和的大地色调以及宁静诗意的氛围。左侧应呈现摄影感和氛围感；右侧应呈现带有可见纤维和极简构图的手工毛毡插画感。

约束条件：保持分屏布局，每侧恰好 5 只鹿，不得有额外动物，无边框，无水印，除标题外不得添加任何额外文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113125214_ig0i2n_HR4JccraIAAUu8D.jpg" width="600" alt="信息图 / 教育视觉图 - 金鹿晨曦羊毛毡艺术转化 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113125220_aus41n_HR4JcbDbsAADPa5.jpg" width="600" alt="信息图 / 教育视觉图 - 金鹿晨曦羊毛毡艺术转化 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113125229_gmn3qk_HR4JcbJawAAdJlM.jpg" width="600" alt="信息图 / 教育视觉图 - 金鹿晨曦羊毛毡艺术转化 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113127477_m8tok2_HR4JcbKbUAA5NjV.jpg" width="600" alt="信息图 / 教育视觉图 - 金鹿晨曦羊毛毡艺术转化 - Image 4">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2098125338484342869#reversed-0)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34333)**

---

### No. 42: 信息图 / 教育视觉图 - Technical Product Infographic Overlay

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

Generates a professional technical infographic with blueprint-style overlays, including dimensions and diagrams for product design visualization.

#### 📝 提示词

```
Premium technical infographic of {argument name="product" default="[Apple 18 pro ]"}. Use the reference image only to understand the shape and structure of the object, without copying the same photo, angle, composition, or background. Reinterpret the subject in a new professional and realistic photograph, clean and well-lit, with a suitable and more aesthetic background. Keep the object as a real photo, not an illustration. Add a technical blueprint-style overlay with white lines, arrows, dimensions, labels, and small diagrams of parts, materials, measurements, and functionality. Clear, elegant, and informative composition. Include a sketch box in the upper left corner with the title "{argument name="title" default="[Apple 18 pro]"}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113111185_qdhjmx_HR1UG5dboAEUYF1.jpg" width="600" alt="信息图 / 教育视觉图 - Technical Product Infographic Overlay - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113111179_aehk7i_HR1UG5UbEAAD7eg.jpg" width="600" alt="信息图 / 教育视觉图 - Technical Product Infographic Overlay - Image 2">
</div>

#### 📌 详情

- **作者:** [Al-Shamus](https://x.com/im_shahid7)
- **来源:** [Twitter Post](https://x.com/im_shahid7/status/2097925502493508013)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34210)**

---

### No. 43: 信息图 / 教育视觉图 - Research Paper Academic Poster

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

A prompt to transform an attached research paper into a professional academic poster following specific conference regulations.

#### 📝 提示词

```
Research the poster regulations for presentation at the {argument name="conference name" default="2026 Neuroscience Conference"} and transform the attached paper into a poster accordingly.
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789029055465_961vg3_HR0qIogbQAAO5DF.jpg" width="600" alt="信息图 / 教育视觉图 - Research Paper Academic Poster - Image 1">
</div>

#### 📌 详情

- **作者:** [Daichi Konno / 紺野 大地](https://x.com/_daichikonno)
- **来源:** [Twitter Post](https://x.com/_daichikonno/status/2097880100587135480)
- **发布时间:** 2026年9月10日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34145)**

---

### No. 44: 信息图 / 教育视觉图 - 3D Diagrams and Visual Layouts

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

A comprehensive prompt setup to generate clean 3D graphic design layouts, informational diagrams, and matte-texture presentation slides.

#### 📝 提示词

```
You are an information editor, diagram designer, and 3D art director.
- Compare 3 visual proposals matching the content, and adopt the most intuitive option.
- Explain using objects or materials specific to the subject. Use books, bamboo slips, or paper for classical literature; parts or assembly for manufacturing.
- Elegant matte materials, soft lighting, and natural depth. Use 3D representations to convey sequence, relationships, and changes.
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789029059595_eeotu5_HRz-Q5LasAAI4Qh.png" width="600" alt="信息图 / 教育视觉图 - 3D Diagrams and Visual Layouts - Image 1">
</div>

#### 📌 详情

- **作者:** [あきらパパ【生成AI活用エンジニア&３児のパパ】](https://x.com/akira_papa_IT)
- **来源:** [Twitter Post](https://x.com/akira_papa_IT/status/2097832162586407176)
- **发布时间:** 2026年9月9日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34148)**

---

### No. 45: 信息图 / 教育视觉图 - 爆炸式透明人工心脏

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一种电影级的生物工程产品可视化效果，展示了带有爆炸式组件和技术标注的透明人工心脏。

#### 📝 提示词

```
目标：创作一张超写实的未来医学工程可视化图像，展示一颗爆炸式透明人工心脏，呈现出高端生物工程产品渲染效果，并配有技术标注。

画布：4:3 横向图像，深色实验室背景，光面黑色反射地板，电影级轮廓光，浅景深，冷蓝色高光与暖琥珀色内部辉光。心脏悬浮在地面中心上方，下方带有柔和的倒影。

主体：一颗透明的生物力学解剖心脏，标注为 {argument name="device concept" default="下一代生物工程人工心脏"}。心脏主体由透明的类玻璃生物相容性聚合物制成，可见内部管道、阀门、微流控通道、电路走线、微型机械泵、红色与蓝色发光血管通路以及琥珀色照明的电子模块。使用逼真的折射、焦散、铬合金螺丝、抛光金属环和黑色碳纤维结构组件。

爆炸式布局：在心脏中心周围精确展示 13 个主要的独立组件组：1 中心透明心脏腔室；2 左侧外部透明弧形外壳；3 左侧黑色碳纤维肋板；4 左侧内部透明弧形支撑层；5 左上主动脉连接环组件；6 上方中央透明主动脉及血管塔；7 右上肺动脉连接环组件；8 右侧圆柱形端口及接口环；9 右侧黑色碳纤维肋板；10 右侧带有琥珀色辉光的透明电路接口模块；11 右侧外部透明弧形外壳；12 最右侧小型透明盖/透镜；13 围绕爆炸部件排列的多个小型悬浮螺丝和螺栓。保持所有部件悬浮在精确的水平层中，如同为了检查而拆解开一样。

技术标注：添加细白/灰色引导线和小型大写科幻字体。包含 7 个可见标注标签：1 “AORTA”（主动脉），副标题“HIGH-FLOW / BIOCOMPATIBLE / POLYMER”（高流量 / 生物相容性 / 聚合物）；2 “RIGHT ATRIUM”（右心房），副标题“MICRO-FLUIDIC / CHANNELS”（微流控 / 通道）；3 “CARBON-FIBER RIB STRUCTURE”（碳纤维肋骨结构），副标题“ULTRA-LIGHT / HIGH-STRENGTH”（超轻 / 高强度）；4 “VENTRICLE”（心室），副标题“BIO-MIMETIC / PUMP CHAMBER”（仿生 / 泵腔）；5 “PULMONARY ARTERY”（肺动脉），副标题“PRESSURE REGULATING / VALVE”（压力调节 / 阀门）；6 “BIO-CIRCUIT INTERFACE”（生物电路接口），副标题“NEURAL SYNC / WIRELESS POWER / REAL-TIME MONITORING”（神经同步 / 无线供电 / 实时监控）；7 “MICRO-FLUID CHANNELS”（微流控通道），副标题“NANO-SCALE / SELF-CLEANING / FLOW OPTIMIZATION”（纳米级 / 自清洁 / 流量优化）。将这些标签放置在心脏周围，且不遮挡关键细节。

页脚文字：左下角为小型间距字体，内容为 {argument name="left footer text" default="HUMANITY\nA STRONGER TOMORROW"}（人类\n更强大的明天）。右下角添加一个微小的示意性线条图标和文字 {argument name="right footer text" default="BIOENGINEERING\nFOR A HEALTHIER WORLD"}（生物工程\n为了更健康的世界）。

视觉风格：超精细写实 3D 渲染，奢华工业设计，透明医疗设备，碳纤维纹理，铬合金五金，玻璃折射，发光的红蓝管道，琥珀色电路灯光，高对比度，简洁的未来感界面字体，技术图表美学，8k 画质。

约束条件：无人像，无手部，无血液或血腥内容，无卡通风格，无杂乱背景，无超大标题。保持解剖结构可识别为人类心脏，同时强调透明的未来工程感。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942342761_m4dngg_HRwADcWaIAIUvtu.jpg" width="600" alt="信息图 / 教育视觉图 - 爆炸式透明人工心脏 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942342793_hfdjgv_HRwADcWaIAAHxKJ.jpg" width="600" alt="信息图 / 教育视觉图 - 爆炸式透明人工心脏 - Image 2">
</div>

#### 📌 详情

- **作者:** [关木](https://x.com/ZeroZ_JQ)
- **来源:** [Twitter Post](https://x.com/ZeroZ_JQ/status/2097551650156368331#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34024)**

---

### No. 46: 信息图 / 教育视觉图 - AI 产品草图转台灯渲染图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个照片级真实感的摄影棚场景，展示了将手绘产品草图转化为成品陶瓷台灯的 AI 工作流。

#### 📝 提示词

```
创建一个整洁、照片级真实感的产品设计工作区场景，展示 AI 辅助从草图到成品的转化过程。使用 16:9 的宽幅画布，配以柔和的自然日光、淡薄荷绿墙面、窗光投下的写实阴影，以及现代化的创客工作室美学。在左侧，放置一张竖立在蓝色网格切割垫上的粗糙灰白色纹理绘图纸，顶部用一小条橙色胶带固定；纸上展示了一张 {argument name="product type" default="蘑菇形陶瓷台灯"} 的详细石墨结构草图，包括垂直和水平辅助线、圆顶灯罩、短灯颈、圆润的球形底座、阴影排线以及地面投影。草图前方放置 2 件绘图工具：一支斜放的黑色铅笔和一块白色长方形橡皮擦。在画面中央，添加半透明的未来感 UI 可视化效果：从左至右排列 4 块半透明玻璃面板，每块面板展示台灯从粗糙草图到精细渲染再到简化 3D 形态的演变过程，带有淡青色轮廓和微妙的蓝色光晕。添加 3 个界面叠加层：左下角一个带有三个水平滑块控件的圆角矩形，右上角一个围绕圆顶预览的矩形裁剪/选择框，以及一个指向台灯演变过程的亮蓝色发光光标箭头。在右侧，将最终的 {argument name="product color and material" default="光泽暖白色陶瓷"} 成品台灯放置在一个长方形斑点石材平台上：平滑的半球形圆顶灯罩、小型黄铜灯杆、灯罩下柔和发出的暖光，以及与草图相呼应的圆润球形底座。场景周围布置工作室道具：左上角和右上角隐约可见的绿叶植物，最右侧放有画笔的白色杯子，右下角一个装有红橙色块的小圆托盘，以及左下角堆叠的样本项目或笔记本。蓝色切割垫应覆盖桌面并显示精确的网格线，以强化设计原型制作的环境感。画面中无可见文字、无 Logo、无水印；强调通过透明的 AI 编辑层将手绘草图转化为成品这一概念。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942339417_gggsxx_HRvqeLvbUAAQOKg.jpg" width="600" alt="信息图 / 教育视觉图 - AI 产品草图转台灯渲染图 - Image 1">
</div>

#### 📌 详情

- **作者:** [AI产品第一打假](https://x.com/ManuTrrsCmps10)
- **来源:** [Twitter Post](https://x.com/ManuTrrsCmps10/status/2097527875318464917#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34019)**

---

### No. 47: 信息图 / 教育视觉图 - 日式走廊窗户详图图纸

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

基于参考图生成简洁的日式建筑详图，重点展示推导出的走廊窗户剖面、立面及局部构造细节。

#### 📝 提示词

```
以 REFERENCE_0 作为建筑参考源，将其重组为一张更简洁、更聚焦的日式走廊窗户构造技术图纸。保持原有的主题和手绘建筑插图风格，但简化页面布局，并将构造细节重绘为推导出的测量详图，而非宽泛的说明性项目。

目标：创建一张详细图纸，标题为 {argument name="main title" default="廊下 窓まわり詳細図"}，副标题为 {argument name="subtitle" default="(断面図・展開図・部分詳細図)"}。将所有尺寸视为基于参考图/照片的估算值，并注明单位为 {argument name="unit note" default="mm"}。

布局：使用精确的 4 个绘图区域：左侧为 1 个大型 A-A 剖面详图，右上角为 1 个室内立面图，右下角为 2 个小型局部构造图。以左侧剖面为视觉中心，并在其顶部包含一个小型的索引平面图/剖面标记。

左侧主剖面：以 S=1/10 的比例重绘走廊窗户剖面，要求构造层次清晰，并使用橙色尺寸线。左侧显示室外绿植和室外地面，中间为高木窗框/玻璃开口，右侧为室内走廊侧。标注内容包括：室外侧、室内侧、天花板、钢柱、木窗框、双层玻璃、砖窗台/窗基、砖砌外墙、角钢/托架、楼板构造、现有钢筋混凝土板/基础、GL ±0 和 FL ±0。强调估算尺寸，包括开口高度约 2100、窗基约 300、砖砌高度 180、砖台宽度 350、室外通道约 600、墙体 100、窗台/长凳 350 以及走廊宽度约 1200。

右上角图纸：创建室内立面图，标注为 {argument name="elevation label" default="内観立面図（廊下側） S=1/50"}。展示走廊侧的窗墙，包含重复的垂直木框、玻璃窗格、砖砌/长凳基座、钢柱、透过玻璃可见的室外绿植，以及橙色的 A-A 剖面标记。

右下角细节：添加 2 个标注为 a 和 b 的局部构造图：a. 上部/窗楣细节，展示天花板、石膏板基层/涂料饰面、木窗框和双层玻璃；b. 下部/窗台细节，展示砖饰面、砂浆基层、砖支撑以及角钢加托架，并标注橙色尺寸 350、约 300 和 180。

风格与约束：保持参考图简洁的日式建筑表现风格：细黑色线条、浅灰色填充、柔和的木材和砖块色调、橙色尺寸标注、白色背景、精确的引出线，以及专业的测量图外观。在指定位置使用日文技术标签，但避免过于拥挤。在底部添加注意事项 {argument name="caution note" default="※寸法は写真からの推定です。実施設計時は現地調査のうえ決定してください。"}。不要添加无关的照片、室内人物、装饰性图标或额外的绘图面板。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942349584_8zjz43_HRvlECqboAAplOX.jpg" width="600" alt="信息图 / 教育视觉图 - 日式走廊窗户详图图纸 - Image 1">
</div>

#### 📌 详情

- **作者:** [KOBATAKA｜Vibe Modeling](https://x.com/shion_takk)
- **来源:** [Twitter Post](https://x.com/shion_takk/status/2097523271302599071#reversed-1)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34031)**

---

### No. 48: 信息图 / 教育视觉图 - 忠实复刻日本政策信息图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

根据参考图像，创建一张清晰且高度还原的日本政府风格密集型政策信息图。

#### 📝 提示词

```
仅以 REFERENCE_0 为唯一来源，将日本霞关风格的政策信息图忠实复刻为清晰、高分辨率的 16:9 Slides。尽可能保留原始的整体布局、密集的信息结构、蓝色标题栏、黄色/红色强调带、箭头、标注框、插图化的景观/商业图标以及所有可见的日语标签。通过使图像更清晰、更明亮、减少压缩并提高可读性来优化输出，使用更整洁的矢量风格文本框和更清晰的小型插图，同时保持与官方政府演示文稿相同的密集美学。保留顶部标题文本为 {argument name="headline text" default="地域循环共生圈（日本发起的脱碳与 SDGs 构想）"}，保留版本标签为 {argument name="version label" default="Ver. 26"}，并保留主要中心标签 {argument name="central concept label" default="地域循环共生圈"}。请勿简化图表，请勿使其现代化，请勿删除小标签，也不要添加任何新的品牌标识、水印、人物或不相关的装饰元素。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942377632_6gt3fh_HRvZeQ7aoAAhJQp.jpg" width="600" alt="信息图 / 教育视觉图 - 忠实复刻日本政策信息图 - Image 1">
</div>

#### 📌 详情

- **作者:** [チャエン | デジライズ CEO《重要AIニュースを毎日最速で発信⚡️》](https://x.com/masahirochaen)
- **来源:** [Twitter Post](https://x.com/masahirochaen/status/2097509616989143355#reversed-2)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34068)**

---

### No. 49: 信息图 / 教育视觉图 - ChatGPT 安史之乱信息图截图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一张逼真的 ChatGPT 移动端截图，展示关于安史之乱的详细中文教育信息图。

#### 📝 提示词

```
目标：创建一张逼真的 ChatGPT 对话垂直手机截图，展示一张由 AI 生成的关于 {argument name="topic" default="安史之乱"} 的中国历史信息图。

画布：576 × 1024 纵向手机屏幕，简洁的 iOS 风格白色界面，高分辨率截图质感，带有柔和阴影和圆角 UI 元素。

顶部状态栏与导航：显示 iPhone 状态栏，包含 5 个可见状态项：时间“8:47”、一个小型的用户/个人图标、带有微小橙点的黑色灵动岛 (Dynamic Island)、蜂窝网络/Wi-Fi 指示器，以及显示“16”的电池图标。下方显示 3 个悬浮导航控件：左侧带有蓝色通知小点的圆形汉堡菜单按钮、右侧包含编辑/撰写图标的圆角胶囊按钮，以及一个三点菜单图标。

聊天布局：在顶部右侧放置一个浅蓝色用户消息气泡，内含以下中文文本：“生成图片：全面讲一讲\n安史之乱”。下方展示一张圆角生成的图片卡片。在卡片左下方添加 2 个小型操作图标：分享/上传图标和省略号图标。在生成图片卡片的右下角添加一个白色圆形分享按钮覆盖层。

生成图片卡片内容：该卡片是一张关于安史之乱的密集型横向中文教育信息图海报。采用古朴的羊皮纸和水墨历史风格，配有深红色章节标题、米色纸张背景、风化边缘，以及顶部引人注目的横幅画，描绘燃烧的唐朝城市、烟雾、士兵、旗帜和深色马匹剪影。左上角为大型毛笔书法标题：“安史之乱”。包含一个关于唐朝由盛转衰这一重大转折点的小型副标题。所有信息图文本均保持为中文，并确保大部分清晰可读。

信息图板块：海报中需包含 9 个可见内容板块：1) “什么是安史之乱？”说明性文本块；2) “主要人物”行，包含 5 个插画肖像人物，分别标注为安禄山、史思明、唐玄宗、唐肃宗和杨贵妃；3) “叛乱的原因”列表，包含 4 个带编号的起因；4) “叛乱的过程”垂直时间轴，包含 6 个标注日期的里程碑；5) 中央的“叛乱形势图”，展示唐朝中国地图，并用红黑箭头标示叛军与朝廷军队的动向；6) “重要战役与事件”栏，包含 4 个缩略战役/事件图像；7) “叛乱的影响”板块，包含 4 个图标加文本的影响项；8) “历史意义”板块，包含 3 个图标加文本的意义项；9) “后世评价”板块，包含 3 个引用卡片。底部添加一行中文口号，如“以史为鉴，方知兴替。”，并在底部边缘配以灰度战场剪影。

底部输入栏：在手机截图底部，显示 ChatGPT 消息输入框，为一个圆角白色胶囊，包含 4 个元素：加号图标、灰色占位符文本“询问 ChatGPT”、麦克风图标以及一个蓝色圆形声波按钮。

视觉风格：现代 ChatGPT 移动端 UI 与细节丰富的中国历史信息图相结合。截图应呈现出真实的移动应用截屏质感，带有白色边距、微妙的投影、圆角，且无任何外部水印。

约束条件：不要添加额外的聊天消息。确保信息图完整包含在圆角图片卡片内。保留指定位置的中文文本。使用准确的唐朝历史视觉元素，避免奇幻元素。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942336326_nitsar_HRvHdzDaAAAiunu.jpg" width="600" alt="信息图 / 教育视觉图 - ChatGPT 安史之乱信息图截图 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942336347_1nfb9s_HRvHdy-bwAAXSzp.jpg" width="600" alt="信息图 / 教育视觉图 - ChatGPT 安史之乱信息图截图 - Image 2">
</div>

#### 📌 详情

- **作者:** [Kin](https://x.com/KinGao476942)
- **来源:** [Twitter Post](https://x.com/KinGao476942/status/2097489377173901591#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34016)**

---

### No. 50: 信息图 / 教育视觉图 - 放大镜下的建筑剖面图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个电影级写实提示词，用于生成透过雨中放大镜观察的九层建筑标注剖面图。

#### 📝 提示词

```
目标：创作一个电影级写实建筑剖面场景，通过手持放大镜观察一座玻璃公寓楼，并带有逐层标注。

画布：横向 4:3 图像，超精细的雨后日落傍晚城市景观。一座现代玻璃建筑矗立在水滨，旁边是倒映着天空的河流或湖泊，远处是天际线，地平线附近有温暖的橙色太阳，蓝色的风暴云，左侧有一道淡淡的彩虹。

主体构图：在极近的前景中，一只人手在画面右侧边缘握着一个大型圆形放大镜。镜片占据了画面中心，焦点清晰，边缘有可见的畸变，玻璃上有许多雨滴。在放大镜圆圈内，前方的建筑被清晰放大，展现出透明的九层横截面，可以看到里面的人、家具和温暖的室内灯光。镜片外，相同的建筑和城市略显柔和且未被放大，以此强调光学效果。水面倒影、湿润的岩石、植物以及清澈浅滩附近的一些小鱼出现在画面底部。

建筑细节：水边一栋高大的现代钢结构玻璃长方形建筑，底部由柱子支撑，室内灯光呈暖黄色，墙壁透明。准确展示 9 个堆叠的可见楼层，每一层都是一个独特的房间或活动场景，并配有微小写实的人物。

楼层标签与标注：从房间引出细细的白色引导线，连接到放大镜内或侧面右侧整洁的白色文字。请包含以下 9 个楼层标签，从上到下依次为：
1. “9F · Rooftop Garden”（9 层 · 屋顶花园），副标题“Tea under string lights · Evening sky”（灯串下的茶会 · 傍晚天空）；展示人们坐在露天屋顶露台的植物和灯串之间。
2. “8F · Lounge”（8 层 · 休息室），副标题“Friends talking · Warm ambient lights”（朋友交谈 · 温暖的环境光）；展示一个舒适的社交休息室，配有沙发和聊天的人群。
3. “7F · Workshop Lab”（7 层 · 工作室实验室），副标题“Careful inspection · Tools neatly arranged”（仔细检查 · 工具摆放整齐）；展示一个创客工作室，配有货架、工具和在工作台前忙碌的人。
4. “6F · Child's Room”（6 层 · 儿童房），副标题“Story time · Toys on the floor”（讲故事时间 · 地上的玩具）；展示一个温馨的儿童房，有一名大人和孩子，玩具散落在地上。
5. “5F · Mini Gym”（5 层 · 迷你健身房），副标题“Treadmill run · Evening workout”（跑步机跑步 · 晚间锻炼）；展示健身器材，一人在跑步，另一人在锻炼。
6. “4F · Reading Room”（4 层 · 阅读室），副标题“Quiet notes · Bookshelves and desk lamp”（安静笔记 · 书架和台灯）；展示书架、书桌、台灯和一名坐着阅读的人。
7. “3F · Design Office”（3 层 · 设计办公室），副标题“Team discussion · UI review in progress”（团队讨论 · UI 评审进行中）；展示一个小型的办公室会议场景，配有屏幕和一个蓝色的项目板。
8. “2F · Artist Studio”（2 层 · 艺术家工作室），副标题“Painter at work · Large canvas by the window”（画家工作 · 窗边的大画布）；展示一名艺术家在大型画布上作画，配有艺术用品和画架。
9. “1F · Family Kitchen”（1 层 · 家庭厨房），副标题“Cooking dinner · Steam and warm light”（烹饪晚餐 · 热气与暖光）；展示家人在餐桌/厨房旁，配有发光的灯具和蒸汽。

视觉风格：写实、电影感强、景深丰富、室内暖光与室外冷蓝色调形成对比、逼真的雨滴、倒影、放大镜折射、锐利的微观细节、微缩比例的写实人物、高级建筑可视化质量。

文本限制：标注文字必须清晰可辨，白色，现代无衬线字体，在右侧垂直对齐，配有细白色指针线。所有标签请保持英文。不要添加额外的楼层、额外的标签、Logo、水印或不相关的文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942325589_7wku2y_HRvEouRaIAA8Fcr.jpg" width="600" alt="信息图 / 教育视觉图 - 放大镜下的建筑剖面图 - Image 1">
</div>

#### 📌 详情

- **作者:** [关木](https://x.com/ZeroZ_JQ)
- **来源:** [Twitter Post](https://x.com/ZeroZ_JQ/status/2097486264417259962#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34001)**

---

### No. 51: YouTube 缩略图 - 雨夜机库中的巨型 MPD 机器人

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张超写实的图像，展示了一台巨大的日本警用机甲在暴雨中伫立于车库内，背景可见东京地标。

#### 📝 提示词

```
这是一张具有电影质感的超写实广角镜头，画面主体是一台巨大的双足警用机器人，伫立在雨天的大型工业机库内。机器人是画面的视觉中心，其复杂的机械结构高耸入云，覆盖着白色装甲板，并暴露出黑色的液压关节。它的头部并非人脸，而是由多镜头相机阵列组成，肩部亮着红色警示灯。胸部和手臂的装甲板上印有黑色的“警视厅 MPD”（Metropolitan Police Department）字样。它的双脚是宽大的防滑平台，稳稳地踩在潮湿的混凝土地面上。左侧天花板上垂下一条垂直横幅，上面写着“警视厅 METROPOLITAN POLICE DEPARTMENT”，并配有樱花徽章。横幅下方有一块水平标牌，写着“安全な東京を 次の世代へ A SAFER TOKYO FOR THE NEXT GENERATION”。透过敞开的机库大门，可以看到背景中暴雨倾盆下的东京城市景观，包括红色的东京塔格状结构和灰色天空下的现代摩天大楼。门外停放着几辆标有“MPD”字样的警车，车灯长明。前景角落站着两名身穿深色制服、头戴白色头盔的人类警官，为画面提供了比例参照。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977651662_sga1s9_HSqE4JtaAAAzupF.jpg" width="600" alt="YouTube 缩略图 - 雨夜机库中的巨型 MPD 机器人 - Image 1">
</div>

#### 📌 详情

- **作者:** [カーブミラー](https://x.com/kabumira862571)
- **来源:** [Twitter Post](https://x.com/kabumira862571/status/2101638284925669854#reversed-0)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35127)**

---

### No. 52: YouTube 缩略图 - 巨型警用机器人捕获熊

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一幅逼真的场景，描绘了一个巨大的黑白警用机器人手持装有熊的笼子，周围有警察和标志牌，位于国家公园步道入口处。

#### 📝 提示词

```
一张逼真的高分辨率图像，展示了一个巨大的双足警用机器人站在郁郁葱葱森林边缘的碎石空地上。这个机器人体型庞大，高耸于周围的车辆和人群之上，拥有黑白相间的装甲底盘，其胸部和肩甲上印有日文“警視庁”（东京都警视厅）和英文“MPD”。它的肩膀和头部闪烁着红光。机器人的双手正握着一个大型金属笼，里面关着一头活棕熊。在机器人的右侧停着一辆白色小型平板卡车，突显了机器人的巨大规模。两名身穿深蓝色制服、头戴头盔的人类警察站在卡车附近，仰望着机器人；他们背对镜头，夹克上印有“警視庁 MPD”。前景左侧有一个木制指示牌，上面有日文和英文文字：“大雪山国立公園 Daisetsuzan National Park”、“登山口 Trailhead”、“駐車場 Parking”，以及一个带有熊图标的警告标志，写着“クマ出没注意 Beware of Bears”。最右侧的另一条垂直横幅上写着“人と野生動物の共生を”（人与野生动物共存）。背景是茂密的树木和山峰，天空湛蓝，点缀着几朵白云。光线为自然日光，投射出逼真的阴影。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803927781_zsm693_HSf2WpjbMAA4Xsy.jpg" width="600" alt="YouTube 缩略图 - 巨型警用机器人捕获熊 - Image 1">
</div>

#### 📌 详情

- **作者:** [カーブミラー](https://x.com/kabumira862571)
- **来源:** [Twitter Post](https://x.com/kabumira862571/status/2100918626996154589#reversed-0)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35007)**

---

### No. 53: YouTube 缩略图 - 幼儿与服务员互动

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张逼真的图片，展示了一个幼儿在餐厅外与一位面带微笑的服务员交谈，画面中有“Knock”文字叠加。

#### 📝 提示词

```
一张垂直构图的逼真电影感照片，展示了一个可爱的幼儿站在城市人行道上，面前是一家敞开的餐厅大门。孩子抬头看着一位面带微笑的女性，她看起来像是服务员或领位员，穿着米色纽扣衬衫和围裙。这一场景捕捉到了互动的瞬间，孩子似乎正在说话或做出有趣的表情。单词 "Knock" 以粗体白色文字叠加在画面中心附近。温暖的自然光线，浅景深，高分辨率。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631455709_uzapfe_HSTqfUAaoAAWuJk.jpg" width="600" alt="YouTube 缩略图 - 幼儿与服务员互动 - Image 1">
</div>

#### 📌 详情

- **作者:** [Adnan](https://x.com/Adnan_Ai4)
- **来源:** [Twitter Post](https://x.com/Adnan_Ai4/status/2100061425360376189#reversed-0)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34849)**

---

### No. 54: YouTube 缩略图 - 赛博偶像 VTuber 预告片项目

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个结构化的提示词，用于生成包含 9 个分镜的动漫 VTuber 预告片项目，展示霓虹赛博舞台表演画面。

#### 📝 提示词

```
目标：创建一个电影感的 VTuber 预告片项目联系表，以 {argument name="character name" default="一位原创赛博偶像 VTuber"} 为唯一角色，在 3x3 的网格中展示 9 个动漫分镜。

画布：宽屏 16:9 图像，所有面板之间有干净的白色间距，高分辨率动漫主视觉风格。使用黄昏/夜晚的霓虹赛博舞台，地面具有光泽反射效果，背景为深色垂直摩天大楼般的灯柱，对角线青色和亮粉色光束，漂浮的粉色碎片纸屑，以及梦幻般的粉蓝色天空。色调为电光青、柔和蓝、洋红色、黑色和白色。

角色设计：一位美丽的年轻动漫偶像，拥有非常飘逸的 {argument name="hair color" default="带有鲜艳粉色挑染的天蓝色长发"}，粉紫色眼睛，白皙皮肤，舞台表现自信动人。服装：黑色高领露脐上衣，透明黑色网纱袖，带有交叉绑带，白色紧身胸衣配黑色系带，黑色短裤，大腿绑带/吊带袜，以及白色系带厚底靴。头发在几乎每个分镜中都应呈现出戏剧性的飘动感，仿佛被风或表演动作带动。

布局及 9 个分镜细节：
1. 左上：全身正面舞台介绍，角色以强有力的偶像姿态站在巨大的淡色圆形背光前，地面有反射，霓虹灯柱环绕。
2. 上中：手持黑色麦克风唱歌的特写，嘴巴微张，眼神专注，头发穿过画面，背景有对角线霓虹灯。
3. 右上：肩部以上的侧面特写，向上看，表情安静动人，长发在深蓝色和粉色光束的映衬下向右飘动。
4. 左中：戏剧性的低角度动态镜头，角色向观众伸出一只张开的手，手臂和手指有透视感，紧身胸衣和短裤清晰可见，背景为充满活力的舞台。
5. 中中：背面全身镜头，角色背对舞台上方巨大的发光薰衣草色圆环，对称的霓虹灯柱和粉色云朵倒映在地面上。
6. 右中：四分之三中景镜头，角色手触碰或抬起靠近头发/头部，自信地注视着镜头，网纱袖和紧身胸衣清晰可见。
7. 左下：背面四分之三中景镜头，角色回头看向肩膀后方，长发扫过画面，背景为粉色日落云彩和剪影般的栏杆/灯柱。
8. 下中：眼睛的极端特写，粉紫色虹膜细节清晰，下半脸部分被透明黑色袖子或戴手套的手臂遮挡，发丝垂在额前。
9. 右下：另一个动态低角度伸展镜头，张开的手向观众伸出，手指张开，嘴巴微张仿佛在呼唤，头发和光带在她周围弧形环绕。

视觉风格：精致的现代日本动漫风格，VTuber 预告片 MV 概念艺术，线条清晰，赛璐珞阴影配柔和渐变，电影级摄像机角度，戏剧性的透视感，光泽反射，高对比度霓虹灯光，充满情感与活力。无标题，无 Logo，无水印，无额外角色。保持网格严格为 9 个分镜，并确保每个分镜中的角色设计保持一致。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942350425_g96uvc_HRvnohtawAA9twY.jpg" width="600" alt="YouTube 缩略图 - 赛博偶像 VTuber 预告片项目 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942350434_11fdnj_HRvnohxaEAEHV__.jpg" width="600" alt="YouTube 缩略图 - 赛博偶像 VTuber 预告片项目 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942350424_hwryi6_HRvnoh3bYAAvP97.jpg" width="600" alt="YouTube 缩略图 - 赛博偶像 VTuber 预告片项目 - Image 3">
</div>

#### 📌 详情

- **作者:** [WTR](https://x.com/wtry1102)
- **来源:** [Twitter Post](https://x.com/wtry1102/status/2097525379338801209#reversed-1)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34033)**

---

### No. 55: YouTube 缩略图 - 动漫月蚀女剑士海报

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

创作一张宽屏动漫游戏公告主视觉图，画面包含一位面带微笑、手持武士刀的女主角，背景为月蚀，配有日文标题排版及飘落的花瓣。

#### 📝 提示词

```
目标：为 {argument name="title text" default="月蝕綺譚"} 创作一张电影质感的动漫游戏公告主视觉图，画面主体为一位在暗色月蚀背景前、神情愉悦的年轻女剑士。

画布：16:9 宽屏横向海报，1200x675 构图，深海军蓝夜空背景，搭配高对比度的红色与金色点缀。

布局：将角色置于右半部分，取大腿中部以上构图，身体略微前倾，展现自信活力。左侧放置巨大的金属质感金色书法体日文标题，标题后方衬有红色新月形笔触，标题旁附带小型垂直排列的罗马音“LUNA OCCULTA”。在左下方以金色字体添加发布信息 {argument name="release date text" default="9月19日 正式リリース予定"}。画面中上偏左处展示一个巨大的黑色日蚀/月蚀圆盘，并带有发光的深红色日冕。

主体细节：一位动漫女剑士，年龄在青少年至青年之间，笑容灿烂，棕色大眼睛，皮肤白皙，黑色长发扎成高马尾，向左侧飘逸，系着红色丝带，丝带的两条长尾在风中飘动。身穿鲜艳的粉色短袖和服式忍者/武士上衣，配黑色滚边，腰间系宽大的黑色腰带，并饰有小型金色绳结，下摆处可见深色内衬。双手横握一把武士刀于腰间；刀柄为黑色，带有精致的菱形缠绳，刀身/刀鞘向右下方延伸。

可见元素计数：画面包含 1 名角色、1 把武士刀、1 条带有 2 条飘带尾的红色发带、1 个月蚀、1 个标题后的红色新月笔触、1 个垂直标题块、1 个小型垂直罗马音标签以及 1 行发布日期文字。场景中散布 24 片发光的粉色花瓣，最大的一簇位于右侧，少量花瓣飘落在标题附近；另添加 8 个微小的橙色火星以增加深度。

视觉风格：精致的现代动漫插画，线条清晰，戏剧性的边缘光，饱和的粉色花瓣，亮面黑色发丝高光，微妙的风动感，暗黑奇幻宣传海报氛围，排版清晰易读，无水印，除指定文字外无任何 Logo。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942378751_mu4889_HRun6zoasAAfGei.jpg" width="600" alt="YouTube 缩略图 - 动漫月蚀女剑士海报 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942378929_z6rb9q_HRun603akAAUcH5.jpg" width="600" alt="YouTube 缩略图 - 动漫月蚀女剑士海报 - Image 2">
</div>

#### 📌 详情

- **作者:** [🍺 イケハヤ@「月蝕綺譚」開発](https://x.com/IHayato)
- **来源:** [Twitter Post](https://x.com/IHayato/status/2097456425190711694#reversed-0)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34071)**

---

### No. 56: YouTube 缩略图 - Vocaloid MV 风格角色网格图

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

这是一个为 GPT Image 2.5 设计的角色转换提示词，可基于参考头像生成 3x3 的电影感分镜网格，呈现独特的 Vocaloid MV 风格。

#### 📝 提示词

```
请使用此角色创建 {argument name="style" default="Vocaloid MV"} 风格的各种分镜，以 {argument name="grid" default="3x3"} 网格格式输出，并保持 {argument name="aspect ratio" default="16:9"} 的宽高比。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942301136_7k8t1n_HRucKbfbwAAI-Lj.jpg" width="600" alt="YouTube 缩略图 - Vocaloid MV 风格角色网格图 - Image 1">
</div>

#### 📌 详情

- **作者:** [兔妹_兔子](https://x.com/tuzi_ai)
- **来源:** [Twitter Post](https://x.com/tuzi_ai/status/2097441918187675744)
- **发布时间:** 2026年9月8日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33962)**

---

### No. 57: YouTube 缩略图 - 未来感浮空城市星云插画

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一幅迷人的高对比度图形，详细描绘了漂浮在云层之上、璀璨宇宙星云环下的城市景观或科幻都市布局。

#### 📝 提示词

```
这是一幅迷人的数字插画，描绘了一座悬浮在蓬松夜云之上的城市，背景是梦幻般的天空。前景中，密集的摩天大楼群窗户透出温暖的金色灯光，勾勒出闪耀的城市天际线。城市仿佛坐落在厚重、连绵的深蓝色与灰色云层之上，向远方延伸。城市上方，夜空化作了天体奇观：一个巨大且发光的彩色星云环绕着漆黑、星光点点的虚空。星云散发出深紫、电光蓝和炽热橙色的鲜艳色调，点缀着遥远闪烁的恒星与星座，营造出梦幻般超凡脱俗的氛围。这是一幅令人惊叹的垂直视角画面，展现了一座未来都市在黄昏时分优雅地漂浮在无尽、厚重且连绵的深灰色云海之上。广阔的城市天际线拥有众多高耸入云的摩天大楼，发光的窗户将温暖的琥珀色和橙色光芒投射到下方的城市景观中。画面上方是一道壮丽的宇宙环，这是一个由鲜艳紫色、深蓝色和灿烂暖金色组成的圆形发光星云，在漆黑的夜空中洒满了无数闪烁的恒星和遥远的星系。构图平衡且宏伟，下方的深色云层作为基底，与上方璀璨的宇宙现象形成鲜明对比。光影超现实且空灵，将城市灯光的温暖人造光与星云的宇宙光芒融为一体。氛围宁静、令人敬畏且神秘，唤起了一种星际奇观与城市孤寂感。柔软蓬松的云层纹理、摩天大楼光滑的玻璃钢结构以及星光熠熠的宇宙尘埃，共同营造出高对比度、视觉冲击力极强的场景。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942279160_c8ry1i_HRuTgPPWIAAcjAy.jpg" width="600" alt="YouTube 缩略图 - 未来感浮空城市星云插画 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942279119_cj0v28_HRuTWsta0AAU6QG.jpg" width="600" alt="YouTube 缩略图 - 未来感浮空城市星云插画 - Image 2">
</div>

#### 📌 详情

- **作者:** [Viki](https://x.com/churvikv)
- **来源:** [Twitter Post](https://x.com/churvikv/status/2097435473043931201)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33916)**

---

### No. 58: YouTube 缩略图 - 复古合成器波播客主持人

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张写实风格的 1980 年代蒸汽波风格工作室肖像，用于创作带有怀旧道具和标志的霓虹灯播客主持人场景。

#### 📝 提示词

```
创作一张写实风格的 1980 年代复古合成器波播客肖像，画面中是一位面带微笑的 {argument name="host description" default="30 多岁的白人男性主持人，有着蓝色眼睛、凌乱的棕色鲻鱼头短发、淡淡的胡茬和友好的笑容"}，他正坐在桌前靠近镜头，面向前方，双臂交叉，姿态放松。他身穿一件大胆的霓虹色防风外套，配色为 {argument name="jacket colors" default="青色、亮粉色、紫色和黑色的几何拼接"}，内搭一件白色 T 恤，手腕上戴着黑色数字手表。在前景中央放置一个大型复古银色广播麦克风，安装在黑色悬臂支架上，清晰可见 SHURE 品牌标识。背景是一个昏暗的工作室，充满了 1980 年代的怀旧元素：他身后是一个明亮的霓虹灯三角形标志，用粉色草书和青色灯管写着 {argument name="neon sign text" default="Thursday AI"}；左侧堆叠着 4 盒磁带，标签分别为“SYNTHWAVE”、“HITS 1984”、“MIXTAPE”和“GOOD VIBES”；磁带下方是一个复古收音机；右侧是一台旧式 CRT 电视，屏幕上显示着带有棕榈树和蓝色网格地平线的蒸汽波日落画面。在电视上方增加一张带框的闪电海报。使用饱和的洋红色和青色轮廓光，温暖的肤色，浅景深，柔和的胶片颗粒感，轻微的灰尘和划痕，磨损的圆角照片边框，高细节摄影，方形垂直构图，怀旧蒸汽波色调，画面中无其他人物，无现代设备，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942313486_7bqlk5_HRt1gHdaUAAOdvA.jpg" width="600" alt="YouTube 缩略图 - 复古合成器波播客主持人 - Image 1">
</div>

#### 📌 详情

- **作者:** [Alex Volkov](https://x.com/altryne)
- **来源:** [Twitter Post](https://x.com/altryne/status/2097399256240001059#reversed-0)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33982)**

---

### No. 59: YouTube 缩略图 - 电影感沙漠“火之环”专辑封面

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张极具戏剧性的专辑封面提示词，描绘了一位歌手在夜晚的沙漠中，身后环绕着象征性的火焰光环。

#### 📝 提示词

```
超写实电影感专辑封面，描绘了一位男歌手独自站在夜晚广阔荒凉的沙漠中央，身穿一件在风中自然飘动的黑色长风衣，搭配深色靴子和极简配饰。歌手直视镜头，表情冷静却充满强烈的情感。在他身后，一个巨大的圆形结构正在缓慢燃烧，在黑暗中形成一个巨大的火环，完美地置于他身后，宛如象征性的光环。火焰以强烈的暖橙色光芒照亮了他的轮廓边缘，而冷蓝色的月光则照亮了他脸部的另一侧，营造出极具戏剧性的电影感对比。浓烟升入夜空，发光的余烬在空中飘浮，微风吹动着他的衣物，地面呈现出沙漠的质感，远处的山脉在朦胧的大气中隐约可见。整体画面象征着毁灭、重生、自由与情感的蜕变。史诗般的另类摇滚专辑美学，极具艺术感且真实，充满强有力的象征意义，戏剧性的广角构图，歌手始终是视觉焦点。超精细的面部特征，真实的皮肤质感，自然的火焰反射，体积烟雾，电影级布光，细腻的模拟胶片颗粒感，丰富的阴影层次，使用 Canon EOS R5 和 35mm 电影镜头拍摄，超写实，高端音乐摄影，8K 分辨率，1:1 正方形专辑封面，无文字，无字母，无水印，非奇幻风格插画，无畸形解剖结构，无多余肢体。超写实电影感专辑封面，描绘了一位女歌手独自站在夜晚广阔荒凉的沙漠中央，身穿一件在风中自然飘动的黑色长风衣，搭配深色靴子和极简配饰。歌手直视镜头，表情冷静却充满强烈的情感。在她身后，一个巨大的圆形结构正在缓慢燃烧，在黑暗中形成一个巨大的火环，完美地置于她身后，宛如象征性的光环。火焰以强烈的暖橙色光芒照亮了她的轮廓边缘，而冷蓝色的月光则照亮了她脸部的另一侧，营造出极具戏剧性的电影感对比。浓烟升入夜空，发光的余烬在空中飘浮，微风吹动着她的衣物，地面呈现出沙漠的质感，远处的山脉在朦胧的大气中隐约可见。整体画面象征着毁灭、重生、自由与情感的蜕变。史诗般的另类摇滚专辑美学，极具艺术感且真实，充满强有力的象征意义，戏剧性的广角构图，歌手始终是视觉焦点。超精细的面部特征，真实的皮肤质感，自然的火焰反射，体积烟雾，电影级布光，细腻的模拟胶片颗粒感，丰富的阴影层次，使用 Canon EOS R5 和 35mm 电影镜头拍摄，超写实，高端音乐摄影，8K 分辨率，1:1 正方形专辑封面，无文字，无字母，无水印，非奇幻风格插画，无畸形解剖结构，无多余肢体。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788769188072_ieusoh_HRmA-1obkAAy3f6.jpg" width="600" alt="YouTube 缩略图 - 电影感沙漠“火之环”专辑封面 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788769187921_lj93qs_HRmA-1fbsAAbVan.jpg" width="600" alt="YouTube 缩略图 - 电影感沙漠“火之环”专辑封面 - Image 2">
</div>

#### 📌 详情

- **作者:** [M. Asif](https://x.com/meAsifAi)
- **来源:** [Twitter Post](https://x.com/meAsifAi/status/2096866056342225198)
- **发布时间:** 2026年9月7日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33693)**

---

### No. 60: YouTube 缩略图 - 赛博朋克犬耳女剑客

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张极具戏剧性的动漫主视觉图，描绘了一位在故障霓虹赛博朋克战场上受伤的犬耳女剑客。

#### 📝 提示词

```
创作一张电影级动漫主视觉图，画面中心为 {argument name="character name" default="一位年轻的犬耳女剑客"}，她正站在混乱的霓虹赛博朋克战场中央。她留着一头飘逸的 {argument name="hair color" default="浅金色"} 长发，发丝戏剧性地向左飘动，前额扎着两条粗辫子，有着下垂的动物耳朵、疲惫的青蓝色双眼，表情空洞冷漠，脸上带有细小的伤口和血迹。她身穿一件深色修身军装夹克，内搭一件染血的白衬衫，配有黑色战术绑带和腰带，穿着深色长裤，整体轮廓饱满且带有战斗磨损感。画面中必须清晰呈现两把剑：一把武士刀斜挎在背上，刀柄上系着红色流苏；另一把剑或武器收在鞘中，通过链条悬挂在身体左侧低处。背景为抽象的废墟未来城市或数字虚空，充斥着强烈的动态模糊、故障伪影、色差效果、水平扫描线碎片、黑色碎片剪影，以及爆炸般的红、洋红、紫、蓝、青和橙色光束。在她头后放置一个明亮的白色圆形光环，右侧有垂直的蓝色结构，左侧则是温暖的红色混乱景象。采用深色高对比度调色，强调戏剧性的轮廓光，运用绘画风格的动漫渲染，刻画锐利的面部细节，展现动态发丝、电影级景深、充满活力的构图以及悲剧性的末日氛围。画面中无任何可读文字，无水印，采用 3:2 宽屏比例。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788250593151_dlb6ut_HREnYNNbEAAXfPR.jpg" width="600" alt="YouTube 缩略图 - 赛博朋克犬耳女剑客 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788250593154_yjzcnj_HREnZi6bsAAocAc.jpg" width="600" alt="YouTube 缩略图 - 赛博朋克犬耳女剑客 - Image 2">
</div>

#### 📌 详情

- **作者:** [Meipuru](https://x.com/miyasangsuifeng)
- **来源:** [Twitter Post](https://x.com/miyasangsuifeng/status/2094499348151513565#reversed-0)
- **发布时间:** 2026年8月31日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33172)**

---

### No. 61: YouTube 缩略图 - 赛博朋克城市跑酷 MV

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

一个关于电影感音乐视频的提示词，展现了在未来城市屋顶进行高速跑酷的场景，并配有跟拍镜头。

#### 📝 提示词

```
在霓虹闪烁的近未来城市屋顶高速奔跑，连接跳跃、跑墙、落地滑行等动作，配合跟拍镜头与极具速度感的电影级 MV
─────────────────
视频生成：fal ai (MiniMax H3 Max)
图像生成（服装）：ChatGPT img2
分镜脚本：GPT-5.6 Sol
✴︎────────────────✴︎
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788163921669_2nu8k3_HRA3sVMasAAKXVQ.jpg" width="600" alt="YouTube 缩略图 - 赛博朋克城市跑酷 MV - Image 1">
</div>

#### 📌 详情

- **作者:** [みゆー|AI×おじぎねこサロンアンバサダー/Miricanvas公式サポーター](https://x.com/gaogao_1192)
- **来源:** [Twitter Post](https://x.com/gaogao_1192/status/2094241662201671695)
- **发布时间:** 2026年8月31日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33023)**

---

### No. 62: YouTube 缩略图 - 冬日暮色中的灯笼摄影

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个高度详细且具有电影感的提示词，用于生成一张照片级逼真的图像：一位身穿米色大衣的女性，在梦幻般的蓝色冬日森林雾气中手持复古灯笼。

#### 📝 提示词

```
{ "title": "{argument name=\"title\" default=\"冬日暮色中的灯笼\"}", "scene": "暮色中宁静的冬日森林。柔和的雪花从天空中轻轻飘落，周围的树木隐没在梦幻般的蓝色冬日雾气中。", "subject": "{argument name=\"subject\" default=\"一位年轻女性独自站在飘落的雪花下，身穿一件米色长款羊毛大衣，围着厚实的针织围巾。她神情平静安详，将一盏发光的复古灯笼轻轻抱在胸前。\"}", "detail": "温暖的灯光照亮了她的脸庞，并映照出飘落的雪花，营造出闪烁的高光。雪花柔和地落在她的大衣和头发上，而远处的森林则在寒冷的蓝色薄雾中保持模糊。", "atmosphere": "宁静、神奇、电影感、平和、感性、梦幻且永恒。", "lighting": "{argument name=\"lighting\" default=\"温暖的金色灯光与冷色调的暮色形成对比，体积光，逼真的光线穿过降雪产生散射，柔和的阴影，电影级光晕。\"}", "composition": "亲密的电影感肖像，居中构图，浅景深，奶油般虚化的背景，柔和模糊的雪林背景，平视视角。", "style": "照片级逼真，电影杰作，柯达胶片色彩，超逼真的皮肤纹理，写实的降雪效果，体积光，奶油般虚化，浅景深，HDR，8K，高度细节，获奖摄影作品。", "mood": "在冬日的寂静中，那一刻宁静的温暖与希望。" }
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787917358071_90hyak_HQvZwRpbAAAqdnm.jpg" width="600" alt="YouTube 缩略图 - 冬日暮色中的灯笼摄影 - Image 1">
</div>

#### 📌 详情

- **作者:** [Compound Learning - Tech | Science](https://x.com/SheBuildsAI_)
- **来源:** [Twitter Post](https://x.com/SheBuildsAI_/status/2093005879461462428)
- **发布时间:** 2026年8月27日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32786)**

---

### No. 63: YouTube 缩略图 - 迈阿密之夜舞蹈封面

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张霓虹合成波风格的迈阿密夜生活音乐海报，包含跳舞剪影、城市天际线双重曝光以及宣传曲目文字。

#### 📝 提示词

```
目标：为名为 {argument name="headline text" default="Miami Night"} 的热带合成波舞曲创作一张方形转竖版的霓虹音乐封面海报，将女性跳舞剪影与迈阿密天际线双重曝光效果融合。

画布：竖版 4:5 海报，高分辨率，光面电影质感。使用鲜艳的日落至夜晚渐变背景：地平线附近为热情的橙色和洋红色，顶部为深紫色和海军蓝的星空。

主体图像：画面中心为一名全身女性舞者剪影，侧身向右，双臂高举过头顶，呈现舞蹈姿态。她长发飘逸，随风向左飞扬。她的身体是一个深色剪影，内部填充了双重曝光的城市景观：发光的摩天大楼、微小的窗户灯光、粉色的屋顶灯、棕榈树、滨水倒影以及躯干和腿部内波光粼粼的海湾水面。保持轮廓清晰优雅，并带有强烈的背光效果。

背景环境：展示夜晚的迈阿密滨水天际线，两侧有棕榈树，模糊的城市建筑、闪烁的灯光以及水面上的霓虹倒影。前景中包含 2 棵显眼的棕榈树剪影（左右各一），以及天际线附近较小的远景棕榈树。上方添加星空。

主体艺术上的排版：在舞者和天际线之上，放置醒目的发光手写草书霓虹文字 {argument name="neon script text" default="Miami Night"}。字体应呈现明亮的粉白色，如同霓虹灯管，横跨画面近全宽并穿过中心。

底部信息面板：在海报底部约四分之一处添加一个深海军蓝的长方形面板。包含 6 个排列整齐的文字/图标元素，呈现音乐宣传卡片样式：1) 一个粉色音符图标，后接白色标题文字 {argument name="track title" default="MiamiNight"}；2) 粉色副标题文字 {argument name="challenge text" default="“Dance party” Challenge"}；3) 一条带有中心小闪光点的细装饰水平分割线；4) 白色艺术家署名行 {argument name="artist line" default="— Crystal Dragon Lancer エル"}；5) 两个粉色标签 "#Suno" 和 "#AI音楽"；6) 右下角小字白色制作信息 "Direction / Prompt: Elle"。

视觉风格：复古迈阿密夜生活、合成波专辑封面艺术、霓虹粉紫配色、电影级双重曝光、光面反射、高对比度、梦幻热带派对氛围、简洁的社交媒体封面设计。

约束：保持所有列出的文字清晰易读并按描述位置放置。不要添加额外的标志、水印或不相关的文字。请保留默认文本中出现的日文字符。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787559679617_yh2m76_HP-e7bpaAAImQDR.jpg" width="600" alt="YouTube 缩略图 - 迈阿密之夜舞蹈封面 - Image 1">
</div>

#### 📌 详情

- **作者:** [エル💙way](https://x.com/ellewayAI)
- **来源:** [Twitter Post](https://x.com/ellewayAI/status/2091492145685205064#reversed-0)
- **发布时间:** 2026年8月23日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32486)**

---

### No. 64: YouTube 缩略图 - 海盗放克播放列表封面

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一款大胆的正方形播放列表封面，特色元素包括复古丝网印刷海盗船长、骷髅旗、红月亮以及巨大的放克风格标题排版。

#### 📝 提示词

```
为 {argument name="playlist title" default="FUNK GUERRA!"} 创建正方形 Spotify 播放列表封面艺术，风格设定为大胆的复古丝网印刷海盗放克专辑海报。使用黑色背景，搭配暖奶油色和鲜艳红橙色的受限色调，呈现厚重的做旧墨迹质感、粗糙的半调/颗粒感、锐利的高对比度矢量形状以及戏剧性的漫画书式光影。中心主体是一位侧脸向右的凶猛海盗船长，留着长长的黑色辫子和浓密胡须，佩戴圆环耳环，头戴印有骷髅交叉骨标志的三角帽，身穿带有奶油色轮廓和纽扣的深色海军大衣。他在右下角前景处紧握一个巨大的船舵。在他身后，包含 2 个海盗符号：一个位于帽子上，另一个位于右侧的黑色旗帜上。在左上角海盗身后添加一个巨大的红橙色做旧月亮。在右上角放置一个小的长方形红橙色轮廓标签，内含以粗体大写字母书写的 {argument name="duration label" default="1 HOUR"}。下半部分由超大的堆叠排版占据：第一个单词 {argument name="top title word" default="FUNK"} 为奶油色，第二个单词 {argument name="bottom title word" default="GUERRA!"} 为红橙色，两者均采用巨大的压缩无衬线板式/块状字体，字间距紧凑。整体构图应呈现出具有侵略性的朋克放克海盗宣传画风格，确保在缩略图尺寸下清晰易读，且不包含额外文本、水印、写实照片渲染或额外角色。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787559675556_2d5wum_HQYBZ4EaQAAVI_D.jpg" width="600" alt="YouTube 缩略图 - 海盗放克播放列表封面 - Image 1">
</div>

#### 📌 详情

- **作者:** [Sawchang](https://x.com/sawchang_dsm)
- **来源:** [Twitter Post](https://x.com/sawchang_dsm/status/2091364582719893616#reversed-1)
- **发布时间:** 2026年8月23日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32373)**

---

### No. 65: YouTube 缩略图 - 索尼耳机评测缩略图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一款适用于科技评测的醒目 YouTube 缩略图模板，包含耳机特写人像、大号疑问文本及产品标签。

#### 📝 提示词

```
制作一张 16:9 横屏格式、视觉冲击力强的 YouTube 科技评测缩略图。在右半部分，展示一位留着深色短卷发年轻男性的特写人像，他佩戴着大型浅灰色头戴式耳机，自信地看向镜头，下巴微抬，带着一丝微妙的微笑；采用胸部以上构图，确保耳机清晰可见。在左半部分，顶部放置醒目的粗体缩略图文本 {argument name="headline text" default="这是"}，使用白色大写字母；下方放置一个红色矩形横幅，内含亮黄色大写文本 {argument name="main question text" default="最强吗？"}，并带有强烈的投影和略微倾斜的动态布局。在主文本下方，添加较小的白色产品文本 {argument name="product name" default="Sony WH-1000XM6"}。添加一个粗体手绘白色弯曲箭头，从文本区域指向耳机。左侧背景使用深海军蓝至黑色的渐变，带有微妙的圆点半调纹理；右侧人物背后呈现暖米色径向光晕。设计需清晰、色彩饱和且具有点击吸引力，具备戏剧性的对比度、摄影棚灯光、锐利的面部细节、干净的抠图边缘，且不含任何多余的 Logo、水印或其他文本。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787386272143_4l5azu_HQRb6sXWIAA7uh3.jpg" width="600" alt="YouTube 缩略图 - 索尼耳机评测缩略图 - Image 1">
</div>

#### 📌 详情

- **作者:** [BLCNYY](https://x.com/BLCNYY)
- **来源:** [Twitter Post](https://x.com/BLCNYY/status/2090897198351368575#reversed-1)
- **发布时间:** 2026年8月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32279)**

---

### No. 66: YouTube 缩略图 - 电影级动作大片人像

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一份用于生成具有特定光影和镜头特性的专业电影级动作大片截图的高细节提示词。

#### 📝 提示词

```
16:9。美式动作电影截图风格。光影：轮廓光 + {argument name="tone" default="冷色调"}，暗色，{argument name="light color" default="冷蓝色"} 色调光源，低光，黑暗，昏暗。{argument name="subject" default="图 1 中的男性"} 半身特写（服装 + 面部特征必须保持一致），模糊的前景空气中漂浮着些许火花。黑色背景。使用等效 85mm 人像镜头的视觉效果拍摄，景深约为 f/2.8，面部特征必须清晰对焦。角色的发型必须保留原始造型、自然的头发质感和发量，且单根发丝清晰可见。电影级对比度。专业商业人像级修图，仅略微均匀肤色。无美颜滤镜，无人工、塑料感或明显的 AI 生成质感。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787386246236_1925oj_HQQyH6EasAALtWB.jpg" width="600" alt="YouTube 缩略图 - 电影级动作大片人像 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787386246189_ubeena_HQQyH6EaQAAE-Mp.jpg" width="600" alt="YouTube 缩略图 - 电影级动作大片人像 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787386246250_24qr0z_HQQyH6LaMAAy_rc.jpg" width="600" alt="YouTube 缩略图 - 电影级动作大片人像 - Image 3">
</div>

#### 📌 详情

- **作者:** [Luber](https://x.com/Luber_AI)
- **来源:** [Twitter Post](https://x.com/Luber_AI/status/2090851717390926032)
- **发布时间:** 2026年8月21日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32260)**

---

### No. 67: YouTube 缩略图 - YouTube 直播辩论截图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

用于生成两位科技界人士在 YouTube 进行直播辩论的逼真截图的提示词。

#### 📝 提示词

```
在 {argument name="channel" default="youtube channel"} 上进行 {argument name="people" default="sam vs dario"} 直播辩论的截图，包含准确的细节，16:9 画幅，主题为 {argument name="topic" default="agi"}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787645595817_qwptnn_HQQFL6laEAAfekE.jpg" width="600" alt="YouTube 缩略图 - YouTube 直播辩论截图 - Image 1">
</div>

#### 📌 详情

- **作者:** [Chetaslua](https://x.com/chetaslua)
- **来源:** [Twitter Post](https://x.com/chetaslua/status/2090801966712791194)
- **发布时间:** 2026年8月21日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32537)**

---

### No. 68: YouTube 缩略图 - 动漫《败北女角太多了！》教室剧照

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一张宽幅电影感动漫教室主视觉图，包含三位校园角色、日式宣传排版以及恋爱喜剧风格的角色注释。

#### 📝 提示词

```
目标：创作一张电影感动漫教室剧照，呈现精致的日式校园恋爱喜剧风格，拥有柔和的日光、富有表现力的角色以及类似宣传海报的日文排版。

画布：宽幅 16:9 横向画幅，1200×675 构图，平视镜头，浅景深电影感，冷蓝灰色阴影与暖色日光高光。

场景与布局：白天，现代高中教室内部。三名学生坐在靠近大窗户的课桌旁。窗外背景展示了明亮的天空、远处的建筑、绿植和混凝土结构的校舍。前景的课桌横贯画面底部，桌上摆放着学校用品。氛围苦涩中带有喜剧色彩，角色周围漂浮着手写体评论。

角色：共 3 名动漫学生。1) 左侧前景：一位开朗的蓝发女学生，作为主体，单手托腮，带着放松而俏皮的微笑，蓝色双眸微微泛泪；留着凌乱的长深蓝色头发，配有刘海，身穿白色短袖校服衬衫，系蓝色领结，领口有黄色小饰品或丝带。她看起来自信且爱捉弄人。2) 中央：一位棕发男学生，身穿白色短袖衬衫和深绿色领带，坐在她身后稍远处，侧头看着她，表情焦虑尴尬，脸上带着一滴小汗珠。3) 右侧背景：一位留着酒红色短发、戴着发夹的矮个子女生，独自坐在窗边，弓着身子躲在小书或手机后，投来安静的嫉妒或尴尬的斜视目光。

物品：包含 5 个显著的前景物品：左侧课桌上的粉色便当盒、一块折叠的粉白相间布料、男孩面前插着吸管的小盒草莓酸奶、右侧课桌上的深蓝色书包，以及酒红色头发女生手中的小书或手机。

文字与图形元素：在左上角添加一个动漫标题 Logo，主标题为 {argument name="title logo text" default="負けヒロインが多すぎる!"}，下方附带罗马字副标题“MAKEINE Too Many Losing Heroines!”。在后墙或窗柱上添加一张教室海报，标语为 {argument name="poster slogan" default="負けても、きっと、青春は、終わらない。"}，并附带英文副标题“Too Many Losing Heroines!”。在每个角色附近添加白色的日文手写注释，配以弯曲箭头和虚线，包括蓝发女生旁边的 {argument name="blue-haired girl annotation" default="やっぱ私は負けヒロインなんだよね〜"}，男生旁边的 {argument name="boy annotation" default="また始まった…"}，以及右侧女生旁边的 {argument name="right girl annotation" default="別に気にしてない"}。手写体应保持轻盈、随意，并融入场景中，而非看起来像 UI 标签。

视觉风格：高质量 2D 动漫主视觉图，细腻的线条，自然的皮肤阴影，精致的头发高光，窗户透出的柔和光晕，细微的胶片颗粒感，柔和的大气雾感，真实的教室透视，以冷色调为主，饱和的蓝发作为视觉焦点。

限制：使用上述指定的 3 名角色和 5 个显著的桌面/手持物品。不要添加额外的学生。保持构图为单张动漫宣传剧照，而非拼贴画。避免水印、真实工作室的 Logo 或无法辨认的故障噪点。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787299942773_6mzcvx_HQHKuJcX0AA-4Jv.jpg" width="600" alt="YouTube 缩略图 - 动漫《败北女角太多了！》教室剧照 - Image 1">
</div>

#### 📌 详情

- **作者:** [ヤノ](https://x.com/Ryuki_Yano)
- **来源:** [Twitter Post](https://x.com/Ryuki_Yano/status/2090380808754434220#reversed-0)
- **发布时间:** 2026年8月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32143)**

---

### No. 69: YouTube 缩略图 - 《败北女角太多了！》动画教室主视觉图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张电影感十足的动画教室宣传主视觉图，包含三位校园恋爱角色，配有日文标题图形和手写风格注释。

#### 📝 提示词

```
创作一张 16:9 的电影感动画主视觉图，主题为校园恋爱喜剧，标题为 {argument name="series title" default="負けヒロインが多すぎる!"}。场景设定在黄昏或午后阳光柔和的日本高中教室，配有宽大的开窗、混凝土立柱、阳台栏杆，窗外是朦胧的城市与山景。前景中，三名学生坐在课桌前：左侧是 {argument name="main heroine" default="一位开朗的蓝发女学生"}，她单手托腮前倾，带着一丝得意的微笑，蓝色的双眸水汪汪的，脸颊微红，身穿白色短袖校服衬衫，系着蓝色领结，胸前戴着可爱的熊形配饰；中间是 {argument name="male lead" default="一位紧张的棕发男学生"}，穿着白衬衫和绿领带，瞪大眼睛不安地斜视着她，额头冒着汗珠；右侧是 {argument name="second heroine" default="一位留着栗色短发的女学生"}，她侧身坐着，躲在花纹笔记本或手机后面，假装不在意，表情闷闷不乐且有些害羞，戴着发夹，身穿白色校服衬衫。课桌上需包含四个清晰可见的物品：蓝发女孩面前的粉色便当盒、一个粉白相间的布包、一盒插着吸管且带有日文标签的草莓酸奶，以及右侧前景处的一个深蓝色书包。添加类似动画宣传海报的平面设计文字叠加：左上角为蓝色和粉色的日文标题 {argument name="headline text" default="負けヒロインが多すぎる!"}，下方配有英文副标题“MAKEINE Too Many Losing Heroines!”；添加四处白色手写风格的日文侧边注释，并配有箭头或虚线，分别位于蓝发女孩、男主角、栗色短发女孩附近以及右上角。背景墙上需添加两张海报：一张是栗色短发女孩身后立柱上的灰色海报，印有日文和英文小字“Too Many Losing Heroines!”；另一张是右侧高墙上的白色海报，印有日文标语和一条细蓝线。画面需采用新海诚风格的细腻动画光影、写实的教室透视、绘画感背景、柔和的轮廓光、微妙的镜头光晕、生动的角色表演、干净的线条，以及柔和的冷色调阴影，除指定的宣传元素外，不得包含额外角色或文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1787299954370_ustsmx_HQHKuJcX0AA-4Jv.jpg" width="600" alt="YouTube 缩略图 - 《败北女角太多了！》动画教室主视觉图 - Image 1">
</div>

#### 📌 详情

- **作者:** [jun](https://x.com/jun1228909)
- **来源:** [Twitter Post](https://x.com/jun1228909/status/2090340154137551340#reversed-0)
- **发布时间:** 2026年8月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=32077)**

---

### No. 70: 漫画 / 故事板 - 手绘时尚插画风格转换

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

专为 gpt-image-2（明确指定）设计的提示词，可将上传的照片转换为迷人的日韩风格手绘时尚插画。

#### 📝 提示词

```
将上传的照片转换为迷人的手绘时尚插画，同时保留原始场景和构图。

保持与参考照片相同的人物、人数、姿势、身体姿态、面部表情、服装、配饰、发型、物体、饮品以及整体取景框。不要添加或移除重要元素。

将写实照片转化为极简的日韩灵感生活方式素描插画，使用松散但自信的深绿色墨线，并带有微妙的手绘瑕疵感。简化面部特征，同时保留每个人可识别的发型、眼镜、耳机、服装轮廓和姿势。

使用柔和的淡粉色背景，主要以深森林绿墨水绘制插画。用简化的表现性线条和选择性交叉排线替代写实的纹理、阴影、车辆、建筑物、路面及周边环境。保留足够的环境细节，使原始地点和构图依然清晰可辨。

风格：可爱的编辑类插画，日本文具美学，时尚草图，休闲日常漫画绘图，不完美的笔触，干净的留白，极简细节，微妙的复古感，手工制作的质感。

色彩处理：以淡粉色背景为主 + 深绿色线条艺术，如有需要仅使用极少量的次要色调。无照片级真实感，无 3D 渲染，无光泽数字绘画。

重要提示：保留原始图像的构图、透视、相机角度、姿势、比例、服装、配饰和关键物体。结果应看起来像是由插画师重新描绘了这张确切的照片，而不是将其重新设计成不同的场景。

输出：干净的垂直插画，美学平衡，高分辨率，精致的手绘完成度。

适用于图像模型的简短版本：

将这张照片转换为可爱的手绘日式生活方式/时尚草图。保留确切的人物、姿势、表情、服装、发型、配饰、饮品、构图、相机角度和重要的背景元素。在柔和的淡粉色背景上，使用松散不完美的深森林绿墨线重绘所有内容，采用最少的交叉排线和简化的细节。迷人的编辑类文具美学，休闲漫画灵感插画，手工钢笔质感，干净的留白，优雅且充满奇思妙想。不要改变构图或添加/移除主体；使其看起来像是原照片直接由手绘制而成。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717714151_cwx8mp_HSd3pWebgAAyN6k.jpg" width="600" alt="漫画 / 故事板 - 手绘时尚插画风格转换 - Image 1">
</div>

#### 📌 详情

- **作者:** [Sairah](https://x.com/Sairah_0)
- **来源:** [Twitter Post](https://x.com/Sairah_0/status/2100779368318701669)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34934)**

---

### No. 71: 漫画 / 故事板 - GPT Image 2 剪纸插画提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

使用 GPT Image 2 将上传的图片转换为柔和手工剪纸分层插画的详细提示词，同时保留构图和特征。

#### 📝 提示词

```
生成前请上传一张参考图片。

主要提示词
将上传的图片转换为柔和的手工剪纸分层插画，同时保留原始构图、主体位置、姿势、比例、透视以及可识别的特征。

格式锁定
垂直 3:4 构图。保留原始的取景、相机角度、裁剪和整体视觉层次。

风格
柔和的纸艺立体模型美学，具有平滑圆润的形状、简化的可爱比例、极简的面部细节、点状眼睛、柔和的红晕脸颊以及温暖的故事书角色设计。使用堆叠的纸张层重现整个场景，具有可见的维度深度、层间微妙的阴影以及类似精心制作卡纸的干净切割边缘。

角色设计
保持主要角色的可识别性，同时将他们的形态简化为迷人的剪纸人物。在每个主要角色周围添加明显的厚白色外层纸张，创建干净的贴纸状剪纸边框，将他们与背景在物理上分离开来。白色边框必须看起来像是有意的卡纸层，而不是光晕或照明效果。

纸张材质
使用类似厚艺术纸或工艺泡沫的哑光触感材料。展示细微的纸张纹理、分层边缘、轻微厚度、干净切口、微小的手工瑕疵以及重叠层之间逼真的接触阴影。

色彩调色板
柔和的粉彩颜色，带有柔和的蓝色、温和的绿色、温暖的中间色、奶油色和微妙的互补点缀。保持调色板平衡、平静、舒适且和谐。

光照
柔和漫射均匀的光照。温和的环境照明。微妙的层阴影。无强烈对比。增强纸张层的物理深度，同时保持柔和的手工氛围。

构图
保留原始的场景结构和视觉层次。保持角色、物体和重要环境元素在其原始位置，同时将所有内容转换为相同的剪纸视觉语言。维持前景、中景和背景之间的清晰分离。

输出风格
舒适的手工纸艺立体模型。现代儿童绘本插画。装饰性剪纸艺术品。温暖的故事书美学。健康、温柔、俏皮、精致、触感和高级感。

负面提示词
避免照片写实主义、CGI、光泽表面、塑料外观、霓虹色、强烈光照、过度细节、逼真面部渲染、漂浮角色、发光白色轮廓、扁平数字插画、杂乱边缘、过度阴影、扭曲解剖结构、改变构图、文字、标志、水印或低质量渲染。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717712171_3eh858_HSb3HpIWcAEg9ih.jpg" width="600" alt="漫画 / 故事板 - GPT Image 2 剪纸插画提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717711740_cqwvem_HSb3HpJWQAEVbcE.jpg" width="600" alt="漫画 / 故事板 - GPT Image 2 剪纸插画提示词 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717711810_1k352d_HSb3HpKW8AEihPT.jpg" width="600" alt="漫画 / 故事板 - GPT Image 2 剪纸插画提示词 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717712692_lpzufz_HSb3HpPW8AAqpGp.jpg" width="600" alt="漫画 / 故事板 - GPT Image 2 剪纸插画提示词 - Image 4">
</div>

#### 📌 详情

- **作者:** [Visual AI Club](https://x.com/visualaiclub)
- **来源:** [Twitter Post](https://x.com/visualaiclub/status/2100638045103853684)
- **发布时间:** 2026年9月17日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34932)**

---

### No. 72: 漫画 / 故事板 - 航拍蒸汽朋克工坊改造

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

将家庭合影转化为俯视视角的蒸汽朋克工坊场景，融合水彩泼溅效果与技术蓝图元素。

#### 📝 提示词

```
基于提供的参考图像，将人物肖像转化为高度细节化的俯拍视角，展示主体人物在杂乱无章的蒸汽朋克发明家工坊中工作的场景。保留三位人物的面部特征和服装颜色（穿白色 T 恤的男子、穿米色衣服的老年女性以及穿无袖米色连衣裙的年轻女性），并将他们重新布置在一张大木桌周围。桌面上铺满陈旧的羊皮纸蓝图，上面绘有华丽机器的技术草图，并散落着黄铜齿轮、精密绘图工具和放大镜。场景由上方悬挂的一盏温暖发光的灯泡照亮。在构图的外边缘应用鲜艳的水彩泼溅效果，将红色、蓝色和黄色等多彩颜料融入纹理纸张背景中。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631458350_1r8oar_HSUeSbNaIAAvoXV.jpg" width="600" alt="漫画 / 故事板 - 航拍蒸汽朋克工坊改造 - Image 1">
</div>

#### 📌 详情

- **作者:** [Tiyashi](https://x.com/TiyashiAI)
- **来源:** [Twitter Post](https://x.com/TiyashiAI/status/2100118111504752947#reversed-0)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34852)**

---

### No. 73: 漫画 / 故事板 - 奇幻制图师与爱犬

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

将人物与宠物的照片转化为详细的奇幻插画，展现他们在巫师书房中探索古老地图的场景。

#### 📝 提示词

```
使用提供的参考图像，将主体及其狗转化为高奇幻风格的“古老地图”插画。保留角色的特定服装——绿色帽子、面罩、橙黑相间的图案球衣和蓝色牛仔裤——以及那只毛茸茸的白色小狗，但将他们置于烛光摇曳的中世纪书房中。男子应俯身在木桌上的一张巨大且风化的羊皮纸地图上，手持羽毛笔仿佛在绘制航线，而狗则坐在他身旁抬头仰望。在场景周围堆叠古老的皮革装订书籍、黄铜指南针和点燃的蜡烛。添加装饰性的墨水手绘边框，包含龙、帆船和城堡元素以框定构图。使用温暖的金色灯光和陈旧纸张纹理。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789545105778_3zwlh0_HSSHFHnbsAAh6O5.jpg" width="600" alt="漫画 / 故事板 - 奇幻制图师与爱犬 - Image 1">
</div>

#### 📌 详情

- **作者:** [boB](https://x.com/b0BRude)
- **来源:** [Twitter Post](https://x.com/b0BRude/status/2099951859532521977#reversed-0)
- **发布时间:** 2026年9月15日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34772)**

---

### No. 74: 漫画 / 故事板 - 复古杂志风肖像拼贴

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个用于创作 2x2 拼贴画的精美提示词，展现 1970 年代企业美学风格的男性模特，搭配森林绿西装与忧郁的影棚灯光。

#### 📝 提示词

```
创作一张电影质感的 2×2 杂志风肖像拼贴画，主角为同一位虚构的年轻男性模特，四个画幅中的面部特征与发型保持一致。他留着整洁的深色侧分发型，五官轮廓分明，面部剃须干净，表情严肃且深沉。忧郁的 {argument name="era" default="1970 年代风格"} 企业时尚摄影，{argument name="background color" default="蓝绿色"} 影棚背景，戏剧性的定向光，细腻的胶片颗粒感，深邃的阴影，柔和的色调，真实的皮肤质感，高端时尚杂志美学。
左上：特写肖像，身穿 {argument name="suit color" default="深森林绿"} 定制西装，搭配白色衬衫和酒红色领带，单手整理领带，可见复古腕表。
右上：坐在木椅上，身体前倾，神情沉思，手托下巴，身穿同款绿色西装、白衬衫和酒红色领带，黑色长裤，可见腕表。
左下：自信站立，绿色西装外套搭在肩上，袖口卷起，白衬衫搭配酒红色领带，脖子上挂着复古胶片相机，黑色长裤。
右下：身穿白衬衫搭配酒红色领带，袖口卷起，绿色西装外套搭在手臂上，单手穿过头发，表情沉思。
对称的 2×2 网格布局，画幅间有细白线分割，角色一致性，写实摄影，50mm 镜头感，浅景深，电影级灯光，细腻的模拟胶片质感，精致的复古氛围，超精细，照片级真实，4K。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789199149794_ouvrj1_HR_JOC8bYAA3zp3.jpg" width="600" alt="漫画 / 故事板 - 复古杂志风肖像拼贴 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2098617202719228006)
- **发布时间:** 2026年9月12日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34466)**

---

### No. 75: 漫画 / 故事板 - 透明玫瑰宫廷淑女

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一幅柔和的动漫奇幻肖像，描绘了一位身着半透明玫瑰色与象牙白宫廷服饰的优雅淑女，适用于精致的角色插画提示词。

#### 📝 提示词

```
创作一幅精致的动漫风格肖像插画，主角是 {argument name="character name" default="Nozomu"}，一位身处明亮宫廷环境中的优雅年轻淑女。她坐在浪漫的教堂式皇家房间内一扇高大的拱窗旁，单手轻托脸颊，目光向上，神情柔和而梦幻。采用 4:5 竖构图，近景至中全身，镜头略高于膝盖，聚焦于她的面部、飘逸的秀发和华丽的服饰。她拥有一头长长的波浪卷发，发色为 {argument name="hair color" default="灰米金色"}，带有轻盈的刘海，几缕发丝在光影中飘动；拥有一双闪烁着 {argument name="eye color" default="玫瑰粉色"} 的大眼睛，肤色白皙通透，带有淡淡的红晕，营造出一种温柔而忧郁的清晨氛围。为她穿上一套透明的宫廷风格服饰，而非传统的公主裙：采用柔软的玫瑰色与象牙白层叠薄纱面料，剪裁修身精致，带有飘逸的披肩式肩部设计、半透明袖子、蕾丝袖口、高领荷叶边、古金色刺绣、精致链条、小型花丝装饰、粉色宝石胸针以及窄丝带点缀。添加 6 个醒目的配饰元素：发间一个巨大的灰玫瑰色蝴蝶结、一个华丽的碎花金粉宝石发饰、一只垂坠的珠宝耳环、一个位于领口中央的粉色宝石胸针、一个古金色腰饰，以及她手中拿着的一封带有火漆印章式金质奖章的小型象牙白信封或卡片。背景应展示高大的白色石拱门、雕花立柱、柔软的玫瑰色窗帘，窗外是明亮的淡粉色天空和远处的哥特式尖塔，并伴有飘落的樱花瓣和闪烁的尘埃微粒。灯光采用温暖的日出逆光，呈现珍珠般的通透感，带有柔光效果、柔和的玫瑰色调、象牙白高光、细腻的古金色质感、精细的线条、复杂的织物细节、明亮的渲染效果，营造出优雅的少女奇幻氛围。避免出现皇冠、手套、泡泡袖、钟形舞会礼服、被囚禁的公主装束、现代服装、重型盔甲、深色调、强烈的阴影或可读文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789199149911_uct728_HR-PEFiaQAAP6P3.jpg" width="600" alt="漫画 / 故事板 - 透明玫瑰宫廷淑女 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789199149949_ubizxa_HR-PEFhb0AEoMnP.jpg" width="600" alt="漫画 / 故事板 - 透明玫瑰宫廷淑女 - Image 2">
</div>

#### 📌 详情

- **作者:** [のぞむ＊AIイラスト](https://x.com/ArtistaNozomu)
- **来源:** [Twitter Post](https://x.com/ArtistaNozomu/status/2098553256742097080#reversed-0)
- **发布时间:** 2026年9月11日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34467)**

---

### No. 76: 漫画 / 故事板 - 黄昏时分的动漫列车与富士山

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一幅充满意境的动漫列车内景，一位哥特风少女的剪影映衬在粉彩色的富士山日落背景下，适合用作电影感壁纸艺术。

#### 📝 提示词

```
创作一幅电影感动漫风格插画，展现黄昏时分安静的列车车厢，营造出忧郁而梦幻的氛围。场景视角位于几乎空无一人的通勤列车内部，横跨长长的深蓝色长椅和大型矩形车窗。一位娇小的少女坐在长椅右侧附近，双手交叠放在膝上，神情平静而孤独，微微侧头凝视。她身着全黑哥特风格服饰：黑色贝雷帽、带有丝带细节的深色衬衫、黑色长裙、深色长袜和黑色系带靴；她的 {argument name="hair color" default="黑色"} 头发编成两条长辫，皮肤白皙，有着精致的动漫五官。透过车窗，展现宁静的日本湖畔景观，远处的 {argument name="mountain" default="富士山"} 位于画面中心，柔和地倒映在水中，岸边有小巧的宝塔剪影和树梢。窗外天空呈现粉彩色的暮色，带有薰衣草蓝的色调、粉色的云朵，左上方窗户附近悬挂着一轮巨大的圆形 {argument name="sun or moon" default="粉色落日"}；左上角点缀着几枝粉色的樱花和花瓣。列车内部光线极其昏暗且清冷，少女大部分处于阴影中，与窗外明亮的景色形成对比。画面包含天花板附近清晰可见的三个吊环、长椅后方的一扇大型多格窗户，以及右侧一扇带有狭长窗户的列车门。采用 16:9 宽画幅构图，使用柔和的赛璐珞动漫渲染风格，内部阴影为柔和的深蓝色，外部光线为粉彩粉色与蓝色，无文字，无水印，无其他乘客。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113124326_zwiqs3_HR6tFIFXcAwQg-M.jpg" width="600" alt="漫画 / 故事板 - 黄昏时分的动漫列车与富士山 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113124492_59uxct_HR6tFIJXcAYfSXe.jpg" width="600" alt="漫画 / 故事板 - 黄昏时分的动漫列车与富士山 - Image 2">
</div>

#### 📌 详情

- **作者:** [Chiyo](https://x.com/Chiyo_memo_)
- **来源:** [Twitter Post](https://x.com/Chiyo_memo_/status/2098304867223687367#reversed-0)
- **发布时间:** 2026年9月11日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34331)**

---

### No. 77: 漫画 / 故事板 - 云朵朋友剪贴簿海报

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张充满奇趣的竖版海报，上方是蓝天中微笑的云朵，下方是九宫格手绘风格的云朵主题项目。

#### 📝 提示词

```
目标：创作一张关于可爱云朵角色的奇趣双层美学海报，上方结合真实的蓝天摄影场景，下方为手绘剪贴簿指南。

画布：3:4 竖版海报。上半部分为真实的户外天空摄影；下半部分为带有柔和颗粒质感的米色纸张插画板。

上方场景：明亮的蓝色日间天空，点缀着几朵小白云。画面中心，一朵蓬松的白云被设计成友好的角色，使用简单的黑色图形特征：正好 2 个圆点眼睛、1 个弯曲的微笑嘴巴，以及 2 只从左右两侧向上抬起的骨头状手臂。氛围轻松、轻盈、惬意且充满童趣。使用自然光，保持天空的开阔感。

下方板块标题：顶部居中手写标题：{argument name="title text" default="Cloud Friend"}。标题左侧添加一颗蓝色小星星，右侧添加一颗红色爱心，周围点缀蓝色小火花，标题下方画一条蓝色波浪线。

下方布局：以松散的 3x3 网格排列 9 个小型插画项目，每个项目下方配有手写编号说明。风格应呈现出暖白色纸张上的彩色铅笔、蜡笔和墨水质感。

九个项目及说明：
1. “hello!” — 一个带有两只黑色手臂和一颗红色小爱心的微笑云朵角色，置于粗糙的蓝色涂鸦色块中。
2. “happy face” — 由 2 个黑色圆点眼睛、1 个黑色微笑嘴巴和 2 个柔和粉色腮红圆圈组成的简单表情。
3. “arms up” — 两只分开的黑色骨头状手臂，呈欢呼姿势，带有蓝色动态线条和红色涂鸦装饰。
4. “very blue” — 一个带有蓝色蜡笔纹理的圆角矩形天空，内含正好 2 朵小白云。
5. “soft & fluffy” — 一个浅灰色铅笔勾勒的蓬松云朵轮廓，配有一颗红色小爱心。
6. “warm sun” — 一个带有短放射状光芒的黄橙色圆形太阳。
7. “gentle breeze” — 浅蓝色流动的风线，带有小漩涡和红色涂鸦装饰。
8. “daydream view” — 一个微小的极简景观，包含正好 2 棵绿树、一条绿色地平线和一个红色屋顶的小房子轮廓。
9. “good mood” — 一组欢快的涂鸦组合，包含 1 颗蓝色星星、1 颗粉色爱心、1 朵薄荷绿云朵、小圆点和红色装饰线。

页脚文字：底部居中手写小字：{argument name="footer quote" default="Look up. Little joys are floating around."}，后跟一颗红色小爱心和蓝色圆点。

视觉风格：上半部分混合真实摄影，下半部分采用稚拙的手绘日记风格。使用柔和的蓝色、米色、黑色、淡粉色、黄色、薄荷绿和红色作为点缀。所有文字保持手写感，不完美、随意且迷人。

约束：保留精确的双层构图、9 个编号项目的确切数量，以及友好的极简云朵表情。避免多余的角色、Logo、水印或密集的文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113120604_i8nxl6_HR347KhaUAA1H6V.jpg" width="600" alt="漫画 / 故事板 - 云朵朋友剪贴簿海报 - Image 1">
</div>

#### 📌 详情

- **作者:** [小小东](https://x.com/xiaoxiaodong01)
- **来源:** [Twitter Post](https://x.com/xiaoxiaodong01/status/2098107456379662554#reversed-0)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34321)**

---

### No. 78: 漫画 / 故事板 - “遗失明日博物馆”概念场景

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个电影级的提示词，描绘了一座地下博物馆，陈列着装满被遗弃的梦想和替代未来的玻璃展柜，配有体积光和充满情感的氛围。

#### 📝 提示词

```
{
  "title": "遗失明日博物馆",
  "image_description": "一座宏大的 {argument name=\"location\" default=\"隐藏在被遗忘城市之下的地下博物馆\"}。建筑令人叹为观止，无尽的大理石走廊被透过巨大玻璃天花板洒下的温暖金光照亮。成千上万个玻璃展柜向远方无限延伸。每个展柜里都装着一个从未发生的未来。其中一个装着一件从未穿过的婚纱。另一个装着一枚从未获得的诺贝尔奖章。还有一个展示着一把布满灰尘的吉他，旁边是一张属于一位过早放弃的音乐家的售罄世界巡演海报。参观者们在博物馆中沉默地行走，眼中含泪地注视着这些展品。",
  "main_subject": {
    "character": "一个独自站立的年轻人",
    "appearance": "深色大衣，略显磨损的鞋子，疲惫的双眼",
    "expression": "震惊且充满情感",
    "focus": "清晰对焦"
  },
  "story_element": {
    "twist": "在博物馆的尽头，他发现了一个专门陈列他自己被遗弃梦想的房间。",
    "question": "如果你能看到你本可能拥有的生活，你会怎么做？"
  },
  "environment": {
    "location": "地下博物馆",
    "lighting": "金色电影级灯光",
    "atmosphere": "静谧、感人、神圣"
  },
  "cinematography": {
    "camera": "ARRI Alexa 65",
    "lens": "50mm 变形镜头",
    "shot_type": "广角电影镜头",
    "depth_of_field": "浅景深",
    "composition": "获奖级叙事构图"
  },
  "mood": [
    "令人心碎",
    "发人深省",
    "忧郁",
    "唯美"
  ],
  "style": {
    "reference": "Christopher Nolan 与 Denis Villeneuve 的风格融合",
    "quality": "超写实",
    "resolution": "8K",
    "film_grain": true,
    "volumetric_lighting": true
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113117731_dedtgp_HR3fUw9awAAdMNt.png" width="600" alt="漫画 / 故事板 - “遗失明日博物馆”概念场景 - Image 1">
</div>

#### 📌 详情

- **作者:** [Compound Learning - Tech | Science](https://x.com/SheBuildsAI_)
- **来源:** [Twitter Post](https://x.com/SheBuildsAI_/status/2098078552193384859)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34317)**

---

### No. 79: 漫画 / 故事板 - 《The Last Train Home》电影感场景

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个令人难忘且唯美的电影感提示词，描绘了深山中一座被遗弃的雪中火车站，以及一列神秘发光的复古火车。

#### 📝 提示词

```
{
  "title": "The Last Train Home",
  "image_description": "一个令人惊叹的电影感场景，地点位于 {argument name=\"location\" default=\"深山中一座被遗弃的火车站\"}。浓雾在空荡的站台上翻涌，复古灯具在雾气中投射出温暖的金色光芒。一位身穿深色羊毛大衣的孤独旅人站在旧皮箱旁。一列古老的火车从浓雾中缓缓驶出，每一扇车窗都散发着柔和的光芒。雪花在车站周围静静飘落。站台上悬挂着一块饱经风霜的牌子，上面写着：HOME。当旅人意识到这列火车本不该存在时，他的眼中充满了复杂的情绪。",
  "story_element": {
    "twist": "这列火车只会出现一次，且恰好在一个人去世前的一小时出现。"
  },
  "environment": {
    "location": "被遗忘的山区火车站",
    "weather": "降雪与浓雾",
    "time": "午夜"
  },
  "cinematography": {
    "shot_type": "宽银幕电影镜头",
    "camera": "ARRI Alexa 65",
    "lens": "50mm 变形镜头",
    "composition": "对称式叙事构图"
  },
  "lighting": {
    "type": "温暖的复古灯光与清冷的月光交织",
    "effects": [
      "体积雾",
      "雪花颗粒",
      "氛围光晕"
    ]
  },
  "mood": [
    "感性",
    "神秘",
    "苦乐参半",
    "怀旧"
  ],
  "quality": {
    "style": "获奖级电影杰作",
    "realism": "超写实主义",
    "resolution": "8K",
    "IMAX_quality": true,
    "film_grain": true
  }
}
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113116188_b7au0q_HR2abiobIAAjIXT.png" width="600" alt="漫画 / 故事板 - 《The Last Train Home》电影感场景 - Image 1">
</div>

#### 📌 详情

- **作者:** [Compound Learning - Tech | Science](https://x.com/SheBuildsAI_)
- **来源:** [Twitter Post](https://x.com/SheBuildsAI_/status/2098002802375303462)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34314)**

---

### No. 80: 漫画 / 故事板 - 不死吸血鬼国王宝座

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个黑暗奇幻概念艺术提示词，用于在闹鬼的教堂宝座室中生成哥特式不死君主，背景包含幽灵军队和不祥的铭文。

#### 📝 提示词

```
创作一幅超精细的黑暗奇幻哥特式插画，描绘 {argument name="character name" default="一位不死吸血鬼国王"} 端坐在废弃教堂的宝座室中。核心人物是一位面色苍白、如尸体般的君主，留着飘逸的 {argument name="hair color" default="白色长发"}，双眼闪烁红光，嘴角流血，头戴锯齿状黑色王冠。他身穿华丽的黑色盔甲，上面布满了骷髅、尖刺、锁链、红色宝石以及破烂的深红色与黑色皇家袍服。他傲慢地坐在镶嵌着骷髅的石制宝座上，一只手搭在扶手上，另一只手紧握一把长长的仪式剑，剑柄饰有骷髅，配有哥特式十字护手、红色宝石和苍白的剑刃。在他周围布置 9 个清晰可见的超自然人物或生物：1 个巨大的半透明幽灵战士手持长剑悬浮在他身后，1 个较小的漂浮幽灵靠近月光下的拱门，4 个朦胧的人类灵魂位于中景的楼梯和阳台上，2 个身穿盔甲的幽灵士兵在右下方手持武器，以及 1 只在左下方前景咆哮的幽灵狼。场景设定在一座巨大的黑色石砌教堂中，配有破损的尖拱、高耸的柱子、蜡烛、锁链、开裂的台阶、骷髅和破烂的红色旗帜。包含 3 条清晰可辨的旗帜或石刻铭文：左侧悬挂的旗帜写着 {argument name="left banner text" default="BLOOD BEYOND DEATH"}，右侧悬挂的旗帜写着 {argument name="right banner text" default="KINGS DIE BUT LEGENDS HAUNT FOREVER"}，左下方的石块上写着 {argument name="stone inscription" default="SWORDS REMEMBER WHAT MEN FORGET"}。透过巨大的拱门，展现远处的哥特式尖顶城堡、拱桥、飞行的蝙蝠、风暴云、寒冷的薄雾和一轮巨大的深红色血月。采用电影级低角度构图，超写实数字绘画，复杂精细的概念艺术细节，冷蓝灰色雾气与深红色调形成对比，戏剧性的月光，烛光，体积雾，锐利的盔甲高光，恐怖的皇家氛围，无现代物品，非卡通风格。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113122277_di5p03_HR1vMAGbkAAltLK.jpg" width="600" alt="漫画 / 故事板 - 不死吸血鬼国王宝座 - Image 1">
</div>

#### 📌 详情

- **作者:** [Lee Penkman](https://x.com/LeeLeepenkman)
- **来源:** [Twitter Post](https://x.com/LeeLeepenkman/status/2097966510111432791#reversed-0)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34327)**

---

### No. 81: 漫画 / 故事板 - Hand-drawn travel journal illustration

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

A detailed prompt to transform a reference photograph into a traditional hand-drawn travel journal sketch using watercolor and colored pencil aesthetics on aged paper.

#### 📝 提示词

```
Transform the reference photograph into a delicate {argument name="style" default="hand-drawn travel journal illustration"} while preserving the original composition, architecture, people, trees, grass, road, and overall perspective. Use a traditional colored-pencil and watercolor sketch aesthetic on warm, slightly aged cream paper. Keep the buildings recognizable but simplify them into expressive hand-drawn shapes, with visible pencil strokes, loose watercolor washes, subtle paper grain, imperfect outlines, and gentle cross-hatching. Preserve the peaceful {argument name="atmosphere" default="rainy-day"} atmosphere, soft overcast sky, warm beige and muted buildings, fresh green lawn, scattered people walking with umbrellas, wet pavement, trees, benches, puddles, and distant cars. Use a muted vintage travel-sketch palette with natural imperfections and understated colors. Place the illustration in the lower portion of the page with generous cream-colored negative space around it. Add elegant handwritten typography above: ‘{argument name="heading" default="Rainy Days"}’, and below: — Quiet moments —. Minimal, nostalgic, artistic travel magazine aesthetic, analog photography transformed into a personal sketchbook memory, sophisticated and authentic, no photorealism.
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789113114721_dynjxc_HR1SmTGakAAv97s.jpg" width="600" alt="漫画 / 故事板 - Hand-drawn travel journal illustration - Image 1">
</div>

#### 📌 详情

- **作者:** [Selina](https://x.com/selinatasnim1)
- **来源:** [Twitter Post](https://x.com/selinatasnim1/status/2097923838449516732)
- **发布时间:** 2026年9月10日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34219)**

---

### No. 82: 漫画 / 故事板 - 电影感哥特萝莉 3x3 动漫剧照

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一张九宫格电影感动漫联系表，展示一位身处玫瑰宫殿中的哥特萝莉女主角，适用于角色 PV 概念设计和视觉叙事。

#### 📝 提示词

```
目标：创作一张电影感动漫风格的 3x3 联系表，主角为 {argument name="character name" default="一位甜美的棕发哥特萝莉女主角"}，场景设定在优雅的玫瑰宫殿内部，每个分镜看起来都像是同一部浪漫奇幻电影的剧照。

画布：宽屏 16:9 图像，划分为 3 列 3 行，共 9 个等大的矩形分镜。分镜之间使用细白线间隔。每个分镜都带有精致的装饰性胶片边框，配有微小的玫瑰图案、边角花纹、淡淡的引导线和装饰性标记，呈现出顶级动漫关键视觉图的效果。

角色设计：一位年轻的动漫少女，留着非常长的波浪卷 {argument name="hair color" default="暖栗棕色"} 头发，琥珀金色的眼睛，面带红晕，表情开朗温柔。她身穿酒红色与奶油色相间的哥特萝莉裙：短款酒红色夹克或开衫，象牙白荷叶边衬衫，领口配有带玫瑰胸针的大红蝴蝶结，层叠的奶油色蕾丝裙摆，外罩酒红色格纹裙，配有蝴蝶结、丝带、褶边、白色蕾丝袜和深色厚底玛丽珍鞋。增加一个带有金链和垂坠三叶草饰品的酒红色玫瑰丝带发饰。整体色调：{argument name="color palette" default="暖玫瑰红、象牙奶油色、金色、柔和棕色以及发光的桃色光影"}。

场景与氛围：奢华的教堂式宫殿大厅或温室，布满玫瑰、高大的拱形窗户、吊灯、大理石地板、华丽的家具、蜡烛和金色阳光。红色玫瑰花瓣在每个分镜中飘浮。光影梦幻、温暖、背光，具有浅景深、柔和的焦外成像效果，呈现出高度精致的动漫插画品质。

分镜布局，共 9 个镜头：
1. 左上：全身远景，少女站在宏伟的拱形大厅中央，裙装清晰可见，周围环绕着玫瑰和阳光。
2. 上中：正面特写，明媚微笑并向观众伸出一只手，发丝飘动，前景有花瓣飘落。
3. 右上：侧脸半身像，面向右侧，马尾辫和长发在窗外淡雅的城市或宫殿天际线背景下飘动。
4. 中左：背部四分之三侧身镜头，强调长发和酒红色服装的质感与卷度，背景是模糊的金色宫殿内部。
5. 中中：坐姿或倚靠在桌边的肖像，托腮微笑，背景有书籍、玫瑰、画框和烛光装饰。
6. 中右：动态舞蹈或旋转镜头，双眼幸福地闭着，裙摆大幅度张开，单臂伸展，花瓣扫过画面。
7. 下左：发饰的极近距离细节：附着在头发上的酒红色玫瑰、缎带、金链和垂坠饰品。
8. 下中：腿部及鞋子的近距离细节，走在光亮的大理石地面上，穿着带蝴蝶结的白袜和深色厚底玛丽珍鞋，地面反射着散落的玫瑰花瓣。
9. 下右：过肩特写，她回眸看向观众，带着温柔的微笑，背景是玫瑰和温暖的灯光。

视觉风格：高端日本动漫插画，电影预告片剧照，细腻的线条，复杂的服装细节，透亮的皮肤，丝滑的发丝渲染，柔和的电影感景深，温暖的浪漫奇幻氛围，优雅且精致，如同宣传 PV 的分镜脚本。

约束条件：在所有 9 个分镜中保持角色、服装、发型和配饰的一致性。不要添加对话、标题、Logo、字幕、水印或额外角色。保持连贯的电影剧照序列，而非 9 张不相关的插画。使用 {argument name="render quality" default="超精细、电影感、柔焦动漫关键视觉图"}。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942372406_7yljpe_HRwf1PcaoAAWo3w.jpg" width="600" alt="漫画 / 故事板 - 电影感哥特萝莉 3x3 动漫剧照 - Image 1">
</div>

#### 📌 详情

- **作者:** [びーぐる / Beagle Works](https://x.com/beagle_dog_inu)
- **来源:** [Twitter Post](https://x.com/beagle_dog_inu/status/2097586729993814160#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34060)**

---

### No. 83: 漫画 / 故事板 - 浮世绘风格：奥尔菲斯山径

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成一幅日本浮世绘风格的神话景观，描绘了奥尔菲斯、幽灵女子、仙鹤、樱花以及黎明时分的鸟居小径。

#### 📝 提示词

```
创作一幅宽幅横向、受浮世绘启发的神话景观插画，采用陈旧的木版画风格，呈现明显的纸张纹理、柔和的墨迹质感、细腻的黑色线条，以及由靛蓝色山脉、朦胧灰蓝色山谷、褪色的鲑鱼粉色天空和柔和奶油色高光组成的暗色调。在前景中央放置一位年轻的希腊诗人或旅行者，{argument name="character name" default="Orpheus"}，留着深色卷发，头戴月桂花环，神情忧虑地回头张望，身穿浅色长袍，外披红色斗篷，身侧拿着一把小竖琴。在左侧，从阴影笼罩的悬崖和迷雾中，展现一位半透明的幽灵女子，身着飘逸的白色长袍，留着长长的深色头发，正向他伸出一只手，显得空灵且部分融入雾气之中。画面上方天空中有且仅有两只飞翔的仙鹤，右上角有一轮硕大的苍白太阳，远处的山顶上有一座红色鸟居，一条蜿蜒的浅色石径从右下角前景穿过朦胧的山峦向鸟居延伸。左上角和左下角用覆盖着粉色花朵的深色樱花树枝装点，许多散落的粉色花瓣在整个构图中呈对角线飘落。添加两块垂直的日式纸质标题牌：左上角一块写着 {argument name="left plaque text" default="冥より暁へ"}，右侧中部一块写着 {argument name="right plaque text" default="音の道"}，字符下方配有一枚红色小印章。将日本浮世绘构图与微妙的古希腊神话主题相结合，呈现电影感但扁平的版画效果，忧郁而梦幻，无现代物品，无写实摄影感，无额外人物，无额外鸟类，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942317332_gb9gnc_HRwUgB9asAAUjYM.jpg" width="600" alt="漫画 / 故事板 - 浮世绘风格：奥尔菲斯山径 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942317561_w0z8a1_HRwUgjrbMAAf6k-.jpg" width="600" alt="漫画 / 故事板 - 浮世绘风格：奥尔菲斯山径 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942317322_7efjyb_HRwUhIMbAAA9Hsg.jpg" width="600" alt="漫画 / 故事板 - 浮世绘风格：奥尔菲斯山径 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942319130_z8kvao_HRwUiM5bkAAg5cH.jpg" width="600" alt="漫画 / 故事板 - 浮世绘风格：奥尔菲斯山径 - Image 4">
</div>

#### 📌 详情

- **作者:** [Dhruval](https://x.com/dhruvalgolakiya)
- **来源:** [Twitter Post](https://x.com/dhruvalgolakiya/status/2097574706228703374#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33991)**

---

### No. 84: 漫画 / 故事板 - 河童女孩与稻草人女巫

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一幅竖构图的动漫乡村场景，描绘了一位穿着河童装束、受惊的女孩在阳光明媚的麦田中偶遇一位友好的稻草人女巫。

#### 📝 提示词

```
创作一幅明亮的竖构图动漫插画，背景是金色的麦田，天空湛蓝，点缀着柔软的白云，远处可见青翠的山峦。在前景中，展示 {argument name="main character" default="一位受惊的河童主题女孩"}：一位留着深青色短波波头、有着琥珀色大眼睛、脸颊泛红、张嘴受惊的动漫小女孩。她穿着一件亮面淡绿色连帽雨衣，雨衣造型像河童，兜帽上有黄色的鸭嘴、顶部有卡通大眼睛，还有深青色的叶状发饰、深色纽扣、袖口装饰、两个前口袋，以及胸前的一枚白色小名牌，上面写着 {argument name="name tag text" default="かっぱ"}。给她加上黄色手套和黄色雨靴，双手举起做出受惊的姿势。在她身后右侧，展示 {argument name="second character" default="一位微笑的稻草人女巫女孩"}：一位身材苗条的动漫女孩，留着凌乱的深棕色短发，有着粉紫色眼睛，面带温暖的微笑，穿着破旧的黑色乡村连衣裙，配有泡泡袖、绳索腰带、领口丝带蝴蝶结、草编袖口，以及一顶带有深色羽毛的宽大磨损草帽；她像友好的稻草人一样挥手。画面中包含 2 个角色：前方的河童装束女孩和后方的稻草人女巫女孩。包含 3 个清晰可见的文字/强调元素：稻草人上方的一个大对话气泡，写着 {argument name="speech bubble text" default="こんにちは〜！どこ行きますか?"}；河童女孩头部附近的一组黄色标点符号“!?”；以及雨衣上写着“かっぱ”的小标签。采用动态漫画风格的线条、富有表现力的面部表情、高细节的衣物褶皱、温暖的阳光、极度前景中麦秆虚化的浅景深，营造出欢快的田园冒险氛围。构图采用竖向，河童女孩位于左下前景，稻草人女孩位于右上中景。请务必保留指定的日语文本，并确保字体清晰易读。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942368984_6ntm42_HRwUd4MbYAAeFO9.jpg" width="600" alt="漫画 / 故事板 - 河童女孩与稻草人女巫 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942370473_pb3i9f_HRwUe_ra0AAW_Mx.jpg" width="600" alt="漫画 / 故事板 - 河童女孩与稻草人女巫 - Image 2">
</div>

#### 📌 详情

- **作者:** [お茶会WCH](https://x.com/ochakaiwch)
- **来源:** [Twitter Post](https://x.com/ochakaiwch/status/2097574098146857435#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34058)**

---

### No. 85: 漫画 / 故事板 - 障子门前的低语动漫场景

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个电影感动漫提示词，用于创作一个幽默的日式传统房间场景，描绘身穿和服的女孩们在低语，而一名女仆正从障子门后窥视。

#### 📝 提示词

```
创作一张温馨的电影感动漫插画，场景设定在黄昏时分的日式榻榻米房间内。画面中需精确呈现三名女孩：左侧房间内有两名身穿和服的日本女孩，正对着障子推拉门窃窃私语；右侧门外有一名金发蓝眼的外国女仆，正透过半透明的纸门窥视，并用一根手指抵在唇边。最左侧的女孩留着凌乱发髻的深色头发，身穿素雅的紫色和服，一只手遮在嘴边，表情惊讶地低语。第二名女孩大部分背对镜头，身穿绿色和服，戴着花朵发饰，身体前倾，耳朵贴近墙壁或门，仿佛在偷听。门外的女仆拥有 {argument name="hair color" default="金色"} 头发、大大的蓝色眼睛、带有荷叶边的白色女仆头饰、黑白配色的女仆装，表情略显天真而神秘。在两名和服女孩上方的灰泥墙上，添加垂直的黑色书法文字 {argument name="wall calligraphy" default="壁に耳あり 障子にメアリー"}。画面右半部分为木质障子格栅门，纸屏风后透出柔和的剪影和温暖的背光。前景：一张部分虚化的矮木桌，桌上有两个蓝白相间的茶杯、一小碟甜点，左下角有一个虚化的花瓶。背景：素雅的挂轴和简约的插花。风格：高质量日本动漫主视觉图，绘画感光影，柔和的景深，右下角温暖的灯笼光，细腻的木纹，精致的布料褶皱，舒适的古典室内环境，幽默的视觉双关氛围，无现代物品，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942358206_y58zxc_HRwTragboAAsKLB.jpg" width="600" alt="漫画 / 故事板 - 障子门前的低语动漫场景 - Image 1">
</div>

#### 📌 详情

- **作者:** [かきみ～ら🍁sports🍡🐬](https://x.com/Persimummies)
- **来源:** [Twitter Post](https://x.com/Persimummies/status/2097573179380392343#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34039)**

---

### No. 86: 漫画 / 故事板 - 兔绅士角色设定图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一份精细的动漫奇幻角色参考图，包含银发兔耳贵族的全身转面图、肖像、服装特写及配色方案。

#### 📝 提示词

```
目标：为 {argument name="character name" default="一位英俊的兔绅士"} 设计一份优雅的动漫角色设定图，角色为拥有银白色长发和高耸白兔耳的男性，展现出带有月亮与时钟元素的精致奇幻贵族形象。

画布：宽幅横向角色参考图，背景为柔和的薰衣草灰，装饰有精致的天体 UI 边框、纤细的白色几何线条、悬挂的星星、月亮、时钟圆环以及叶片植物剪影，配色采用海军蓝、象牙白、薰衣草紫、银色和柔和紫色的淡雅色调。

布局：左侧使用 3 个全身转面图：1 个向左的侧面图、1 个正面图和 1 个背面图。右侧包含 2 个大型肖像面板：上方肖像表现冷静、冷峻的表情，手持怀表链靠近脸部；下方肖像表现害羞脸红的表情，一只手靠近颈部，一只兔耳向前垂下。在全身图与肖像之间，包含 6 个垂直细节特写面板：1 个领口的领巾与胸针、1 个耳朵与耳环细节、1 个怀表与表链细节、1 个袖口刺绣细节、1 个外套下摆刺绣细节，以及 1 个蓬松尾巴加靴子细节。最左侧添加 1 条垂直色板，包含 6 个圆形色块：深蓝、灰白、薰衣草紫、炭黑、淡粉和白色，下方带有小型新月图标。

主体细节：角色为身材高挑、优雅的年轻男性，皮肤白皙，留着凌乱的 {argument name="hair color" default="银白色"} 长发，拥有狭长的薰衣草灰色眼睛、柔软的睫毛，以及内侧带有淡粉色绒毛的长白兔耳。表情冷漠、忧郁且俊美。身着正式的奇幻服装：深海军蓝长燕尾服配银色滚边，一侧披着不对称的象牙白肩披，高领白色荷叶边衬衫，系着带有椭圆形宝石胸针的淡薰衣草色领巾，炭灰色马甲，修身黑色长裤，白色手套，黑色及膝高跟靴，装饰性链条，怀表，钟面装饰，新月与星星点缀，以及沿袖口和外套下摆的叶片刺绣。背面图必须展示披肩、开叉燕尾、类似背带的腰部束带以及一个小巧圆润的白色蓬松兔尾。

视觉风格：高精细度日式动漫插画，角色设定图 / 概念艺术展示，线条细腻，干净的赛璐璐阴影融合柔和的绘画渐变，瓷器般的皮肤，复杂的服装装饰，优雅的乙女游戏美学，梦幻的月光氛围，柔和的淡雅光影，特写面板细节清晰。

文字内容：不包含可读的标题文字或标签；仅使用装饰条和类似界面的形状。

约束：保持图像为单一连贯的角色参考图，而非漫画。保留视图、肖像面板、细节面板和色块的精确数量。避免出现额外角色，避免现代街头服饰，避免高饱和度色彩，且不要添加水印或 Logo。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942376192_sl7ycm_HRv6MaRbAAAoksD.jpg" width="600" alt="漫画 / 故事板 - 兔绅士角色设定图 - Image 1">
</div>

#### 📌 详情

- **作者:** [🐹🐹](https://x.com/hmst_yyyy)
- **来源:** [Twitter Post](https://x.com/hmst_yyyy/status/2097545150608417251#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34066)**

---

### No. 87: 漫画 / 故事板 - 九宫格动漫分镜拼贴

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成 3×3 电影感动漫蒙太奇，主角为银发少女，配有日式歌词风格字幕，适用于音乐视觉效果、项目分镜或专辑封面。

#### 📝 提示词

```
目标：创建一个电影感的 3×3 动漫关键视觉拼贴，展示 {argument name="character name" default="一位未命名的银发少女"} 在九个情感分镜中的表现，类似于音乐视频分镜或视觉小说结局蒙太奇。

画布：宽屏 16:9 图像，约 1200×675，由粗黑边框分割成 9 个矩形面板，排列为 3 列 3 行。使用黄昏至夜晚的忧郁色调，带有柔和光晕、胶片颗粒、浅景深、雨/雪状粒子以及高细节的动漫渲染。

主角：一位年轻动漫少女，皮肤白皙，凌乱的长 {argument name="hair color" default="银白色"} 双马尾，系着黑色丝带，琥珀色金眸，面容精致，表情忧郁。服装为暗黑街头风：超大号黑色露肩夹克、黑色吊带、部分分镜中穿着破洞牛仔裤、全身镜头中穿着运动鞋、在演唱分镜中佩戴耳机。确保她在九个面板中形象保持一致。

布局与面板内容：使用 9 个独立面板。
1. 左上：正面特写，少女向观众伸出一只手，前景手指柔和模糊；背景为苍白天空。添加日文文本「まだ、終わってない。」及小型英文副标题“Not yet. The story goes on.”
2. 中上：侧视图，少女坐在日落时的屋顶或阳台边缘，远处是城市天际线和天线，橙紫色云朵。添加大型手写日文文本「どこまで行けるんだろう」及微型英文副标题，暗示“What a beautiful sunset.”
3. 右上：侧卧面部特写，琥珀色眼睛突出，右侧为深色背景。添加日文文本「きっと、わたしはわたしでいい。」及英文副标题“It’s okay to be me.”
4. 左中：雨夜霓虹城市中的侧面半身像，头向后仰，闭眼，发丝飘动，背后是发光的摩天大楼灯光。添加日文文本「痛みだって歌になる。」及英文副标题“Even pain can be a song.”
5. 正中：强烈的正面特写，仅露出眼睛和深色衣袖上方的上半脸，背后是抽象的黑色笔触涂鸦；无需大型副标题。
6. 右中：破碎的镜面场景，她映在多个碎片中，一只手伸向碎玻璃；冷蓝色灯光。添加日文文本「いくつもの、わたし。」及英文副标题“So many me. Still me.”
7. 左下：录音室场景，侧视图，她对着大型电容麦克风和防喷罩深情歌唱，佩戴黑色包耳式耳机。添加日文文本「声になりたかった。」及英文副标题“I wanted to be a voice.”
8. 中下：背面全身镜头，她独自走在布满涂鸦的隧道或地下通道中，走向明亮的出口，超大号夹克从肩头滑落。添加非常大的白色手写日文文本「また、行ける。」及小型英文副标题“Go to the next. On to the next.”
9. 右下：温暖亲密的特写，她躺在枕头或床上，带着疲惫而柔和的表情看向观众。添加日文文本「また、どこかで。」及英文副标题“See you somewhere again.”

排版：混合优雅的竖排日文明朝体和富有表现力的白色手写笔刷字体。英文翻译应为小型衬线体，放置在日文下方或附近。保持文字清晰，同时融入电影感图像中。

视觉风格：超细节现代动漫插画，情感化 J-pop 专辑封面美学，发丝上的柔和轮廓光，琥珀色眼睛中的闪烁高光，绘画感背景，写实光影，戏剧性裁剪，黑色面板边框，细微的色差，无标志或水印。

可定制情绪：整体感受应为 {argument name="emotional tone" default="苦乐参半、坚韧且静谧的希望"}。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942355876_rfk2mc_HRvzc6CaUAARo-d.jpg" width="600" alt="漫画 / 故事板 - 九宫格动漫分镜拼贴 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942355922_jueg0v_HRvzc52boAAkF1O.jpg" width="600" alt="漫画 / 故事板 - 九宫格动漫分镜拼贴 - Image 2">
</div>

#### 📌 详情

- **作者:** [OwO](https://x.com/monolith_v_game)
- **来源:** [Twitter Post](https://x.com/monolith_v_game/status/2097537739629731884#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34038)**

---

### No. 88: 产品营销 - GPT Image 2 编辑风格美食海报提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

使用 GPT Image 2 生成垂直编辑风格美食海报的提示词，展示带有建筑感蒸汽效果的蒸饺。

#### 📝 提示词

```
4:5 垂直比例编辑风格美食海报，画面中心为一盘手工蒸饺，盛放在深色锤纹陶瓷盘中，置于炭黑色石质台面上。构图居中，具有强烈的建筑感。

一股高耸的热气直接升腾于饺子之上，成为主导性的图形元素。不要柔和蓬松的蒸汽，而是将热气塑造成层叠的半透明薄片、几何折面、垂直平面和重叠的玻璃状结构，营造出一种由热量构建的建筑纪念碑之感。

仅可见厨师的双手和前臂。一只手臂从左上方自然伸入，穿着整洁的象牙白厨师袖口，正小心翼翼地将新鲜微型蔬菜撒在饺子上。另一只手从右下方伸入，扶着圆形竹制蒸笼的边缘，暗示这道菜刚刚上桌。不出现面部或完整的人体形象。

背景为扁平化的哑光炭黑厨房墙面，细节极简。远处仅包含一个功能性物体：一个暖色调的拉丝铜酱锅，处于柔焦状态。

采用克制的配色方案：炭黑、暖象牙白、石灰色、柔和铜色、淡竹棕色和清新的草本绿。戏剧性的定向餐厅灯光在饺子上形成雕塑般的高光、逼真的水汽、柔和的阴影以及可见的热度。

在上升的热气后方放置一个巨大的半透明数字“{argument name="number" default="03"}”，部分被蒸汽建筑结构遮挡，并融入构图之中，而非悬浮其上。

在底部，以高窄紧凑的编辑风格字体呈现单词“{argument name="title" default="DUMPLINGS"}”，字间距宽松。在边缘添加极小的辅助文字，营造精致的美食杂志氛围。

极简、高端、触感丰富、静谧奢华，将美食摄影与瑞士编辑设计及建筑海报构图相结合。体现热量、精准、仪式感与宁静。无杂乱元素，无卡通风格，无过多道具。4:5 比例。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063417834_gh1k4n_HSzJA1wXYAAySMz.jpg" width="600" alt="产品营销 - GPT Image 2 编辑风格美食海报提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063418241_d8fu6z_HSzJBUNWEAAhThx.jpg" width="600" alt="产品营销 - GPT Image 2 编辑风格美食海报提示词 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1790063418355_bi7mjd_HSzJBr7WoAAz9u1.jpg" width="600" alt="产品营销 - GPT Image 2 编辑风格美食海报提示词 - Image 3">
</div>

#### 📌 详情

- **作者:** [Mira](https://x.com/miratechtool)
- **来源:** [Twitter Post](https://x.com/miratechtool/status/2102276163317965292)
- **发布时间:** 2026年9月22日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35156)**

---

### No. 89: 产品营销 - 橙色屋顶时尚摄影提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个充满活力的时尚摄影提示词，展示了一位金发女子站在橙色屋顶上，具有夸张的透视效果和鲜艳的色彩。

#### 📝 提示词

```
创作一张 9:16 比例的超写实时尚摄影作品，画面中是一位时尚的年轻金发女子，身穿鲜艳的橙色超大短款夹克、白色修身背心、宽松奶油色工装裤和厚底白色运动鞋。她侧身蹲在明亮的橙色城市屋顶边缘，一只运动鞋极度靠近镜头，营造出夸张的前景透视效果。她的身体微微背对镜头扭转，同时回头越过肩膀，脸上带着俏皮而自信的表情。一只手抓住屋顶边缘，另一只手随意地调整着她的橙色太阳镜。风吹拂着她的头发和夹克。采用极低的贴地广角视角拍摄，景深戏剧化，构图略微倾斜且非传统，前景畸变强烈，充满动感的抓拍瞬间。她身后是生动的钴蓝色天空，点缀着大片白云，以及带有橙色和珊瑚色装饰的现代彩色建筑。色彩调色板以极其鲜艳的橙色、蓝色和白色为主，阳光强烈，阴影深邃自然，色彩饱和度高，皮肤纹理真实，发丝细节逼真，呈现真实的户外摄影质感，散发自发的时尚编辑活力，透视略带超现实感但完全符合照片级真实度。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977644263_q6cmws_HSqh7IFaMAAgThh.jpg" width="600" alt="产品营销 - 橙色屋顶时尚摄影提示词 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977644272_ydxbpc_HSqh7p4a8AExMZ7.jpg" width="600" alt="产品营销 - 橙色屋顶时尚摄影提示词 - Image 2">
</div>

#### 📌 详情

- **作者:** [Cherry](https://x.com/hey_am_cherry)
- **来源:** [Twitter Post](https://x.com/hey_am_cherry/status/2101670230556852685)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35115)**

---

### No. 90: 产品营销 - 高速水珠人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成一张超写实高速电影感照片的提示词，画面中一名年轻男子被悬浮的水珠环绕。

#### 📝 提示词

```
一张超写实的高速电影感摄影作品，画面主体是一位二十岁出头、英俊非凡的年轻男子。他伸出一只手径直朝向镜头，仿佛要冲破这凝固的瞬间。他拥有一头浓密自然的黑色波浪卷发，眉毛深邃有力，深褐色的双眼炯炯有神，下颌线条轮廓分明，留着淡淡的自然胡茬，皮肤质感真实细腻，毛孔清晰可见，面部细节丰富。

男子处于完全静止且极其清晰的状态，而数千颗晶莹剔透的水珠悬浮在他周围的半空中，定格在撞击的确切瞬间。大小不一的水珠环绕着他的脸庞、双手、头发和肩膀，每一颗都清晰可辨，呈现出逼真的反射、折射和微小的高光。他伸出的手极度靠近镜头，营造出强烈的景深感和透视效果。

动态的水花飞溅和细微的运动轨迹仅存在于周围的水中，与他完美定格的姿态形成鲜明对比。采用微距摄影美学，超高速快门捕捉，极致细节呈现，浅景深效果，眼睛和水珠锐利如刀，电影级布光，戏剧性的高光与阴影，高端奢华广告摄影风格，深色氛围背景，淡淡的雾气，体积光射线，符合真实物理规律，85mm 微距镜头，f/2.8 光圈，HDR，8K 分辨率，照片级真实感，自然肤色，精致的色彩分级，令人惊叹的景深，无人工修饰的面部痕迹，无文字，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977648774_2enzt8_HSp-I0DbkAAM6DX.jpg" width="600" alt="产品营销 - 高速水珠人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2101630890212511942)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35123)**

---

### No. 91: 产品营销 - 奢华香水明暗对照法肖像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成超写实奢华香水广告照片的提示词，画面以戏剧性的明暗对照光影呈现男士面部特写。

#### 📝 提示词

```
超写实奢华香水广告摄影作品，主角为一名二十岁出头、英俊非凡的年轻男子。采用极致特写肖像构图，画面中仅可见其半侧脸庞。他唯一可见的眼睛是绝对的视觉焦点——虹膜细节锐利清晰，深棕色眼眸，目光强烈而迷人地直视镜头，睫毛浓密自然，眉形英挺，鼻梁高挺雕塑感强，颧骨与下颌线轮廓分明，留有细微自然的胡茬，皮肤纹理真实细腻，毛孔清晰可见。
脸部的另一半戏剧性地隐入深邃的黑色阴影中，营造出强烈的明暗对照（Chiaroscuro）效果。背景近乎纯黑，无缝黑暗，呈现出高端奢华香水广告的精致美学。微妙且受控的轮廓光勾勒出可见的面部线条，极具张力的影棚布光，浓郁的黑位，精致的对比度，优雅神秘的氛围，高级编辑类美容摄影，电影般的景深感，85mm 微距人像镜头，浅景深，超高清皮肤细节，照片级真实感，8K HDR，完美构图，成熟男性优雅气质，无文字，无 Logo，无水印，无可见香水瓶。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977641817_7mgjjz_HSonJMkaIAASSsA.jpg" width="600" alt="产品营销 - 奢华香水明暗对照法肖像 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2101535226279371060)
- **发布时间:** 2026年9月20日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35110)**

---

### No. 92: 产品营销 - 电影级影棚人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于生成具有纹身和腕表的男性电影级超写实影棚人像的提示词，强调戏剧性布光与面部特征保留。

#### 📝 提示词

```
创建同一位男性的电影级超写实影棚人像，保留其面部身份、面部结构、发型、胡须、肤色及独特特征。

他直视镜头，眼神强烈，表情严肃、自信且具威慑力。身穿挺括的白色正装衬衫，领口微开。纹身的双臂搭在深色表面上，双手在前景中自然交握。添加一款精致奢华的腕表。

使用来自单侧的戏剧性暖色侧光，营造深邃的电影感阴影和轮廓分明的面部特征，同时保留真实的皮肤纹理、毛孔和胡须细节
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803924733_8hsv1z_HSjMUR0bwAAEe3S.jpg" width="600" alt="产品营销 - 电影级影棚人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2101153881220907439)
- **发布时间:** 2026年9月19日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35003)**

---

### No. 93: 产品营销 - GPT Image 2 真人角色街拍

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)

#### 📖 描述

一个用于将动漫/游戏角色转换为写实街头摄影风格的提示词模板，使用 GPT Image 2，注重自然光线和真实的城市环境。

#### 📝 提示词

```
[角色名称]，真人版本，忠实于核心角色身份。
一组城市街拍摄影 × 时尚角色街拍快照 × 自然生活感。
角色真实地出现在现代城市街道上，呈现为一组街拍图像。根据角色气质自动决定街景、现代服装转换、动作、站姿、回眸瞬间、相机位置、景别和构图。
保留发型、代表色、标志性配饰和身份气质，不要完全复制原始服装。
真实的街道、橱窗、咖啡店、巷口、斑马线、路标、模糊的路人背景、自然的空间深度。
自然光或城市环境光，轻微的抓拍感，高端街拍质感，逼真的摄影纹理，主体清晰，背景具有景深效果。
无 UI，无截图感，无多余文字。
左上角风格化 "V" + 猫元素 logo，右下角 voxCAT 签名。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803922169_fcf50q_HSfcWWbbUAA5uyR.jpg" width="600" alt="产品营销 - GPT Image 2 真人角色街拍 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803922538_3d2fcz_HSfcWZPboAACjHB.jpg" width="600" alt="产品营销 - GPT Image 2 真人角色街拍 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803922023_taeyeg_HSfcWZMbEAAVVwB.jpg" width="600" alt="产品营销 - GPT Image 2 真人角色街拍 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789803923311_i4cuar_HSfcWWdbQAA76Hl.jpg" width="600" alt="产品营销 - GPT Image 2 真人角色街拍 - Image 4">
</div>

#### 📌 详情

- **作者:** [VoxCat](https://x.com/VoxcatAI)
- **来源:** [Twitter Post](https://x.com/VoxcatAI/status/2100890040100626480)
- **发布时间:** 2026年9月18日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35002)**

---

### No. 94: 产品营销 - 超写实时尚人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于使用 gpt-image-2（文中称为 gpt2，但上下文暗示为图像生成模型）生成超写实时尚人像的提示词。注意：'gpt2' 通常指文本模型，但用户称 'Image was generated using gpt2'。鉴于严格的过滤规则，如果 'gpt2' 含义模糊或指代旧版 LLM，可能会被拒绝。然而，观察模式 'gpt image 2'，'gpt2' 很可能是 gpt-image-2 或类似工具的笔误。但等等，指令说明：'对于 ANY other AI model... 的提示词设置 hasPrompt=false... 一条 MENTIONS gpt-image-2 但分享 DIFFERENT model 提示词的推文 — 设置 hasPrompt=false'。文本说的是 'gpt2'。这很模糊。让我们仔细看。'gpt2' 绝对不是 'gpt-image-2'。这可能是用户的错误，或者指的是不同的工具。然而，用户经常错误地将 'gpt-image-2' 简写为 'gpt2'。但严格来说，'gpt2' 是一个特定的旧模型。如果我将其视为 gpt-image-2 的噪音/笔误，我可能会包含它。但提示词过滤器是严格的。看看其他推文。推文 2100429164914557427 说 'Gpt image 2'。推文 2100779368318701669 说 'GPT Image 2'。推文 2100839251294446037 说 'GPT Image 2'。推文 2100812124109091018 说 'gpt2'。这很可能是 gpt-image-2 的笔误或泛指。鉴于风险，我将标记 isTweetAboutTargetModel=false，因为 'gpt2' 不是 'gpt-image-2'，可能指代遗留文本模型或过于模糊。实际上，重读语义变体：'gpt image 2', 'gpt-image2', 'gpt-2 image'。单独的 'gpt2' 有风险。为了安全起见，我将拒绝它。

#### 📝 提示词

```
-
超写实时尚人像，一位美丽的女性被飘逸的半透明白色织物环绕，柔和的风自然地吹动头发，优雅的白色无袖连衣裙，极简单色美学，轻盈的丝绸织物包裹着画面，梦幻般的电影感灯光，柔和漫射的自然光，奢华杂志摄影风格，空灵的氛围，精致的皮肤纹理，柔和的阴影，高级时装 Vogue 风格，居中构图，干净的白色背景，优雅的动作，85mm 镜头，浅景深，超高细节，高端美容广告，柔和哑光色调，自然的面部表情，漂浮的织物动态，精致的女性化美学
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717713791_833rol_HSeVd0QbQAAZWwM.jpg" width="600" alt="产品营销 - 超写实时尚人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Marcos](https://x.com/arsalannazir07)
- **来源:** [Twitter Post](https://x.com/arsalannazir07/status/2100812124109091018)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34933)**

---

### No. 95: 产品营销 - 奢华地中海时尚大片提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个详细的提示词，用于生成一张逼真的奢华时尚大片，画面中一位身着亚麻西装的型男站在迷人的地中海海岸背景下。

#### 📝 提示词

```
逼真风格的奢华时尚大片，主角是一位三十岁出头、极具魅力的地中海男士，留着深色波浪卷发和修剪整齐的络腮胡，佩戴圆形复古墨镜，身穿一套精致的酒红色/勃艮第红亚麻西装，搭配剪裁宽松的长裤和一件挺括的白色亚麻衬衫，衬衫领口微敞，脚踩棕色麂皮乐福鞋。他随意地倚靠在一堵古老风化的石灰岩墙上，双腿自然交叉，双手插在裤兜里，神情自信而放松，目光略微向上并避开镜头。
戏剧性的地中海海岸场景，背景是令人屏息的绿松石色大海和崎岖的石灰岩悬崖，优雅的半山建筑，温暖的午后金色阳光，柔和的电影感阴影，浅景深效果，背景优美虚化，自然的皮肤质感，真实的织物纹理，营造出精致的意大利里维埃拉 / 阿马尔菲海岸氛围。全身时尚摄影，竖构图，主体突出取景，85mm 镜头，f/2.8 光圈，高端奢华杂志大片风格，电影级调色，温暖的大地色调，超写实摄影，面部细节清晰锐利，比例自然，带有微妙的胶片颗粒感，顶级时尚广告美学，8K 高清细节。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717709996_62xjl3_HSeGIK_bcAAJaeK.jpg" width="600" alt="产品营销 - 奢华地中海时尚大片提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2100795233747476490)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34928)**

---

### No. 96: 产品营销 - 电影感健身宣传摄影

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

生成超写实电影感健身宣传照片的详细提示词，画面中一名男性运动员正举起杠铃，伴有镁粉飞扬的效果。

#### 📝 提示词

```
一张超写实的电影感健身宣传照片，主角是一位英俊的年轻男性运动员，二十岁出头，正在昏暗的工业风健身房中，将沉重的杠铃直接举至镜头上方。采用极端的低角度仰拍视角，相机位于他正下方，使运动员和杠铃在观众头顶显得极具压迫感和戏剧性。

他留着浓密自然的黑色波浪卷发，蓬松而凌乱有型；眉毛浓密且轮廓分明；深棕色眼眸深邃；鼻梁挺直如雕塑；颧骨突出；下颌线锋利阳刚；脸上带有细微的自然胡茬；皮肤纹理高度逼真，可见毛孔和汗水。

他的肌肉线条自然清晰，体格健硕，肩部、手臂、胸部和核心肌群充满力量感。表情专注而坚定。当他用力将沉重杠铃向上推起时，双手间爆发出一团白色的镁粉尘雾，悬浮颗粒在电影感的顶光照射下弥漫于空气中。

环境是一个粗犷昏暗的工业风健身房，配有黑色钢铁器械、混凝土墙壁、金属质感表面、微妙的大气雾霭、深邃阴影以及富有戏剧性的定向光照。强烈的轮廓光勾勒出他的身形，体积光束穿透充满镁粉的空气。

添加醒目的文字 "{argument name="text" default="FORGED"}" 作为高端健身宣传排版，字体巨大有力，自然地融入构图之中，不遮挡运动员的面部或身体。采用工业风压缩大写字体，展现坚韧的运动美学，并带有轻微的做旧纹理。

极端低角度，动态透视，电影级构图，宏大尺度感，高对比度，逼真的汗水与镁粉颗粒，浅景深，85mm 摄影美学，超高细节，照片级真实感，8K HDR，高端健身广告摄影。

无女性，无人群，无多余人物，无 Logo，无水印，无解剖结构扭曲，无多余手指，无人工痕迹明显的脸部。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717715966_nq9voi_HSd3lbjbwAAfohF.jpg" width="600" alt="产品营销 - 电影感健身宣传摄影 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2100779246247641102)
- **发布时间:** 2026年9月18日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34937)**

---

### No. 97: 产品营销 - 适用于 GPT Image 2 的电影感沙漠人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个高度详细的提示词，用于生成一位身着传统中东服饰的男子在日落时分穿越沙漠沙丘的超写实电影感全身肖像。

#### 📝 提示词

```
超写实的电影感全身肖像，描绘了一位二十岁出头、英俊非凡的年轻男子，自信地行走在广阔金色的沙漠沙丘中，正值日落时分。他拥有一头浓密自然卷曲的乌黑头发，呈现出柔和蓬松的质感；眉毛浓密且轮廓分明，深邃富有表现力的深棕色眼睛，挺直雕塑般的鼻子，突出的颧骨，棱角分明的男性化下颌线，以及淡淡的自然胡茬。他的表情平静、尊贵、自信且神秘。

他穿着精致的传统中东风格服饰：一件奢华飘逸的象牙白长袍（thobe），带有微妙的刺绣细节；一件完美垂坠的深酒红色斗篷（bisht），饰有优雅的金色镶边；精致的皮革凉鞋；以及一条传统米色头巾（keffiyeh），自然地环绕在他的头部和肩部。织物在温暖的沙漠微风中轻轻飘动。

无尽雕刻般的沙丘延伸至远方，在戏剧性的黄金时刻夕阳下熠熠生辉。温暖的阳光在沙地上投下长长的电影感阴影，大气中的尘埃颗粒在空中轻柔漂浮。远处雄伟的沙漠山脉剪影为地平线增添了深度。

高端时尚编辑摄影，电影构图，自然的皮肤纹理和可见毛孔，逼真的织物细节，物理准确的光照，体积感的金色阳光，微妙的胶片颗粒，浅景深，丰富的暖色调，戏剧性的天空，照片级真实感，8K HDR，超高细节，使用 85mm 镜头拍摄，顶级杂志美学，无人工痕迹的面部，无文字，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717711906_q2qosr_HSaqaSWaAAAoc1X.jpg" width="600" alt="产品营销 - 适用于 GPT Image 2 的电影感沙漠人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2100553654071968133)
- **发布时间:** 2026年9月17日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34931)**

---

### No. 98: 产品营销 - 电影感牛仔夹克人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

为 GPT Image 2 优化的超写实电影感人像提示词，展示身穿黑色牛仔夹克和牛仔裤的女性。

#### 📝 提示词

```
创作一张超写实的电影感人像摄影作品，画面中是一位美丽的年轻女性，拥有一头浓密、自然卷曲的深棕色长发，中分发型，脸颊两侧有柔和的发丝修饰脸型。她五官精致柔美，皮肤白皙透亮，嘴唇呈自然的粉色，眉毛自然，眼神深邃动人（深棕色）。她直视镜头，表情平静、温柔且略带严肃。
她身穿一件时尚黑色牛仔夹克，内搭修身黑色上衣，下身搭配黑色牛仔裤，腰间系着一条带有银色矩形扣环的黑色皮带。脖子上佩戴着一条精致的银色项链，挂着一个小吊坠。抬起的手腕上戴着一款经典黑色皮表带手表，表盘为银色。
姿势：特写至半身人像，站在室内豪华现代走廊中。一只手轻轻触碰并撩起头部一侧的头发，另一只手臂自然下垂。身体面向镜头，姿态放松而自信。
背景：优雅高档的酒店或豪华公寓走廊，墙壁呈暖米色，地面抛光反光，天花板灯光柔和，远处呈现奶油般的金色散景效果。背景虚化柔和，营造出高端电影氛围。
光线：柔和温暖的室内照明，面部受自然漫射光照射，发丝上有微妙的高光，皮肤纹理真实，阴影柔和，整体色调温暖奢华。
摄影风格：超写实专业时尚摄影，电影感人像，时尚杂志编辑风格，85mm 镜头，f/1.8 光圈，浅景深，发丝细节逼真，皮肤毛孔自然，黑色牛仔布料纹理清晰，高动态范围，柔和散景，专业色彩分级。
构图：垂直 2:3 人像比例，平视相机角度，主体居中，突出头部和上半身，细节丰富，照片级真实感，8K 画质。
负面提示词：卡通，动漫，插画，CGI，塑料质感皮肤，过度磨皮的脸部，模糊的眼睛，扭曲的手部，多余的手指，变形的脸部，不自然的头发，过饱和的颜色，刺眼的光线，低分辨率，水印，文字。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631451411_2xjqd2_HSZSO4Ra8AAw3Si.jpg" width="600" alt="产品营销 - 电影感牛仔夹克人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [Zorvia](https://x.com/ZorviaLux)
- **来源:** [Twitter Post](https://x.com/ZorviaLux/status/2100456702823030825)
- **发布时间:** 2026年9月17日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34844)**

---

### No. 99: 产品营销 - 未来主义赛车车库人像提示词

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

用于创作一位身穿奢华西装的年轻男子在充满未来感的方程式赛车车库内、超级跑车旁的超写实电影感人像的提示词。

#### 📝 提示词

```
超写实电影感全身时尚人像，描绘了一位二十岁出头、英俊非凡的年轻男子，自信地站在一间高端未来主义方程式赛车车库内，身旁是一辆前卫的下一代超级跑车。他拥有一头浓密自然卷曲的乌黑头发，呈现出柔和凌乱的蓬松感；眉毛浓密且轮廓分明，深邃富有表现力的深棕色眼睛，挺括雕塑般的鼻子，突出的颧骨，锋利阳刚的下颌线，以及淡淡的自然胡茬。他的神情平静、自信、精致，略带一丝神秘感。
他身着一套剪裁无可挑剔的午夜黑奢华西装，搭配一件领口微敞的挺括黑色真丝衬衫，脚穿优雅的黑色皮革正装鞋，佩戴极简风格的高端腕表及精致配饰。他的姿态放松却极具气场，一只手自然地搭在未来感十足的汽车旁。
这辆超级跑车拥有激进的空气动力学轮廓、锐利的 LED 前大灯、裸露的碳纤维细节、雕塑般的车身线条、未来主义赛车轮毂以及微妙发光的装饰元素，灵感源自前沿的方程式赛车技术。在他身后是一个专业级的高端赛车车库，配有抛光金属地板、碳纤维设备、发光的维修区面板、赛车监控屏、流线型工具台以及戏剧性的顶部照明。
情绪化的电影布光，冷调的金属反射，微妙的大气雾霭，真实的皮肤纹理与毛孔，自然的面部细节，戏剧性的轮廓光，浅景深，奢华汽车编辑美学，高端时尚大片摄影，85mm 镜头，f/1.8，HDR，照片级真实感，8K，超高细节，真实比例，无人工痕迹的脸部，无水印，无标志。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789717710225_72fg5w_HSY736sb0AAM9Xz.jpg" width="600" alt="产品营销 - 未来主义赛车车库人像提示词 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2100432119327871085)
- **发布时间:** 2026年9月17日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34930)**

---

### No. 100: 产品营销 - 日式面馆招牌

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一张写实风格的图片，展示了一家日式餐厅店面，特色是色彩丰富的墙面菜单和宣传 500 日元套餐的户外立式广告牌。

#### 📝 提示词

```
一张逼真的照片，展示了日式餐厅的外立面，其中包含两个不同的招牌元素。背景中，安装在深色木质柜台上方粉色墙壁上的是一块大型菜单板，分为垂直的颜色编码列（黄色、白色、蓝色、红色）。这些列中的文字列出了诸如“狸猫乌冬面”、“拌乌冬面”、“油荞麦面”和“蘸面”等面条菜品，价格标注为 380 日元。前景中，立在人行道上的是一个黑色 A 型立式广告牌，以 2x2 网格形式展示了四款促销套餐。每个象限都配有诱人的食物碗照片（面条和猪肉饭），并伴有醒目的文字，宣传将面条与“猪肉盖饭”结合的“500 日元”套餐。光线为自然日光，捕捉了街道背景下招牌的鲜艳色彩。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631457355_f54o9x_HSU_xn5aUAA7gAR.jpg" width="600" alt="产品营销 - 日式面馆招牌 - Image 1">
</div>

#### 📌 详情

- **作者:** [Torishima / INTP](https://x.com/izutorishima)
- **来源:** [Twitter Post](https://x.com/izutorishima/status/2100233876388053345#reversed-0)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34850)**

---

### No. 101: 产品营销 - 紫发时尚人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

专为 GPT Image 2 设计的超写实低角度时尚人像提示词，展现一位留着紫色头发、身穿橙色西装外套的女性。

#### 📝 提示词

```
创建一张超写实的低角度全身时尚人像，主体为参考图中的同一位年轻女性。保留她鲜艳的 {argument name="hair color" default="violet-purple"} 齐下巴波波头及直刘海、白皙如瓷的肌肤、自然的雀斑、淡褐色/浅棕色眼睛、精致的五官、光泽感的嘴唇以及纤细的身材。
她随意地坐在石阶上，双膝弯曲并分开，双手放在大腿附近，头部微微后仰，目光看向镜头之外。她身穿一件宽松的鲜艳 {argument name="jacket color" default="orange"} 西装外套，内搭修身白色罗纹背心，下身穿着脚踝处卷起的宽松白色阔腿裤，搭配白袜和厚底白色运动鞋，并佩戴圆形 {argument name="glasses tint" default="orange-tinted"} 墨镜。
背景使用带有清晰网格线的大型棕色纹理石墙。强烈的黄金时刻阳光营造出戏剧性的对角线阴影和高对比度。温暖的电影色调，真实的皮肤和织物质感，细节锐利，具有编辑风格的街头时尚摄影感，照片级真实，8K 分辨率。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631453805_szoqwf_HSV85EobAAA77Yj.jpg" width="600" alt="产品营销 - 紫发时尚人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [Wareen AI 💟](https://x.com/Wareenaa)
- **来源:** [Twitter Post](https://x.com/Wareenaa/status/2100222128834703614)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34845)**

---

### No. 102: 产品营销 - 电影质感天鹅绒西装人像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一个用于生成超写实电影感全身时尚人像的提示词，描绘了一位身穿午夜蓝天鹅绒西装的男士。

#### 📝 提示词

```
超写实电影感全身时尚人像，一位极具魅力的年轻男子，二十岁出头，自信地坐在黑暗工作室中一张简约的哑光黑色长方形凳子上。他留着浓密自然的波浪状乌黑头发，带有柔和的纹理体积感；眉毛浓密且轮廓分明；深邃富有表现力的深棕色眼睛；挺括雕塑般的鼻子；突出的颧骨；锋利阳刚的下颌线；以及细微自然的胡茬。他的表情平静、自信、严肃且神秘，直视镜头。

他身穿剪裁完美的深午夜蓝天鹅绒西装，搭配结构感强的西装外套和配套长裤，内搭一件领口微敞的挺括白色正装衬衫，脚穿优雅的黑色皮鞋，佩戴极简精致的配饰。他的姿态放松而有力，身体微微前倾，手肘自然放在大腿上，双手在身前松散地交握。

黑暗极简主义的电影工作室环境，背景从黑色渐变为炭灰色并完全融入黑暗，戏剧性的氛围烟雾和柔和雾气在他身后缭绕。来自上方略偏后方的强烈冷白色聚光灯透过烟雾营造出光环效果，而微妙的侧光则勾勒出他的面部和西装轮廓。深沉的阴影，高对比度，头发和肩膀周围有美丽的边缘光，现实的工作室地板投影。

以高端男装编辑大片风格拍摄，全身构图，相机位置略低于视线水平，85mm 人像镜头，浅景深，真实的皮肤毛孔和面部纹理，自然的解剖结构，详细的天鹅绒和织物纹理，抛光皮鞋，电影级 HDR，精致奢华的美学，忧郁的黑色电影氛围，微妙的胶片颗粒，专业工作室摄影，照片级真实感，超高细节，8K 画质。

无女性，无文字，无标志，无水印，无香烟，无夸张肌肉，无塑料皮肤，无人工感面孔，无扭曲的手部，无多余手指。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789545096956_3081uo_HSTuMi0bMAAzKiZ.jpg" width="600" alt="产品营销 - 电影质感天鹅绒西装人像 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeisenLegacy](https://x.com/MohdAdnanA86218)
- **来源:** [Twitter Post](https://x.com/MohdAdnanA86218/status/2100065236224966805)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34756)**

---

### No. 103: 产品营销 - 高级时尚编辑风双重曝光

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

专为 GPT Image 2 设计的详细提示词，用于创作具有双重曝光效果的高级时尚编辑肖像，画面中一位身穿牛仔服饰、佩戴墨镜的男士置身于琥珀色背景前。

#### 📝 提示词

```
创作一幅电影感的高级时尚编辑肖像，描绘一位英俊的男士回头望向镜头（使用图像作为面部参考）。他留着短而略显凌乱的纹理发型，蓄着修剪整齐的浓密胡须，五官轮廓深邃且充满男性魅力，佩戴着一副未来感十足的黑色墨镜。他身穿一件复古蓝色牛仔夹克，展现出逼真的褪色质感、缝线细节以及磨损的面料纹理。
在他身后，创建一个巨大的半透明重影双重曝光效果，呈现同一位男士略微朝向相反方向的姿态，为构图增添神秘的运动轨迹感。背景采用浓郁发光的焦橙色/琥珀色摄影棚渐变色调，伴有微妙的大气雾感和温暖的电影级布光。强烈的暖色轮廓光勾勒出头发和肩部的线条，柔和的方向性光线则照亮面部和牛仔面料的质感。
高端时尚杂志美学，照片级真实的皮肤和头发，极其细腻的面料细节，戏剧性的对比度，浅景深，微妙的胶片颗粒感，精致的色彩分级，清晰的面部焦点，体积光，精致的商业摄影，奢华眼镜广告大片，动态分层构图，人像摄影，4:5 竖屏比例，无文字，无标志，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789545102366_4bowxv_HSTsbWZacAEWyIv.jpg" width="600" alt="产品营销 - 高级时尚编辑风双重曝光 - Image 1">
</div>

#### 📌 详情

- **作者:** [Aijaz](https://x.com/iamsofiaijaz)
- **来源:** [Twitter Post](https://x.com/iamsofiaijaz/status/2100063290093375640)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34767)**

---

### No. 104: 产品营销 - Tiny Chefs 魔法微型烘焙坊场景

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

生成一幅充满奇思妙想的电影感图像，描绘一位年轻女面包师带领五位 Q 版迷你厨师宝宝穿过一家温馨的微型烘焙坊，场景中充满了甜蜜的信息和烘焙道具。

#### 📝 提示词

```
创作一幅超写实、细节丰富的电影感竖屏 4:5 人像，展现名为 “Tiny Chefs” 的魔法温馨微型烘焙坊，画面充满温暖、甜蜜、创意与欢乐的能量。在场景中央，展示一位开朗的年轻女面包师，她身穿白色长袖衬衫，系着印有 “Tiny Chefs” 字样和小爱心图案的棕色围裙，穿着黑白格纹裤子，戴着红色领巾，头发梳成凌乱的丸子头。她右手高举金属打蛋器，张大嘴巴开怀大笑，正向前奔跑。在她周围是五个幼儿大小的迷你厨师（Q 版婴儿），每位都戴着印有爱心和 “Tiny Chef” 字样的超大蓬松厨师帽，身着粉色或蓝色的围兜/围裙搭配格纹服装，脸颊上沾着面粉，笑容灿烂，手持巨大的烘焙道具：一个拿着巨型草莓，一个拿着大块巧克力，一个拿着擀面杖，一个拿着裱花袋，一个拿着装满彩色糖珠的玻璃罐。地板上散落着溢出的面粉，形成手写文字 “Sweet People Make a Brighter World ♡”，此外还有糖果球、鸡蛋、巧克力块和碗。

背景细节：
- 顶部中央：悬挂的木制招牌写着 “Tiny Chefs – Bake a Happier World ♡”，配有厨师帽图标。
- 左侧：黑板标题为 “Ingredients for Today:”，复选框列出 Love, Creativity, Kindness, Sweet Treats, Happy People，末尾有一个爱心；下方是标有 FLOUR, SUGAR, COCOA 的玻璃罐和一个倾倒出面粉的麻布袋。
- 右侧：第二块黑板列出 Small Bites / Big Happiness / Sweet People / Brighter Days / Same Team / Bigger Dreams，配有一个爱心；旁边是一个标有 SPRINKLES 且装满多彩糖果的玻璃罐。
- 远景透过拱形门廊：温暖的阳光、悬挂的吊灯、摆满烘焙食品的架子，以及架子上一个撒满糖珠的巨大粉色糖霜甜甜圈，还有一个小招牌写着 “Donut Happiness Lives Here ♡”。

光影与风格：来自后方的黄金时刻暖光倾泻而下，柔和的背景虚化，色彩浓郁饱和，浅景深聚焦于面包师，木材、织物、面粉尘埃和光泽糖果具有超精细纹理。营造童话绘本与电影现实主义相结合的奇幻氛围。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789631456671_iwuvr1_HSTg-NqawAA8NAi.jpg" width="600" alt="产品营销 - Tiny Chefs 魔法微型烘焙坊场景 - Image 1">
</div>

#### 📌 详情

- **作者:** [Mehwish kiran](https://x.com/mehwishkiran07)
- **来源:** [Twitter Post](https://x.com/mehwishkiran07/status/2100050753276817452#reversed-0)
- **发布时间:** 2026年9月16日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34773)**

---

### No. 105: 电商主图 - GPT Image 2 提示词：酒吧中身穿红裙的女性

![Language-JA](https://img.shields.io/badge/Language-JA-blue)

#### 📖 描述

为 GPT Image 2 设计的详细提示词，用于生成一张逼真的肖像照片：一位年轻女性身着酒红色缎面连衣裙，手持香槟杯，置身于琥珀色灯光笼罩的高档酒吧中。

#### 📝 提示词

```
主题：
红裙中的祝酒

主要主体：
画面中央，一位年轻女性坐在高档昏暗酒吧的深红色天鹅绒椅子上。焦点集中在她紧身的酒红色缎面连衣裙、右手纤细的香槟杯以及周围的琥珀色灯光上。

人物与表情：
小巧的椭圆形脸庞，柔和的下颌线，深邃的大棕眼，细眉，精致的鼻梁，微微张开的粉嫩光泽双唇。头部略微向右倾斜，目光流向屏幕左侧，带着平静的微笑。深棕色长卷发从中分处散开，披在肩上，留有稀疏的空气刘海和侧边发丝。

服装与姿势：
短款酒红色缎面连衣裙，配有细肩带，胸前交叉垂坠设计，从腰部到大腿呈现对角线褶皱。佩戴小珍珠耳环、镶嵌黑石的细项链，双手腕戴有精致手链。深深陷入椅中，双腿交叉，左肘靠在扶手上，指尖轻触下巴附近，右手握住酒杯杯脚。

背景与光线：
身后是琥珀色的层架灯光，摆放着酒瓶和玻璃器皿；右后方有布艺灯罩台灯和红花；左右两侧可见深红色椅子。左前方黑色大理石桌上放着蜡烛和小盘子。来自左右的温暖层架光和台灯柔和地打在脸部和缎面上，背景呈现圆形散景效果。

构图与相机：
3:4 竖构图，正面相机高度与坐姿人物齐平，捕捉从头顶到交叉膝盖的半身肖像。人物位于中心且占比大，酒杯在右上，蜡烛在左下。右腿在底部边缘被裁剪，焦点在眼睛和酒杯上，酒吧层架深度虚化。

质感与风格：
逼真的实拍照片风格。展现缎面、天鹅绒、大理石、玻璃的高清深层光泽以及自然皮肤光泽，由酒红色和琥珀色调统一的电影感夜景。

负面提示：
改变裙子颜色和交叉腿姿势；省略酒杯或酒吧灯光
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789977649024_s9ljsn_HSbauMPbkAABUzx.jpg" width="600" alt="电商主图 - GPT Image 2 提示词：酒吧中身穿红裙的女性 - Image 1">
</div>

#### 📌 详情

- **作者:** [Prompt アトリエ｜AI画像プロンプト](https://x.com/CyberTotal2026)
- **来源:** [Twitter Post](https://x.com/CyberTotal2026/status/2101659894357139704)
- **发布时间:** 2026年9月20日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=35122)**

---

### No. 106: 电商主图 - GPT Image 2 提示词：复古粉色搅拌机

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

专为 GPT Image 2 打造的高端产品摄影提示词，展示现代厨房中的复古风格淡粉色搅拌机。

#### 📝 提示词

```
一张高端写实特写照片，展示放置在现代厨房台面上的复古风格淡粉色搅拌机。该搅拌机拥有光泽感十足的粉色复古机身，搭配抛光镀铬装饰件、带透明手柄的玻璃搅拌杯，以及带有发光红色指示灯的圆形前置控制旋钮。杯内正在混合淡粉色和白色的食材，形成平滑的漩涡状动态效果。一只女性的手正轻柔地握住右侧的镀铬侧手柄。背景为优雅的现代厨房，包含深色拱形门廊、装裱好的极简主义艺术画作、柔和温暖的室内灯光、浅景深效果，以及镀铬和玻璃表面上的逼真反射。整体呈现奢华的产品摄影风格，构图具有电影感，细节高度丰富，纹理自然，采用垂直 9:16 比例。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789388947736_m2pa42_HSF63L-bgAA_Hmi.jpg" width="600" alt="电商主图 - GPT Image 2 提示词：复古粉色搅拌机 - Image 1">
</div>

#### 📌 详情

- **作者:** [Dua Fatima](https://x.com/DuaFatimaAi)
- **来源:** [Twitter Post](https://x.com/DuaFatimaAi/status/2099094038012100890)
- **发布时间:** 2026年9月13日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34656)**

---

### No. 107: 电商主图 - Rhode Lip Treatment 对比广告

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

创建一个黑色背景的并排对比图，展示两张西瓜主题的 rhode beauty 广告生成图。

#### 📝 提示词

```
目标：创建一个宽幅对比图，展示两张为 Peptide Lip Treatment (Watermelon Slice 口味) 生成的 rhode beauty 静态广告，采用黑色背景，并将两个方形广告样机并排呈现。

画布：16:9 横向画幅，黑色背景，高对比度，简洁的社交媒体对比布局。

布局：将两个圆角方形广告图水平居中放置，并留出充足间距。左侧面板上方用亮橙色文字标注：“GPT-Image-2”。右侧面板上方用同样的亮橙色文字标注：“GPT-Image-2.5”。在底部中央添加一行小的斜体橙色说明文字，内容为“prompt in comments”。

广告面板：使用 2 个方形美容广告面板。
1. 左侧面板：柔和的粉色背景，圆角设计，优雅的编辑类美容广告构图。左上角为大号衬线字体标题“A SLICE OF GLOSS.”，下方配有较小的“Peptide Lip Treatment”文字。一支粉色的 rhode Peptide Lip Treatment 唇膏管从右上角向左下角斜向悬浮，带有垂直的白色“rhode”品牌标识。周围环绕着光泽的粉色凝胶漩涡、透明的溅射水滴和西瓜切片。西瓜元素数量：3 片可见切片或楔形块——底部一片大西瓜切片、管身背后右侧一片切片、以及右上角一片小楔形块。保持产品居中且醒目。
2. 右侧面板：同一 rhode 广告的更具动感、更明亮、细节更丰富的版本。粉色背景，圆角设计，左上角为衬线标题“A SLICE OF GLOSS.”及较小的“Peptide Lip Treatment”。一支更大的粉色 rhode 唇膏管在中心附近斜向悬浮，周围环绕着富有戏剧性的半透明粉色光泽溅射丝带、大量气泡和水滴，以及西瓜切片。西瓜元素数量：5 片可见块——底部一条大的前景西瓜条、左中位置一片楔形块、右中位置一片楔形块、右上角一片小楔形块，以及中心溅射效果后方的一片局部切片。产品应比左侧面板看起来更清晰、更具光泽感且更高端。

视觉风格：精致的产品广告，鲜艳的西瓜粉色和红色，光泽的液体质感，影棚灯光，高端化妆品宣传，清晰的排版，饱和的色彩，逼真的 3D 产品渲染与超现实溅射摄影相结合。

文本与自定义：使用顶部标签 {argument name="left model label" default="GPT-Image-2"} 和 {argument name="right model label" default="GPT-Image-2.5"}。使用广告标题 {argument name="headline text" default="A SLICE OF GLOSS."}。使用管身上的品牌名 {argument name="brand name" default="rhode"}。使用底部说明文字 {argument name="bottom caption" default="prompt in comments"}。

约束：保持 2 个对比面板，2 个橙色模型标签，以及 1 个底部说明文字。不要添加额外的徽标、水印、UI 界面元素或指定标签及广告文案之外的任何额外文本。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942321734_9pzxvn_HRwjsc8bkAAKTG6.jpg" width="600" alt="电商主图 - Rhode Lip Treatment 对比广告 - Image 1">
</div>

#### 📌 详情

- **作者:** [HeyOz](https://x.com/HeyOz_AI)
- **来源:** [Twitter Post](https://x.com/HeyOz_AI/status/2097590858564726955#reversed-0)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33995)**

---

### No. 108: 电商主图 - 基于草图生成的写实风格房间推广渲染图

![Language-ZH](https://img.shields.io/badge/Language-ZH-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个综合性提示词，以手绘房间布局作为结构指南，生成具有自然光感的写实房地产推广照片。

#### 📝 提示词

```
创建一个写实的房间推广图像，用于向潜在租客展示我的房间。房间布局主题如下：左侧有一扇大落地窗，采光和照明效果极佳。窗边放着一个猫窝，上面躺着一只 {argument name="pet" default="橘猫"}。卧室内部有一张大书桌，桌上摆放着电脑、键盘、鼠标和手机等日常用品。一名年轻的中国男性正坐在人体工学椅上操作电脑。书桌右侧是一张单人床。整体空间关系需遵循草图布局。光影和纹理应呈现出手机拍摄的卧室照片效果。硬性要求：草图中所画的所有物品必须出现，包括窗外的太阳。需避免的问题：不要包含任何与现实日常生活相悖的元素或现象。其他比例和房间细节可由你自行决定，以确保呈现出自然、写实且不突兀的效果。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942292901_ftm719_HRwCeKraoAA-G5L.jpg" width="600" alt="电商主图 - 基于草图生成的写实风格房间推广渲染图 - Image 1">
</div>

#### 📌 详情

- **作者:** [安伈XinAn](https://x.com/AnXin_37)
- **来源:** [Twitter Post](https://x.com/AnXin_37/status/2097554757506539972)
- **发布时间:** 2026年9月9日
- **多语言:** zh

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33954)**

---

### No. 109: 电商主图 - 精致玫瑰美甲修图

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

在保持参考肖像几乎一致的前提下，仅将可见的指甲修改为精致的玫瑰主题美甲。

#### 📝 提示词

```
以 REFERENCE_0 作为底图，进行极其细腻的产品级修图：仅将手持草莓处可见的指甲修改为精致的 {argument name="nail design" default="淡粉色玫瑰主题美甲，配有微型花卉美甲艺术和亮面质感"}。保持整体构图、面部、姿势、服饰、软帽、花束、草莓、玫瑰、壁纸、光影、色调以及标题文字 {argument name="headline text" default="PINK EDEN"} 与参考图尽可能一致。请勿更改人物、背景、排版、裁剪或整体氛围。此次修图应仅影响 2 处可见的指甲区域：主拇指指甲及其旁边部分可见的小指甲；所有其他细节应保持不变。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942358271_0ynebz_HRvk4F8bYAAUW5q.jpg" width="600" alt="电商主图 - 精致玫瑰美甲修图 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942358277_clgsrw_HRvk4F2bcAADmc3.jpg" width="600" alt="电商主图 - 精致玫瑰美甲修图 - Image 2">
</div>

#### 📌 详情

- **作者:** [のえる](https://x.com/elle_elle_e)
- **来源:** [Twitter Post](https://x.com/elle_elle_e/status/2097521726594978239#reversed-1)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34041)**

---

### No. 110: 电商主图 - 产品植入生活方式图像生成

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

一套通过参考详细视觉风格 JSON，创建人物手持特定产品且风格一致的生活方式图像的工作流。

#### 📝 提示词

```
分析这张照片，并提供一份非常详细的 JSON 提示词来描述其视觉风格。请务必详细拆解色彩分级、光照以及照片中的所有确切颜色，以便我能将这种外观应用到我自己的图像中。使用此 JSON 作为参考，生成一个手持我产品的人物。保持相同的面部特征。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1789029005307_j2vgpe_HRvBtnraAAAChs3.jpg" width="600" alt="电商主图 - 产品植入生活方式图像生成 - Image 1">
</div>

#### 📌 详情

- **作者:** [Miko](https://x.com/Mho_23)
- **来源:** [Twitter Post](https://x.com/Mho_23/status/2097483045221917131)
- **发布时间:** 2026年9月9日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33936)**

---

### No. 111: 电商主图 - 韩国超市购物抓拍

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张写实的智能手机风格生活时尚照片，展示了一名女性在超市过道蹲下的瞬间，适用于真实的零售场景或社交媒体产品展示。

#### 📝 提示词

```
创作一张写实的竖屏智能手机风格照片，捕捉在韩国超市购物的抓拍瞬间。一位留着 {argument name="hair color" default="深棕色齐肩发"} 的年轻女性蹲在麦片和格兰诺拉麦片货架旁，戴着一顶压得很低的 {argument name="hat color" default="红色"} 棒球帽，身穿一件略显宽松的白色罗纹长袖亨利衫、浅蓝色阔腿牛仔裤、米色鞋底的白色运动鞋，背着一个纤细的黑色单肩包。她侧身向右看，左臂伸向地上的黑色塑料购物篮；篮子里装着可见的杂货，侧面印有白色的“emart”标志。场景中仅包含一位主要购物者、一个黑色购物篮、两位背景中的购物者、一辆背景中的购物车、一个醒目的上方过道指示牌（标有数字 6 和韩文分类文字）、一个写着“2,980”的价格标签，以及摆满贴有韩文标签的麦片、格兰诺拉麦片、零食和包装食品袋的长货架。采用自然的消费者手机抓拍风格，构图略显随意，呈现真实的室内荧光灯照明、轻微的动态模糊、中性色调、光亮的灰色超市地面反射、深邃的过道透视感以及真实的日常细节。使其看起来像是一张随意的买家秀或超市社交媒体照片，而非摄影棚时尚大片。无美颜灯光，无夸张姿势，无人工痕迹的皮肤质感，无多余人物，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942336338_pno2c0_HRunAK4a8AAgaeo.jpg" width="600" alt="电商主图 - 韩国超市购物抓拍 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942336335_c9iow2_HRunAK4bEAAuUrl.jpg" width="600" alt="电商主图 - 韩国超市购物抓拍 - Image 2">
</div>

##### Image 3

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942336347_njta2l_HRunAK7boAAhW8b.jpg" width="600" alt="电商主图 - 韩国超市购物抓拍 - Image 3">
</div>

##### Image 4

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942337698_21gvm6_HRunAK5bgAAlJqH.jpg" width="600" alt="电商主图 - 韩国超市购物抓拍 - Image 4">
</div>

#### 📌 详情

- **作者:** [虎小象](https://x.com/hx831126)
- **来源:** [Twitter Post](https://x.com/hx831126/status/2097453683609137635#reversed-0)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34017)**

---

### No. 112: 电商主图 - 破碎的古代陶土花瓶

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个写实的摄影棚产品拍摄提示词，用于生成背景为黑色的、带有发光内部结构的古老裂纹陶土文物。

#### 📝 提示词

```
创作一张博物馆级的超写实产品摄影照片，主体为单个古代 {argument name="artifact type" default="陶土花瓶"}，置于纯黑色背景中心。器皿呈高挑卵形，底座窄小，肩部圆润，瓶口宽大外翻，由红褐色风化粘土制成，带有厚重的岁月包浆、矿物质沉积、缺口、划痕、白色磨损和细微裂纹。添加雕刻装饰：瓶颈处紧贴瓶口下方有一圈连续的几何纹带，瓶身有凸起的漩涡状藤蔓浮雕图案。右前方有一处巨大的锯齿状垂直裂口，露出中空的内部，开口处仍附着多块破碎的陶片；裂口从上肩部延伸至下腹部，露出内部温暖的铜橙色锤纹凹陷表面，并捕捉光线。使用来自左上方的戏剧性摄影棚布光，并在破碎的空腔内增加微妙的温暖内反射光，以强调粗糙的陶瓷质感、断裂边缘、深度和考古真实感。构图为正面的四分之三产品视角，完整花瓶可见，底部带有轻微阴影，高对比度，焦点清晰，超精细，无标签，无人像，无额外物体，无水印。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942315707_4sytlg_HRuXCqdagAAoIpC.jpg" width="600" alt="电商主图 - 破碎的古代陶土花瓶 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942315769_dm2egp_HRuXCqiaQAADMwJ.jpg" width="600" alt="电商主图 - 破碎的古代陶土花瓶 - Image 2">
</div>

#### 📌 详情

- **作者:** [Jaden](https://x.com/23_)
- **来源:** [Twitter Post](https://x.com/23_/status/2097436129033343250#reversed-0)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33986)**

---

### No. 113: 电商主图 - 街头风格全身时尚肖像

![Language-EN](https://img.shields.io/badge/Language-EN-blue)

#### 📖 描述

全身商业摄影棚肖像提示词，展示了一名穿着休闲白色 Polo 衫、焦糖棕色慢跑裤并搭配同色系斜挎包的成年男性。

#### 📝 提示词

```
创作一张超写实的全身摄影棚时尚肖像，展示一名成年男性自信地站在无缝暖米色摄影棚背景前。

将人物置于画面中央，正对镜头，表情沉稳从容，姿态放松。他留着利落的自然短发，发际线整洁，外表修剪得体。

让他穿着一件干净的白色短袖 Polo 衫，胸前带有小巧的黑色 Nike 勾形标志，搭配修身的暖焦糖棕色慢跑裤。配上一双时尚的白棕配色 Nike 低帮运动鞋，与裤子和配饰完美呼应。

在他的躯干上斜挎一个高级焦糖棕色斜挎包，肩带跨过一侧肩膀。包应自然地垂落在他的下腹部/臀部区域，正面带有低调的黑色运动品牌标识和精致的彩色图形刺绣。

一只手轻轻握住斜挎包的下部，另一只手自然地放在胸前的肩带附近，营造出一种放松的街头时尚姿态。

使用柔和的专业摄影棚灯光，提供温和的正面照明，主体下方带有微妙的阴影，呈现自然的皮肤纹理、逼真的织物褶皱、高度精细的皮革/麂皮质感以及清晰的鞋履细节。

背景保持极简且无干扰，采用柔和的暖色调中性渐变。将图像风格设定为高级成人街头服饰广告肖像，现代、整洁、时尚、照片级真实感、构图平衡、面部细节清晰、比例真实、全身取景、高端商业摄影、85mm 镜头感、柔和的景深、超高分辨率。

长宽比：4:5 竖向肖像。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788855295885_pvw99a_HRpj3B8aoAAScPU.jpg" width="600" alt="电商主图 - 街头风格全身时尚肖像 - Image 1">
</div>

#### 📌 详情

- **作者:** [Abkr Sadiq](https://x.com/abs_uiux)
- **来源:** [Twitter Post](https://x.com/abs_uiux/status/2097155462961811901)
- **发布时间:** 2026年9月8日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33800)**

---

### No. 114: 电商主图 - 精品电商平铺网格

![Language-JA](https://img.shields.io/badge/Language-JA-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

专为时尚与服装电商 Lookbook 设计的简洁布局，展示了在水泥或木质地板上整齐排列的平铺商品。

#### 📝 提示词

```
[品牌/产品信息]
- 品牌名称：{argument name="brand name" default="{brandName}"}
- 系列名称：{argument name="collection" default="{collection}"}
- 典型商品价格：{argument name="item price" default="{backpackPrice}"}

[图像质量、呈现与构图规范]
- 风格：适用于日本时尚/生活方式品牌电商网站的极简且精致的 Lookbook 照片。
- 构图：在自然光照射的摄影棚内，将服装单品（包袋、外套、鞋履等）整齐地平铺或有序排列在硬木地板或水泥地面上。
- 排版布局（适用于 GPT-image / Nano Banana Pro）：在画布角落隐约呈现品牌名称 {argument name="brand name" default="{brandName}"}、{argument name="collection" default="{collection}"} 文字以及价格标注 {argument name="item price" default="{backpackPrice}"}，并使用超细字体。
- 灯光/色彩：如阴天自然光般柔和，低对比度，以大地色系（米色、橄榄绿、炭灰色、灰白色）为主的沉稳色调。

[布局与输出的严格限制（强制性）]
- 输出成品设计本身，并填满整个画布。设计内部的背景和场景描绘（墙壁、空间、阴影）可遵循正文中的说明。
- 禁止事项：带相框的海报照片、贴在墙上的海报照片、放置在桌子或纸张上的样机照片、纸张边缘的透视变形或投影。
- 输出成品 2D 平面设计本身，并填满整个画布。允许包含上述描述的场景元素（墙壁、房间、阴影）。绝对禁止任何海报样机效果：不得出现相框、不得出现贴在墙上或放在桌上的照片、不得出现艺术品边缘的透视变形或投影。

- 宽高比："--ar 1:1" 或 "--ar 4:3"
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788855320165_tg6adc_HRm1opdXQAEwb6-.jpg" width="600" alt="电商主图 - 精品电商平铺网格 - Image 1">
</div>

#### 📌 详情

- **作者:** [AI Guide-Note - 実務で使えるAI活用メディア](https://x.com/AIGuideNote)
- **来源:** [Twitter Post](https://x.com/AIGuideNote/status/2096906819713081810)
- **发布时间:** 2026年9月7日
- **多语言:** ja

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33797)**

---

### No. 115: 电商主图 - 商业粉色浆果冰沙摄影

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一份详细的高端食品场景商业摄影提示词，展示了粉色浆果冰沙和花生酱罐，并包含精确的产品与环境描述。

#### 📝 提示词

```
在明亮舒适的现代厨房中，创作一张超写实的高端食品摄影作品。左侧的白色圆桌上，垂直摆放着一组 {argument name="drink type" default="鲜艳浓郁的粉色浆果冰沙"}，盛装在 {argument name="glassware" default="三个小型透明玻璃罐叠放"} 中。冰沙质地浓稠细腻，带有细微的浆果颗粒和光泽感。右侧放置一个带有绿色盖子的透明 {argument name="complementary food" default="有机花生酱"} 罐，里面装满了金棕色的奶油花生酱。请准确还原产品包装、标签位置、颜色和比例。在罐子旁边自然地散落几颗完整的花生。前景处放置一个装有混合烤花生的小陶瓷碗，以及一个米色陶瓷盘，盘中放着一把盛有满满一勺奶油花生酱的勺子。在冰沙旁点缀几枝精致的绿色香草。背景：整洁的白色地铁砖厨房墙面，侧面照射的柔和自然光，微妙的阴影，营造出温暖舒适的氛围。将食物放置在一个小型木制项目上，下方垫着一张复古印花纸。在左上角添加优雅的手写风格白色文字“Smoothies”，下方配以较小的草书文字“Tingi Kalori”。垂直 9:16 构图，高端商业食品摄影，逼真的质感，自然日光，浅景深，柔和的背景虚化，清晰的产品细节，平衡的构图，温暖的生活方式美学，照片级真实感，高分辨率，无人物。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788769180609_sufbpd_HRh2BbAawAAZRGN.jpg" width="600" alt="电商主图 - 商业粉色浆果冰沙摄影 - Image 1">
</div>

#### 📌 详情

- **作者:** [Dua Fatima](https://x.com/DuaFatimaAi)
- **来源:** [Twitter Post](https://x.com/DuaFatimaAi/status/2096555489073279173)
- **发布时间:** 2026年9月6日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33680)**

---

### No. 116: 电商主图 - 粉色饮品微距摄影

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个商业级摄影提示词，用于拍摄冰镇粉色果饮的微距照片，强调凝结水珠、气泡和逼真的光影效果。

#### 📝 提示词

```
一张照片级逼真的特写，主体为一个 {argument name="container" default="高挑、晶莹剔透的圆柱形玻璃杯"}，里面盛着 {argument name="drink color" default="鲜艳的半透明粉色"} 果饮和几块不规则的大冰块。细小的气泡和细腻的泡沫自然地聚集在表面，冰块和玻璃杯上可见凝结的水珠和细小液滴。柔和的漫射日光照亮了饮品，在冰块中形成了美丽的粉色倒影和逼真的折射效果。{argument name="background" default="极简干净的白色背景，带有柔和模糊的产品/包装背景"}，浅景深，优雅的饮品摄影，微距细节，自然高光，逼真的玻璃畸变，清晰对焦，高端商业摄影，竖构图，8K，超写实
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788682054942_jzv3w7_HRfhOyYbwAA5q7U.jpg" width="600" alt="电商主图 - 粉色饮品微距摄影 - Image 1">
</div>

#### 📌 详情

- **作者:** [Dua Fatima](https://x.com/DuaFatimaAi)
- **来源:** [Twitter Post](https://x.com/DuaFatimaAi/status/2096391880644891001)
- **发布时间:** 2026年9月6日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33570)**

---

### No. 117: 电商主图 - 专业产品广告摄影

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一个专业的摄影棚拍摄提示词，用于制作具有柔和光影和高端品牌美学的高质量产品照片。

#### 📝 提示词

```
专业产品广告照片，拍摄主体为 "{argument name="product" default="[产品名称]"}"，在 {argument name="background" default="中性背景 [浅米色 / 蓝色渐变]"} 下进行摄影棚拍摄，柔和的漫射光，微妙的阴影，产品置于画面中心，四分之三角度视角，材质纹理细节丰富，符合高端品牌广告的简洁现代美学，4K 分辨率，1:1 纵横比
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788682055545_641j9k_HRdx-nca8AAWbsT.jpg" width="600" alt="电商主图 - 专业产品广告摄影 - Image 1">
</div>

##### Image 2

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788682055706_1jwcgb_HRdyErYaYAAAsxP.jpg" width="600" alt="电商主图 - 专业产品广告摄影 - Image 2">
</div>

#### 📌 详情

- **作者:** [Deny](https://x.com/denygen9)
- **来源:** [Twitter Post](https://x.com/denygen9/status/2096274439260516678)
- **发布时间:** 2026年9月5日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33572)**

---

### No. 118: 电商主图 - 冰蜂蜜拿铁搅拌特写

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张写实的微距美食摄影作品，展示了一只手在纹理玻璃杯中搅拌奶油冰蜂蜜拿铁的过程，适用于饮料广告或社交媒体内容。

#### 📝 提示词

```
创作一张 9:16 竖屏写实微距特写图片，展示放在光洁白色桌面上的小型透明纹理玻璃杯中的冰蜂蜜拿铁，构图如同电影级微距美食视频截图。玻璃杯应具有扇形波浪杯口和垂直条纹杯身，杯中盛满奶油色的咖啡和牛奶，表面及杯内清晰可见 7 块冰块。一只右手从右上角伸入，拇指和手指可见，手持 1 把闪亮的深色金属勺插入杯中轻轻搅拌，形成柔和的焦糖棕色漩涡层、细小的泡沫以及沿杯壁流动的咖啡条纹。使用 {argument name="drink color" default="奶油焦糖色咖啡"}、{argument name="glass style" default="小型透明扇形条纹玻璃杯"}、{argument name="tabletop color" default="光洁白色"}、{argument name="lighting style" default="柔和自然摄影棚灯光"} 以及 {argument name="camera angle" default="紧凑俯视微距特写"}。保持背景简洁且呈浅灰白色，具有浅景深、逼真的液体反射、细腻的冰块高光、诱人的奶油质感，构图平滑且具电影感，无文字，无 Logo，无多余物品。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788682097464_o55w3c_HRdKDJIagAASU3k.jpg" width="600" alt="电商主图 - 冰蜂蜜拿铁搅拌特写 - Image 1">
</div>

#### 📌 详情

- **作者:** [Dua Fatima](https://x.com/DuaFatimaAi)
- **来源:** [Twitter Post](https://x.com/DuaFatimaAi/status/2096225708116693057#reversed-0)
- **发布时间:** 2026年9月5日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33614)**

---

### No. 119: 电商主图 - 金毛寻回犬喷雾广告

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

通过将一张近距离喷雾参考图扩展为更宽广的宠物驱避喷雾广告，创作出一张照片级真实的户外露营产品摄影图。

#### 📝 提示词

```
以提供的参考图为基础，将其扩展为一张更宽广的竖版生活方式产品照片。保留正在被喷雾的金毛寻回犬以及扶住它身体的手，但需缩小画面，以展示狗狗侧身坐着且面部可见。添加第二只手，手持一个蓝白相间的扳机式喷雾瓶对准狗狗，并呈现出细微雾气喷洒在毛发上的效果。场景设定在黄金时刻阳光明媚的森林露营地，并增加 3 个主要的背景元素：右侧 1 个橄榄绿帆布帐篷，狗狗身后 1 张小型露营桌，以及 1 片柔和虚化的高大树林。使画面呈现出户外宠物驱避喷雾广告的质感；在瓶身上添加清晰可见的标签文字：{argument name="product label" default="Outdoor Repellent Spray"} 以及简单的品牌标识：{argument name="brand name" default="NIPIP"}。采用照片级真实的浅景深效果、温暖的背光、自然的色彩、清晰的毛发细节以及逼真的水珠/雾气。不要像参考图那样进行紧凑裁剪；需清晰展现狗狗、两只人手、喷雾瓶以及露营地的环境背景。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788942352509_kpd10v_HRbHd-Ka4AA6isc.jpg" width="600" alt="电商主图 - 金毛寻回犬喷雾广告 - Image 1">
</div>

#### 📌 详情

- **作者:** [Dmiao豆苗啊](https://x.com/nima2qisi2)
- **来源:** [Twitter Post](https://x.com/nima2qisi2/status/2096098246313795661#reversed-0)
- **发布时间:** 2026年9月5日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=34035)**

---

### No. 120: 电商主图 - 柔和影棚人像，手持粉色设备

![Language-EN](https://img.shields.io/badge/Language-EN-blue)
![Raycast](https://img.shields.io/badge/🚀-Raycast_Friendly-purple)

#### 📖 描述

一张 2:3 的写实生活风人像，一位戴眼镜的女性在浅蓝色影棚背景下，手持一台淡粉色手持设备。

#### 📝 提示词

```
创作一张 2:3 的写实竖构图影棚人像，主角为一名 20 岁出头的东亚女性，拥有 {argument name="hair color" default="黑色长发，略显凌乱"}，肤色白皙，面带柔和自然的微笑，佩戴黑色大框长方形眼镜。她呈坐姿或微微前倾，画面展示从上半身到头部的范围，身体向左侧转动四分之三，视线看向画面左侧外。她身穿简约的浅灰色吊带背心或家居上衣，肩带为白色，妆容自然清透，唇色粉嫩，表情轻松温柔。她的右手持有一件物品：一台纤薄的淡粉色手持电子设备，边角圆润，顶部附近有一个小圆按钮和两个微小的指示灯点，竖直持于脸颊旁。使用干净的浅水蓝色无缝背景，柔和的漫射影棚光，浅景深效果，面部细节清晰，皮肤纹理自然，发丝逼真，呈现清新的生活方式/产品摄影质感。构图保持通透，头部位于上方中心，手部和设备位于左下方，画面中不得包含任何文字、Logo、水印或额外道具。
```

#### 🖼️ 生成图片

##### Image 1

<div align="center">
<img src="https://cms-assets.youmind.com/media/1788595162538_l51g3c_HRVlrc4bMAAC5MV.jpg" width="600" alt="电商主图 - 柔和影棚人像，手持粉色设备 - Image 1">
</div>

#### 📌 详情

- **作者:** [LuLa](https://x.com/luladogdog)
- **来源:** [Twitter Post](https://x.com/luladogdog/status/2095695079189127542#reversed-0)
- **发布时间:** 2026年9月4日
- **多语言:** en

**[👉 立即尝试 →](https://youmind.com/zh-CN/gpt-image-2-prompts?id=33543)**

---

---

## 📚 更多提示词

<div align="center">

### 🎯 17459 更多提示词未在此显示

Due to GitHub's content length limitations, we can only display the first 120 regular prompts in this README.

**[👉 在网页图库中查看所有提示词](https://youmind.com/zh-CN/gpt-image-2-prompts)**

The gallery features:

✨ 精美的瀑布流网格布局

🔍 全文搜索和筛选

🌍 支持 17 种语言

📱 移动端优化体验

</div>

---

## 🤝 如何贡献

我们欢迎贡献！您可以通过以下方式提交提示词：

### 🐛 GitHub Issue

1. Click [**提交新提示词**](https://github.com/YouMind-OpenLab/awesome-gpt-image-2/issues/new?template=submit-prompt.yml)
2. 填写表单，包含提示词详情和图片
3. 提交并等待团队审核
4. 如果通过审核（我们会添加 `approved` 标签），它将自动同步到 CMS
5. 您的提示词将在 4 小时内出现在 README 中

**注意：** 我们仅接受通过 GitHub Issues 提交的内容，以确保质量控制。

查看 [CONTRIBUTING.md](docs/CONTRIBUTING.md) 了解详细指南。

---

## 📄 许可证

根据 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) 许可。

---

## 🙏 致谢

- [Payload CMS](https://payloadcms.com/)
- [youmind.com](https://youmind.com)

---

## ⭐ Star 历史

[![Star History Chart](https://api.star-history.com/svg?repos=YouMind-OpenLab/awesome-gpt-image-2&type=Date)](https://star-history.com/#YouMind-OpenLab/awesome-gpt-image-2&Date)

---

<div align="center">

**[🌐 在网页图库中查看](https://youmind.com/zh-CN/gpt-image-2-prompts)** •
**[📝 提交提示词](https://github.com/YouMind-OpenLab/awesome-gpt-image-2/issues/new?template=submit-prompt.yml)** •
**[⭐ 给仓库点星](https://github.com/YouMind-OpenLab/awesome-gpt-image-2)**

<sub>🤖 此 README 自动生成。最后更新： 2026-09-23T15:43:27.150Z</sub>

</div>
